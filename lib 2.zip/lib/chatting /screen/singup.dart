import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase/chatting%20/screen/loging.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
class SingUp extends StatefulWidget {
  const SingUp({super.key});

  @override
  State<SingUp> createState() => _SingUpState();
}

class _SingUpState extends State<SingUp> {

  TextEditingController userNameController= TextEditingController();
  TextEditingController emailController= TextEditingController();
  TextEditingController phoneController= TextEditingController();
  TextEditingController passwordController= TextEditingController();
  bool isLoading=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.deepPurpleAccent,
        title: const Text('Sing up',style: TextStyle(color: Colors.deepOrange),),
        centerTitle: true,
      ),
      body: isLoading ? Center(
        child: Container(
          height: 40,
          width: 40,
          color: Colors.red,
          child: const CircularProgressIndicator(),
        ),
      ) : Column(
        children: [
          TextField(
            controller: userNameController,
            decoration: const InputDecoration(
              hintText: 'userName'
            ),
          ),
          const SizedBox(height: 20,),
          TextField(
            controller: phoneController,
            decoration: const InputDecoration(
              hintText: 'phone'
            ),
          ),
          const SizedBox(height: 20,),
          TextField(
            controller: passwordController,
            decoration: const InputDecoration(
                hintText: 'password'
            ),
          ),
          const SizedBox(height: 20,),
          TextField(
            controller: emailController,
            decoration: const InputDecoration(
              hintText: 'email'
            ),
          ),
          const SizedBox(height: 20,),
          GestureDetector(
            onTap: () async{


              if(userNameController.text.isNotEmpty && emailController.text.isNotEmpty && passwordController.text.isNotEmpty){
                setState(() {
                  isLoading= true;
                });
                createAccount(userNameController.text, emailController.text, passwordController.text).then((user) async {

                  if(user !=null){
                    setState(() {
                      isLoading=false;
                    });
                    print('Account created sucessfull ');
                    FirebaseAuth _auth= FirebaseAuth.instance;
                    FirebaseFirestore _firebase= FirebaseFirestore.instance;
                    await _firebase.collection('users').doc(_auth.currentUser?.uid).set({
                      "email":userNameController,
                      "password":emailController,
                      "status": "Unavalible",

                    });


              await _firebase.collection('collectionPath').add({});

                  }else{
                    print('login Fields');
                  }
                });
              }else{
                print('Please enter Fields');
              }
            },
            child: const Text('sing up',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),
          const SizedBox(height: 20,),
          GestureDetector(
            onTap: (){

              Navigator.push(context,MaterialPageRoute(builder: (context) =>LoginScreen()));
            },
            child: const Text('login  here',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),
        ],
      ),
    );
  }

  Future<User?> createAccount(String name,String email,String password) async{
    FirebaseAuth _auth= FirebaseAuth.instance;
    FirebaseFirestore _firebase= FirebaseFirestore.instance;

    try{

      User? user =(await _auth.createUserWithEmailAndPassword(email: email, password: password)).user;
      if(user != null){
        print('Account created successfull');
        /// here used firebase storege

        await _firebase.collection('users').doc(_auth.currentUser?.uid).set({
          "email":email,
          "password":password,
          "status": "Unavalible",

        });
        return user;
      }else{
        print("Account creation failed");
        return user;
      }

    }catch(e){
      print('firebase Auth :${e}');
      return null;
    }
  }

}
