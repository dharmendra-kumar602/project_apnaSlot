import 'package:flutter/material.dart';
class ForgetScreen extends StatefulWidget {
  const ForgetScreen({super.key});

  @override
  State<ForgetScreen> createState() => _ForgetScreenState();
}

class _ForgetScreenState extends State<ForgetScreen> {

  TextEditingController forgetController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.deepPurpleAccent ,
        title: const Text('forget password Screen'),
        centerTitle: true,
      ),
      body: Column(
        children: [
         const SizedBox(height: 20,),
          TextField(
            controller: forgetController,
            decoration: const InputDecoration(
              hintText: 'forget password'
            ),
          ),
         const SizedBox(height: 20,),
          GestureDetector(
            onTap: (){

            },
            child: const Text('forget here',style: TextStyle(color: Colors.deepPurpleAccent),),
          )
        ],
      ),
    );
  }
}
