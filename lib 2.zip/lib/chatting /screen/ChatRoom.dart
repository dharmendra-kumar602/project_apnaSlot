import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
class HomeScreenChatting extends StatefulWidget {

   //  final Map<String,dynamic> userMap;
   // final String  chatRoomId;
  const HomeScreenChatting({super.key});

  @override
  State<HomeScreenChatting> createState() => _HomeScreenChattingState();
}

class _HomeScreenChattingState extends State<HomeScreenChatting> {

 final TextEditingController _message =TextEditingController();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chatting screen Name'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body:  Column(
        children: [
          Container(
            child: StreamBuilder<QuerySnapshot>(
              builder: (BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot){
                if(snapshot.data !=null){

                  return ListView.builder(
                    itemCount:snapshot.data?.docs.length,
                      itemBuilder: (BuildContext context,int index){
                      return Text(snapshot.data?.docs[index]['message']);
                      });
                }else{
                  return ListView.builder(
                      itemCount:snapshot.data?.docs.length,
                      itemBuilder: (BuildContext context,int index){
                        return Text(snapshot.data?.docs[index]['message']);
                      });
                }
              }, stream: null,
            ),
          ),

          Container(
            width: size.width /10,
            height: size.height,
            alignment: Alignment.center,
            child: Row(
              children: [
                Container(
                  height: size.height/12,
                  width: size.width/1.5,
                  child: TextField(
                    controller: _message,
                    decoration: InputDecoration(
                        hintText: 'Typing...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        )
                    ),
                  ),
                ),
                IconButton(onPressed: (){}, icon: const Icon(Icons.send)),
                SizedBox(
                  height: size.height,
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }
}
