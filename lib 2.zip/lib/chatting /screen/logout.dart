import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
class LogOut extends StatefulWidget {
  const LogOut({super.key});

  @override
  State<LogOut> createState() => _LogOutState();
}

class _LogOutState extends State<LogOut> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log out screen'),
        centerTitle: true,
      ),
      body: Column(
        children: [
         GestureDetector(
           onTap: (){
             logout();
           },
           child: const Text('Log out'),
         )
        ],
      ),
    );
  }

  Future logout() async{
    FirebaseAuth _auth= FirebaseAuth.instance;
    try{
      await _auth.signOut();
      print('Logout successfull');
    }catch(e){
      print('logout exception : ${e}');
    }
  }

}
