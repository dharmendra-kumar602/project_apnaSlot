import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase/chatting%20/screen/forget.dart';
import 'package:firebase/chatting%20/screen/ChatRoom.dart';
import 'package:firebase/chatting%20/screen/logout.dart';
import 'package:firebase/chatting%20/screen/singup.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  TextEditingController emailController= TextEditingController();
  TextEditingController passwordController= TextEditingController();
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.deepPurpleAccent ,
        title:  const Text('login Screen'),
        centerTitle: true,
      ),
      body:  Column(
        children:
        [
          TextField(
            controller: emailController,
            decoration: const InputDecoration(
              hintText: 'Enter Email',
            ),
          ),
           const SizedBox(height: 20,),
          TextField(
            controller: passwordController,
            decoration: const InputDecoration(
              hintText: 'Enter password',
            ),
          ),
          const SizedBox(height: 20,),
          GestureDetector(
            onTap: (){
              if(emailController.text.isNotEmpty && passwordController.text.isNotEmpty){
                setState(() {
                  isLoading = true;
                });

                login(emailController.text, passwordController.text).then((user) {

                  if(user != null){
                    print("Login Successfull");
                    setState(() {
                      isLoading=false;
                    });
                  }else{
                    print("Login Failed");
                  }
                });
              }else{
                print("please fill correct email  and password");
              }
            },
            child: const Text('Login here'),
          ),
          const SizedBox(height: 20,),
          GestureDetector(
            onTap: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) =>SingUp()));
            },
            child: const Text('sing up here',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),
          const SizedBox(height: 20,),

          GestureDetector(
            onTap: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) =>ForgetScreen()));
            },
            child: const Text('forget here',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),

         GestureDetector(
            onTap: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) =>LogOut()));
            },
            child: const Text('logout  here',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),
 GestureDetector(
            onTap: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) =>HomeScreenChatting()));
            },
            child: const Text('Chatting screen  here',style: TextStyle(color: Colors.deepPurpleAccent),),
          ),


        ],
      ),
    );
  }

  Future<User?> createAccount(String name,String email,String password) async{
    FirebaseAuth _auth= FirebaseAuth.instance;
    try{

      User? user =(await _auth.createUserWithEmailAndPassword(email: email, password: password)).user;
      if(user != null){
        print('Account created successfull');
        return user;
      }else{
        print("Account creation failed");
        return user;
      }

    }catch(e){
      print('firebase Auth :${e}');
      return null;
    }
  }

  Future<User?> login(String email,String password) async{

    FirebaseFirestore _firebase= FirebaseFirestore.instance;

    FirebaseAuth _auth=FirebaseAuth.instance;
    try{
      User? user=(await _auth.signInWithEmailAndPassword(email: email, password: password)).user;
      if(user !=null){
        print("Login Sucessfull");
///  here used for firebase storeges
        await _firebase.collection('users').doc(_auth.currentUser?.uid).set({
          "email":email,
          "password":password,
          "status": "Unavalible",

        });
        return user;
      }else{
        print("Login faild");
        return user;
      }
    }catch(e){
      print('login exception : ${e}');
    }
  }

  Future logout() async{
    FirebaseAuth _auth= FirebaseAuth.instance;
    try{
      await _auth.signOut();
      print('');
    }catch(e){

      print('logout exception : ${e}');
    }
}

}
