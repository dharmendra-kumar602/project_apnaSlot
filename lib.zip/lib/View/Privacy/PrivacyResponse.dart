class TermsAndConditionsResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  TermsData? data;

  TermsAndConditionsResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  TermsAndConditionsResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    data = json['data'] != null ? new TermsData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class TermsData {
  String? title;
  String? content;

  TermsData({this.title, this.content});

  TermsData.fromJson(Map<String, dynamic> json) {
    title = json['title'] != null ? json['title'].toString():null;
    content = json['content'] != null ? json['content'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['content'] = this.content;
    return data;
  }
}
