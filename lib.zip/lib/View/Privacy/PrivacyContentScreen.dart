import 'package:apna_slot/Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';

import '../../Controller/Helper/ColoController/CustomColors.dart';
import '../../Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
import '../../Controller/Helper/TextController/FontFamily/FontFamily.dart';
import '../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import 'PrivacyController.dart';


class PrivacyAndTermsScreen extends StatefulWidget {
  String type;
  PrivacyAndTermsScreen({Key? key,required this.type}) : super(key: key);

  @override
  State<PrivacyAndTermsScreen> createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<PrivacyAndTermsScreen> {

  PrivacyController  privacyCTRL = Get.put(PrivacyController());

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100),(){
      init();
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }



  Future<void> init()async{
    privacyCTRL.isNetworkError = false;
    privacyCTRL.isEmpty = false;

    if(await ConnectionValidator().check()){
      await privacyCTRL.getTermsApi(context: context,type: widget.type).then((value) {
      });
    }else{
      privacyCTRL.isNetworkError = true;
      setState(() {
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<PrivacyController>(
        init: privacyCTRL,
        builder: (controller) {
          return LoadScreen(
              widget: controller.isError ?
              ErrorScreen(onTap: (){init();},isShowBackBtn: true,)
              : controller.isNetworkError ?
              NoInternetConnectionScreen(
                  onTap: (){
                    init();
                  },isShowBackBtn: true
              )
              : controller.isEmpty ?
              EmptyDataScreen(
                isShowBtn: false,
                isShowBackBtn: true,
                onTap: (){ init();},
                string: kEmptyData,
              )
              : controller.termsData != null && controller.isEmpty == false ?
              Scaffold(
                backgroundColor: Colors.white,
                body: SafeArea(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Padding(
                          padding: const EdgeInsets.only(top: 50.0, left: 20.0,right: 20.0),
                          child: SingleChildScrollView(
                            physics: const ClampingScrollPhysics(),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                buildSizeBox(20.0, 0.0),
                                buildText1(text: controller.termsData?.title ?? "",size: 20,fontFamily: FontFamily.josefinBold),
                                buildSizeBox(10.0, 10.0),
                                Html(data: controller.termsData?.content ?? "",)

                              ],
                            ),
                          )
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          margin: const EdgeInsets.only(top: 50.0,right: 20.0),
                          child: InkWell(
                            onTap: (){
                                Get.back();
                              },
                            child: Icon(Icons.clear,color: CustomColors.blackColor ,size: 28.0,),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ):const SizedBox.shrink(),
              isLoading: controller.isLoading
          );
        }
    );


  }

}
