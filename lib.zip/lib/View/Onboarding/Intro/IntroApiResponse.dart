class IntroApiResponse {
  bool? error;
  String? message;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  List<IntroData>? data;
  int? errorCode;

  IntroApiResponse(
      {this.error,
        this.message,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.data,
        this.errorCode});

  IntroApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    if (json['data'] != null) {
      data = <IntroData>[];
      json['data'].forEach((v) {
        data!.add(new IntroData.fromJson(v));
      });
    }
    errorCode = json['errorCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['errorCode'] = this.errorCode;
    return data;
  }
}

class IntroData {
  String? heading;
  String? message;
  String? image;

  IntroData({this.heading, this.message, this.image});

  IntroData.fromJson(Map<String, dynamic> json) {
    heading = json['heading'] != null ? json['heading'].toString():null;
    message = json['message'] != null ? json['message'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['heading'] = this.heading;
    data['message'] = this.message;
    data['image'] = this.image;
    return data;
  }
}
