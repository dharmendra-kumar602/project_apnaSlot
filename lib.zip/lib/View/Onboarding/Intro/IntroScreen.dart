import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:delayed_display/delayed_display.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import 'IntroController.dart';


class IntroScreen extends StatefulWidget {
  const IntroScreen({Key? key}) : super(key: key);
  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {

  IntroController introCtrl = Get.put(IntroController());

  PageController pageCtrl = PageController(
    viewportFraction: 1.0,
    keepPage: true,
  );


  int currentPage = 0;

  @override
  void initState() {
    pageCtrl = PageController(
        viewportFraction: 1.0, keepPage: true, initialPage: 0);
    init();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> init()async{
    await introCtrl.introApi(context: context);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<IntroController>(
        init: introCtrl,
        builder: (controller) {
          return LoadScreen(
            widget: Scaffold(
                backgroundColor: Colors.white,
                appBar: AppBar(
                  elevation: 0,
                  backgroundColor: CustomColors.transparentColor,
                  actions: [
                    Padding(
                      padding: const EdgeInsets.only(
                        right: 15,
                        top: 20,
                      ),
                      child: InkWell(
                          focusColor: CustomColors.transparentColor,
                          hoverColor: CustomColors.transparentColor,
                          highlightColor: CustomColors.transparentColor,
                          splashColor: CustomColors.transparentColor,
                          onTap: () {
                            Get.offAllNamed(loginScreenRoute);
                          },
                          child: buildText1(text: kSkip,size: 18)
                      ),
                    ),
                  ],
                ),
                floatingActionButton: FloatingActionButton(
                  onPressed: () {
                    if (currentPage == 1) {
                      Get.offAllNamed(loginScreenRoute);
                    }else{
                      pageCtrl.nextPage(curve: Curves.easeIn, duration: const Duration(milliseconds: 300));
                    }
                  },
                  backgroundColor: CustomColors.bluearrowcolor,
                  child: Center(
                    child: SvgPicture.asset(str_svgForward,color: CustomColors.whiteColor,),
                  ),
                ),
                body: PageView.builder(
                    itemCount: controller.introData?.length,
                    controller: pageCtrl,
                    onPageChanged: onPageViewChange,
                    itemBuilder: (context,index){
                      return
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              buildSizeBox(100.w * 4 / 100, 0.0),
                              SizedBox(
                                  height: 100.w * 100 / 100,
                                  child: controller.introData?[index].image != null ?
                                  ImageHelperWhiteBg(
                                    image: controller.introData?[index].image ?? '',
                                    height: MediaQuery.of(context).size.height,
                                    width: MediaQuery.of(context).size.width,
                                    fit: BoxFit.cover,
                                    alignment: Alignment.topCenter,
                                  ):DefaultWidget.whiteBg(),
                              ),
                              buildSizeBox(100.w * 10 / 100, 0.0),
                              DelayedDisplay(
                                child: buildHeadingBold(
                                  text: controller.introData?[index].heading ?? "",
                                  style: TextStyle(fontFamily: FontFamily.larkenBold, fontSize: 24),
                                ),
                              ), 
                              buildSizeBox(100.w * 3 / 100, 0.0),
                              DelayedDisplay(
                                  child: buildMainDescription(text: controller.introData?[index].message ?? ""))
                            ],
                          ),
                        );
                    }
                )

            ),
            isLoading: false,
          );
        });

  }

  Future<void> onPageViewChange(int page) async {
    PrintLog.printLog("Current Main Page: $page");
    int previousPage = page;

    currentPage = page;


    if (page != 0) {
      previousPage--;
    } else {
      previousPage = 2;
    }
    PrintLog.printLog("Previous Main Page: $previousPage");
    setState(() {});
  }
}
