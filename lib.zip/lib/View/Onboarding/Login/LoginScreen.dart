import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/TextController/TextValidator/TextValidator.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../Controller/WidgetController/TextField/CustomTextField.dart';
import 'LoginController.dart';


class LoginScreen extends StatefulWidget{
  const LoginScreen({Key? key}) : super(key: key);
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>{

  final _formKey = GlobalKey<FormState>();

  TextEditingController mobileNoCtrl = TextEditingController();
  LoginController loginCtrl = Get.put(LoginController());

  bool isClearBtn = false;
  bool isNumber = false;
  bool isValidNumber = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    mobileNoCtrl.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder<LoginController>(
        init: loginCtrl,
        builder: (controller) {
          return GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: LoadScreen(
              widget: Scaffold(
                  backgroundColor: CustomColors.whiteColor,
                  body: SingleChildScrollView(
                    child: Container(
                      height: Get.height,
                      width: Get.width,
                      padding: const EdgeInsets.only(left: 15,right: 15,top: 15),
                      child: Column(
                        children: [
                          buildSizeBox(Get.height *7/100, 0.0),
                          buildMainHeading(text: kLoginTitle),
                          buildSizeBox(Get.height *2.5/100, 0.0),
                          buildMainDescription(text: kLoginDes),
                          buildSizeBox(Get.height *3.5/100, 0.0),

                          CustomTextField(
                              readOnly: false,
                              isError: isNumber ? true : isValidNumber ? true:false,
                              errorText: isNumber ? kEnterMobileNo : isValidNumber ? kEnterValidMobileNo:'',
                              controller: mobileNoCtrl,
                              hintText: kLoginMob,
                              inputType: TextInputType.phone,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              maxLength: 10
                          ),
                          buildSizeBox(Get.height *7/100, 0.0),
                          ButtonCustom(
                            onPress: checkDetails,
                            buttonWidth: Get.width,
                            buttonHeight: 54,
                            text: kLoginBtnTitle
                            ,),
                          buildSizeBox(Get.height *4/100, 0.0),
                          // buildSizeBox(30.0, 0.0),
                          InkWell(
                            onTap: () {
                              Get.toNamed(signUpScreenRoute);
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                buildText1(text: kLoginNotMember,color: CustomColors.greyColor),
                                buildText1(text: kLoginRegisterNow),
                              ],
                            ),
                          ),
                          buildSizeBox(Get.height *1.5/100, 0.0),
                          // const Spacer(),
                          Expanded(
                            // height: Get.height * 45/100,
                            // width: Get.width,
                            child: Image.asset(
                              str_imgLoginBg,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
              ),
              isLoading: controller.isLoading,
            ),
          );
        });

  }

  checkDetails()async{
    isNumber = TxtValidation.normalTextField(mobileNoCtrl);
    isValidNumber = TxtValidation.validateMobileTextField(mobileNoCtrl);
    if(!isNumber && !isValidNumber){
      PrintLog.printLog(":::Success....");
      await loginCtrl.loginApi(context: context,mobNo: mobileNoCtrl.text.toString().trim(),isResend: false).then((value){
          FocusScope.of(context).unfocus();
      });
    }
    setState(() {

    });
  }

}