class SignUpApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  SignUpData? data;

  SignUpApiResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  SignUpApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    data = json['data'] != null ? new SignUpData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class SignUpData {
  int? id;
  String? name;
  String? email;
  String? mobileNo;
  int? mobileOtp;

  SignUpData({this.id, this.name, this.email, this.mobileNo, this.mobileOtp});

  SignUpData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    mobileNo = json['mobile_no'];
    mobileOtp = json['mobile_otp'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['mobile_no'] = this.mobileNo;
    data['mobile_otp'] = this.mobileOtp;
    return data;
  }
}
