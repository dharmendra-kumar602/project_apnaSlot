

import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/TextController/TextValidator/TextValidator.dart';
import '../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../Controller/WidgetController/CheckBox/CheckBoxCustom.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../Controller/WidgetController/TextField/CustomTextField.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import 'SignUpController.dart';

class SignUpScreen extends StatefulWidget{
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();

}

class _SignUpScreenState extends State<SignUpScreen>{
  SignUpController signUpCtrl = Get.put(SignUpController());

  TextEditingController nameCT = TextEditingController();
  TextEditingController emailCT = TextEditingController();
  TextEditingController mobCT = TextEditingController();

  FocusNode nameFC = FocusNode();
  FocusNode emailFC = FocusNode();
  FocusNode mobFC = FocusNode();
  FocusNode mobFC11 = FocusNode();

  bool isName = false;
  bool isEmail = false;
  bool isValidEmail = false;
  bool isMobile = false;
  bool isValidMobile = false;
  bool isCheck = true;

  double heightSpaceTextField = 10.0;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    nameFC.dispose();
    emailFC.dispose();
    mobFC.dispose();

    nameCT.dispose();
    emailCT.dispose();
    mobCT.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
          resizeToAvoidBottomInset: false,
          body: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Container(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: Column(
                    children: [

                      buildSizeBox(Get.height *7/100, 0.0),
                      buildMainHeading(text: kRegisterTitle),
                      buildSizeBox(Get.height *2.5/100, 0.0),
                      buildMainDescription(text: kSignUpDes),

                      buildSizeBox(Get.height *3.5/100, 0.0),
                      CustomTextField(
                        isError: isName,
                        autofillHints: [AutofillHints.name],
                        readOnly: false,
                        controller: nameCT,
                        focus: nameFC,
                        errorText: isName ? kEnterName:"",
                        hintText: kSignUpName,
                        inputType: TextInputType.text,
                        validator: (value) {
                        },
                      ),
                      buildSizeBox(heightSpaceTextField, 0.0),

                      CustomTextField(
                        isError: isEmail ? true : isValidEmail ? true:false,
                        readOnly: false,
                        controller: emailCT,
                        hintText: kEmail,
                        autofillHints: [AutofillHints.email],
                        focus: emailFC,
                        errorText: isEmail ? kEnterEmail : isValidEmail ?kEnterValidEmail:"",
                        // inputType: TextInputType.phone,
                        // maxLength: 10,
                        validator: (value) {
                        },
                      ),
                      buildSizeBox(heightSpaceTextField, 0.0),
                      CustomTextField(
                        isError: isMobile ? true : isValidMobile ? true:false,
                        readOnly: false,
                        controller: mobCT,
                        hintText: kMobileNumber,
                        errorText: isMobile ? kEnterMobileNo : isValidMobile ? kEnterValidMobileNo: '',
                        inputType: TextInputType.phone,
                        focus: mobFC,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        autofillHints: [AutofillHints.telephoneNumber],
                        maxLength: 10,
                        validator: (value) {
                        },
                      ),
                      buildSizeBox(heightSpaceTextField, 0.0),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CheckBoxCustomWithText(value: isCheck, title1: kSignUpIAgree,title2: kSignUpTNC,
                            onChanged: (val){
                              setState(() {
                                isCheck = val!;
                              });
                            },
                            onTap: (){
                            PrintLog.printLog("OnTap Term and Condition");
                            PopupCustom.termAndConditionPopUP(context: context, type: "terms");
                            },
                          )
                        ],
                      ),
                      buildSizeBox(Get.height *8/100, 0.0),
                      ButtonCustom(
                        onPress: checkDetails,
                        buttonWidth: Get.width,
                        buttonHeight: 56, text: kSubmit,
                      ),
                      buildSizeBox(Get.height *5/100, 0.0),

                      GestureDetector(
                        onTap: () {
                          Get.back();
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            buildText1(text: kSignUpAlready,color: CustomColors.greyColor),
                            buildText1(text: kLogin,color: CustomColors.bluearrowcolor),
                          ],
                        ),
                      ),
                    ],
                  ),

                ),
              ),
            ),
          )

      ),
    );
  }

  checkDetails()async{
    isName = TxtValidation.normalTextField(nameCT);
    isMobile = TxtValidation.normalTextField(mobCT);
    isValidMobile = TxtValidation.validateMobileTextField(mobCT);
    isEmail = TxtValidation.normalTextField(emailCT);
    isValidEmail = TxtValidation.validateEmailTextField(emailCT);

    if(!isName && !isMobile && !isValidMobile && !isEmail && !isValidEmail){
      if(isCheck){
        PrintLog.printLog(":::Success....");
        await signUpCtrl.signUpApi(
            context: context,
            name: nameCT.text.toString().trim(),
            mobNo: mobCT.text.toString().trim(),
            emailId: emailCT.text.toString().trim()
        ).then((value){
          FocusScope.of(context).unfocus();
        });
      }else{
        ToastCustom.showToast(msg: kCheckTerm);
      }
    }
    setState(() {

    });
  }
}




