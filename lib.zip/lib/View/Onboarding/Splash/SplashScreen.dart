import 'dart:async';
import 'package:apna_slot/View/Dashboard/Dashboard/DashboardScreen.dart';
import 'package:apna_slot/main.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/TextController/FontFamily/FontFamily.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../Dashboard/Home/HomeScreen/HomeController.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  AnimationController? controller;
  Animation<double>? scaleAnimation;

  @override
  void initState() {
    controllerInit();
    super.initState();
    Future.delayed(const Duration(milliseconds: 100),(){
      init();
    });
  }

  Future<void> controllerInit()async{
    // Get.put(HomeController());
  }

  @override
  void dispose() {
    super.dispose();
    scaleAnimation?.isDismissed;
    controller?.dispose();
  }

  Future<void> init() async {
    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000)
    );
    scaleAnimation = CurvedAnimation(parent: controller!, curve: Curves.easeIn);
    controller?.addListener(() {
      setState(() {});
    });
    controller?.forward();
    runSplash();
  }

  void runSplash() async {
    Future.delayed(const Duration(seconds: 5),(){
      if(authToken != ""){
        Get.offAllNamed(dashboardScreenRoute,arguments: DashboardScreen(screenIndex: 0));
      }else{
        Get.offAllNamed(introScreenRoute);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          constraints: const BoxConstraints.expand(),
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage(str_imgSvgSplashScreen1),
                fit: BoxFit.cover),
          ),
          child: Stack(
            children: [
              Container(
                  height: 100.h,
                  width: 100.w,
                  color: Colors.white12
              ),
              Center(
                child: Image.asset(str_gifSplash,width: 150),
              ),
              Positioned(
                width: 100.w * 2.8, //1100
                height: 100.w * 2.8,
                bottom: -100.w * 2.56,
                right: -100.w * 1.18, //-1010,right: -460,
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                ),
              ),

              Positioned(
                  bottom: 30,
                  right: 50,
                  child: Text(
                    kSplashScreenTitle,
                    style: TextStyle(
                        fontFamily: FontFamily.josefinRegular,
                        fontSize: 16,
                        color: CustomColors.bluearrowcolor
                    ),
                  ))
            ],
          )),
    );
  }

}
