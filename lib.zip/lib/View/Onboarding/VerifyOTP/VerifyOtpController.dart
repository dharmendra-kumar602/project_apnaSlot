
import 'package:apna_slot/Controller/Helper/DeviceInfo/DeviceInfo.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../../Controller/ApiController/ApiController.dart';
import '../../../Controller/ApiController/WebConstant.dart';
import '../../../Controller/Firebase/FirebaseMessaging/FirebaseMessaging.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../main.dart';
import '../../Dashboard/Dashboard/DashboardScreen.dart';
import 'VerifyOtpResponse.dart';


class VerifyOtpController extends GetxController{

  ApiController apiCtrl = ApiController();
  VerifyOtpData? verifyOtpData;

  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;

  Future<VerifyOtpApiResponse?> verifyOtpApi({required BuildContext context, required String otp, required String mobNo}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    String? deviceType = await DeviceInfoCustom.getPlatForm();

    String fcmToken = await FirebaseMessagingCustom.getToken() ?? "";
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.fcmToken, variableValue: fcmToken);

    Map<String, dynamic> dictparm = {
      "mobile_no":mobNo,
      "mobile_otp":otp,
      "fcm_token":fcmToken,
      "device_name":deviceType,
    };

    String url = WebApiConstant.API_URL_VERIFY_OTP;

    await apiCtrl.verifyOtpApi(context:context,url: url, dictParameter: dictparm,token: "")
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              verifyOtpData = result.data;
              await saveUserData(verifyOtpData: result.data);
              result.data == null ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);
              changeSuccessValue(true);
              Get.offAllNamed(dashboardScreenRoute,arguments: DashboardScreen(screenIndex: 0));
            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }



  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

  Future<void> saveUserData({VerifyOtpData? verifyOtpData})async{
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userId, variableValue: verifyOtpData?.id ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userName, variableValue: verifyOtpData?.name ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userEmail, variableValue: verifyOtpData?.email ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userMobileNo, variableValue: verifyOtpData?.mobileNo ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userProfileImg, variableValue: verifyOtpData?.profileImage ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userStatus, variableValue: verifyOtpData?.status ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.authToken, variableValue: verifyOtpData?.token ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userCityName, variableValue: verifyOtpData?.city ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAddress, variableValue: verifyOtpData?.address ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAadhaarNumber, variableValue: verifyOtpData?.aadhaarNo ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAadhaarImage, variableValue: verifyOtpData?.aadharImage ?? "");

    authToken = verifyOtpData?.token.toString() ?? "";
  }
}

