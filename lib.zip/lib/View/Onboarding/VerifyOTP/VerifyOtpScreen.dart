
import 'dart:async';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/OtpTextField/OtpTextField.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../Login/LoginController.dart';
import 'VerifyOtpController.dart';

class VerifyOtpScreen extends StatefulWidget{
  String mobileNumber;
  VerifyOtpScreen({Key? key,required this.mobileNumber}) : super(key: key);


  @override
  State<VerifyOtpScreen> createState() => _VerifyOtpScreenState();

}

class _VerifyOtpScreenState extends State<VerifyOtpScreen>{

  VerifyOtpController otpCtrl = Get.put(VerifyOtpController());
  LoginController loginCtrl = Get.find();

  TextEditingController controller1 = TextEditingController();
  TextEditingController controller2 = TextEditingController();
  TextEditingController controller3 = TextEditingController();
  TextEditingController controller4 = TextEditingController();


  FocusNode pin1focusNode = FocusNode();
  FocusNode pin2focusNode = FocusNode();
  FocusNode pin3focusNode = FocusNode();
  FocusNode pin4focusNode = FocusNode();


  Timer? _timer;
  int _start = 0;
  double spaceField = 10.0;


  void startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  void initState(){
    super.initState();
    init();
  }

  @override
  void dispose() {
    _timer?.cancel();
    clearTextField();
    controller1.dispose();
    controller2.dispose();
    controller3.dispose();
    controller4.dispose();

    super.dispose();
  }

  Future<void> init()async{
    clearTextField();
  }

  void nextField(String value, FocusNode focusNode, [FocusNode? focusNode1]) {
    if (value.length == 1) {
      focusNode.requestFocus();
    } else {
      focusNode1?.requestFocus();
    }
    setState(() {

    });
  }

  clearTextField()async{
    controller1.clear();
    controller2.clear();
    controller3.clear();
    controller4.clear();
    pin1focusNode.requestFocus();
  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder<VerifyOtpController>(
        init: otpCtrl,
        builder: (controller) {
          return LoadScreen(
            widget: Scaffold(
              backgroundColor: Colors.white,
              body: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => FocusScope.of(context).unfocus(),
                  child: SingleChildScrollView(
                    physics: const NeverScrollableScrollPhysics(),
                    child: Form(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        child: Center(
                            child: Column(
                              children: [
                                SizedBox(height: 8.h),
                                Text(kVerifyOtpTitle,style: TextStyle(fontFamily: FontFamily.larkenRegular,fontSize: 24),),
                                SizedBox(height: 2.h),
                                Text(
                                  kVerifyOtpDes
                                  ,style: TextStyle(fontFamily: FontFamily.josefinRegular,height:1.4,letterSpacing:0.37,fontSize: 14),textAlign: TextAlign.center,),
                                SizedBox(height: 6.h),
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children:  [
                                      OtpTextfieldWidget(
                                        textEditingController: controller1,
                                        focus: pin1focusNode,
                                        onChanged: (value){
                                          nextField(value, pin2focusNode);
                                        },
                                      ),
                                      buildSizeBox(0.0, spaceField),
                                      OtpTextfieldWidget(
                                        textEditingController: controller2,
                                        focus: pin2focusNode,
                                        onChanged: (value){
                                          nextField(value, pin3focusNode,pin1focusNode);
                                        },
                                      ),
                                      buildSizeBox(0.0, spaceField),

                                      OtpTextfieldWidget(
                                        textEditingController: controller3,
                                        focus: pin3focusNode,
                                        onChanged: (value){
                                          nextField(value, pin4focusNode,pin2focusNode);
                                        },
                                      ),
                                      buildSizeBox(0.0, spaceField),

                                      OtpTextfieldWidget(
                                        textEditingController: controller4,
                                        focus: pin4focusNode,
                                        onChanged: (value){
                                          nextField(value, pin4focusNode, pin3focusNode);
                                          if(controller1.text.toString().trim().isNotEmpty && controller2.text.toString().trim().isNotEmpty && controller3.text.toString().trim().isNotEmpty && controller4.text.toString().trim().isNotEmpty){
                                            PrintLog.printLog(":::Success....");
                                            controller.verifyOtpApi(
                                                context: context,
                                                otp: "${controller1.text.toString().trim()}${controller2.text.toString().trim()}${controller3.text.toString().trim()}${controller4.text.toString().trim()}",
                                                mobNo: widget.mobileNumber.toString().trim()
                                            ).then((value){
                                              // FocusScope.of(context).unfocus();
                                              // if(controller.isError){
                                              //   clearTextField();
                                              // }
                                            });
                                          }
                                        },
                                      ),
                                      buildSizeBox(0.0, spaceField),

                                    ]
                                ),

                                SizedBox(
                                  height: 6.h,
                                ),
                                Text(kVerifyOtpDoNotCode,style: TextStyle(fontFamily: FontFamily.josefinRegular,fontSize: 14,color: Colors.grey),),
                                SizedBox(
                                  height: 2.h,
                                ),
                                _start == 0 ?
                                InkWell(
                                  onTap:onTapResendOtp,
                                  child:
                                  Text(kVerifyOtpResend,style: TextStyle(fontFamily: FontFamily.josefinRegular,fontSize: 14,color: CustomColors.bluearrowcolor),),
                                  // Text(_start.toString(),style: TextStyle(fontFamily: FontFamily.josefinRegular,fontSize: 14,color: CustomColors.bluearrowcolor),),
                                ):
                                SizedBox(
                                  height: 50,
                                  width: Get.width,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        kVerifyOtpOtpReceive,
                                        style: TextStyle(
                                            color: CustomColors.bluearrowcolor, fontSize: 14,fontFamily: FontFamily.josefinRegular),
                                      ),
                                      Text(
                                        _start.toString(),
                                        style: TextStyle(
                                            color: CustomColors.bluearrowcolor,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            fontFamily: FontFamily.josefinRegular
                                        ),
                                      ),
                                      Text(
                                        kSeconds,
                                        style: TextStyle(
                                            color: CustomColors.bluearrowcolor, fontSize: 14,fontFamily: FontFamily.josefinRegular),
                                      ),
                                    ],
                                  ),
                                ),

                                SizedBox(
                                  height: 14.h,
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Image.asset(
                                    str_imgLoginBg,
                                    height: 40.h,
                                  ),
                                ),
                              ],
                            )
                        ),
                      ),
                    ),
                  )

              ),

            ),
            isLoading: controller.isLoading,
          );
        });

  }

  onTapResendOtp(){
    loginCtrl.loginApi(context: context, mobNo: widget.mobileNumber,isResend: true).then((value) {
      _start = 60;
      startTimer();
      clearTextField();
      pin1focusNode.requestFocus();
    });

  }

}