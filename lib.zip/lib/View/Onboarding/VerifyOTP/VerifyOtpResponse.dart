class VerifyOtpApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  VerifyOtpData? data;

  VerifyOtpApiResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  VerifyOtpApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    data = json['data'] != null ? new VerifyOtpData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class VerifyOtpData {
  String? id;
  String? name;
  String? email;
  String? type;
  String? emailVerifiedAt;
  String? emailOtp;
  String? mobileNo;
  String? mobileOtp;
  String? mobileVerifiedAt;
  String? profileImage;
  String? status;
  String? deletedAt;
  String? createdAt;
  String? updatedAt;
  String? token;
  String? city;
  String? address;
  String? aadhaarNo;
  String? aadharImage;

  VerifyOtpData(
      {this.id,
        this.name,
        this.email,
        this.type,
        this.emailVerifiedAt,
        this.emailOtp,
        this.mobileNo,
        this.mobileOtp,
        this.mobileVerifiedAt,
        this.profileImage,
        this.status,
        this.deletedAt,
        this.createdAt,
        this.updatedAt,
        this.token,
        this.city,
        this.address,
        this.aadharImage,
        this.aadhaarNo});

  VerifyOtpData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    name = json['name'] != null ? json['name'].toString():null;
    email = json['email'] != null ? json['email'].toString():null;
    type = json['type'] != null ? json['type'].toString():null;
    emailVerifiedAt = json['email_verified_at'] != null ? json['email_verified_at'].toString():null;
    emailOtp = json['email_otp'] != null ? json['email_otp'].toString():null;
    mobileNo = json['mobile_no'] != null ? json['mobile_no'].toString():null;
    mobileOtp =  json['mobile_otp'] != null ? json['mobile_otp'].toString():null;
    mobileVerifiedAt = json['mobile_verified_at'] != null ? json['mobile_verified_at'].toString():null;
    profileImage = json['profile_image'] != null ? json['profile_image'].toString():null;
    status = json['status'] != null ? json['status'].toString():null;
    deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
    token = json['token'] != null ? json['token'].toString():null;
    city = json['city'] != null ? json['city'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    aadhaarNo = json['aadhar_no'] != null ? json['aadhar_no'].toString():null;
    aadharImage = json['aadhar_image'] != null ? json['aadhar_image'].toString():null;

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['type'] = this.type;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['email_otp'] = this.emailOtp;
    data['mobile_no'] = this.mobileNo;
    data['mobile_otp'] = this.mobileOtp;
    data['mobile_verified_at'] = this.mobileVerifiedAt;
    data['profile_image'] = this.profileImage;
    data['status'] = this.status;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['token'] = this.token;
    data['city'] = this.token;
    data['address'] = this.token;
    data['aadhar_no'] = this.token;
    data['aadhar_image'] = this.aadharImage;

    return data;
  }
}


