// import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
// import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
// import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
// import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
// import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
// import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
// import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomCheckBox.dart';
// import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:intl/intl.dart' show DateFormat;
// import '../../../Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
// import '../../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
// import '../../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
// import '../../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
// import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
// import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
// import '../../Detail/DetailsController.dart';
// import '../LibrarySheetArrangement/SheetArrangementScreen.dart';
// import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart'
//     show CalendarCarousel;
// import 'package:flutter_calendar_carousel/classes/event.dart';
//
// class LibraryBookScheduleScreen extends StatefulWidget {
//   DateTime? currentDate;
//   String? libraryID;
//   bool? isDetail;
//   LibraryBookScheduleScreen({Key? key,required this.isDetail,required this.libraryID, this.currentDate}) : super(key: key);
//
//   @override
//   State<StatefulWidget> createState() { return _LibraryBookScheduleScreenState(); }
// }
//
// class _LibraryBookScheduleScreenState extends State<LibraryBookScheduleScreen> {
//
//   bool isPlanSelected = false;
//
//   /// Current Month
//   DateTime targetDateTime = DateTime.now();
//   /// Current Month
//   String currentMonth = DateFormat.yMMM().format(DateTime.now());
//   /// Selected Date
//   DateTime selectedDate = DateTime.now();
//   /// Max selected date
//   DateTime maxSelectedDate = DateTime.now();
//   /// last selected date
//   DateTime lastSelectionDate = DateTime.now().subtract(const Duration(days: 1));
//
//   DetailController detailCtrl = Get.put(DetailController());
//
//   @override
//   void initState() {
//     Future.delayed(const Duration(milliseconds: 100),(){
//       init();
//     });
//     firstCheckBoxClick();
//     super.initState();
//   }
//
//   Future<void> init()async{
//     if(widget.isDetail != true){
//       detailCtrl.isNetworkError = false;
//       detailCtrl.isEmpty = false;
//       if(await ConnectionValidator().check()){
//         await detailCtrl.getLibraryDetail(context: context,libraryID: widget.libraryID ?? "").then((value) {
//           ///
//           targetDateTime =  detailCtrl.detailData?.currentDate != null ? DateTime.parse(detailCtrl.detailData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
//           selectedDate =    detailCtrl.detailData?.currentDate != null ? DateTime.parse(detailCtrl.detailData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
//           maxSelectedDate = detailCtrl.detailData?.currentDate != null ? DateTime.parse(detailCtrl.detailData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
//           lastSelectionDate = detailCtrl.detailData?.currentDate != null ? DateTime.parse(detailCtrl.detailData?.currentDate ?? "${DateTime.now()}").subtract(const Duration(days: 1)) : DateTime.now().subtract(const Duration(days: 1));
//           currentMonth =   detailCtrl.detailData?.currentDate  != null ? DateFormat.yMMM().format(DateTime.parse(detailCtrl.detailData?.currentDate ?? "${DateTime.now()}")) : DateFormat.yMMM().format(DateTime.now());
//           ///
//         });
//       }else{
//         detailCtrl.isNetworkError = true;
//         setState(() {
//         });
//       }
//     }else{
//       targetDateTime = widget.currentDate != null ? widget.currentDate! : DateTime.now();
//       selectedDate =   widget.currentDate != null ? widget.currentDate! : DateTime.now();
//       maxSelectedDate = widget.currentDate != null ? widget.currentDate! : DateTime.now();
//
//       lastSelectionDate = widget.currentDate != null ? widget.currentDate!.subtract(const Duration(days: 1)) : DateTime.now().subtract(const Duration(days: 1));
//       currentMonth =   widget.currentDate != null ? DateFormat.yMMM().format(widget.currentDate!) : DateFormat.yMMM().format(DateTime.now());
//     }
//     setState(() { });
//   }
//   /// First checkBox checked
//   Future<void> firstCheckBoxClick()async{
//     if(detailCtrl.detailData?.subscriptions != null && detailCtrl.detailData!.subscriptions!.isNotEmpty){
//       bool checked = detailCtrl.detailData!.subscriptions!.any((element) => element.isSelected == true);
//       if(checked){
//         int indexChecked = detailCtrl.detailData!.subscriptions!.indexWhere((element) => element.isSelected == true);
//         detailCtrl.detailData?.subscriptions?[indexChecked].isSelected = true;
//         isPlanSelected = true;
//       }else{
//         detailCtrl.detailData?.subscriptions?[0].isSelected = true;
//         isPlanSelected = true;
//       }
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<DetailController>(
//       init: detailCtrl,
//       builder: (controller) {
//         return LoadScreen(
//           widget: controller.isError ?
//           ErrorScreen(
//             onTap: () {
//               init();
//             },
//           )
//               : controller.isNetworkError ?
//           NoInternetConnectionScreen(
//             onTap: () {
//               init();
//             },
//           )
//               : controller.isEmpty ?
//           EmptyDataScreen(
//             onTap: () {
//               init();
//             },
//             isShowBtn: false,
//             string: kEmptyData,
//           )
//               :
//           SafeArea(
//               child: Scaffold(
//                   backgroundColor: CustomColors.bluearrowcolor,
//                   appBar: CustomAppBar.appBar(
//                     onTap: () {
//                       Get.back();
//                     },
//                     title: controller.detailData?.firmName ?? "",
//                     titleColor: Colors.white,
//                     backgroundColor: CustomColors.bluearrowcolor,
//                     leadingColor: Colors.white,
//                   ),
//                   bottomNavigationBar: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.symmetric(horizontal: 20),
//                         width: Get.width,
//                         decoration: BoxDecoration(
//                           color: CustomColors.whiteColor,
//                           borderRadius: const BorderRadius.only(
//                             topLeft: Radius.circular(40),
//                             topRight: Radius.circular(40),
//                           ),
//                           boxShadow: [
//                             BoxShadow(
//                               color: CustomColors.blackColor.withOpacity(0.3),
//                               offset: const Offset(
//                                 0.0,
//                                 0.0,
//                               ),
//                               blurRadius: 10.0,
//                               spreadRadius: 2.0,
//                             ), //BoxShadow
//                           ],
//                         ),
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           mainAxisSize: MainAxisSize.min,
//                           children: [
//                             controller.detailData?.subscriptions != null && controller.detailData!.subscriptions!.isNotEmpty ?
//                             Column(
//                               mainAxisAlignment: MainAxisAlignment.start,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 buildSizeBox(25.0, 0.0),
//                                 buildHeadingBold(text: kSchedule),
//                                 buildSizeBox(10.0, 0.0),
//                                 Container(
//                                   height: 30,
//                                   width: Get.width,
//                                   margin: const EdgeInsets.only(bottom: 10),
//                                   child: ListView.builder(
//                                       padding: EdgeInsets.zero,
//                                       itemCount: controller.detailData?.subscriptions?.length,
//                                       shrinkWrap: true,
//                                       physics: const ClampingScrollPhysics(),
//                                       scrollDirection: Axis.horizontal,
//                                       itemBuilder: (context,index){
//                                         return Padding(
//                                           padding: const EdgeInsets.only(right: 15.0),
//                                           child: InkWell(
//                                             onTap: (){
//                                               controller.detailData?.subscriptions?.forEach((element) {
//                                                 element.isSelected = false;
//                                               });
//                                               if(controller.detailData?.subscriptions?[index].isSelected == false){
//                                                 controller.detailData?.subscriptions?[index].isSelected = true;
//                                               }else{
//                                                 controller.detailData?.subscriptions?[index].isSelected = false;
//                                               }
//                                               setState(() {
//                                               });
//                                             },
//                                             child: CheckBoxCustomWithText.box(
//                                                 isSelected: controller.detailData?.subscriptions?[index].isSelected ?? false,
//                                                 text: controller.detailData?.subscriptions?[index].name ?? ""
//                                             ),
//                                           ),
//                                           // child: CustomCheckBoxWithText(
//                                           //   value: widget.subscriptions?[index].isSelected ?? false,
//                                           //   label: widget.subscriptions?[index].name ?? "",
//                                           //   space: 8,
//                                           //   radius: 2,
//                                           //   onChanged: (value){
//                                           //
//                                           //   },
//                                           // ),
//                                         );
//                                       }
//                                   ),
//                                 ),
//                                 const Divider(height: 1,color: Colors.grey),
//                               ],
//                             ): const SizedBox.shrink(),
//
//                             buildSizeBox(20.0, 0.0),
//
//                             /// Opening Hours
//                             controller.detailData?.openTime != null && controller.detailData?.openTime != "" ?
//                             Row(
//                               children: [
//                                 buildText1(text: kOpenHour,size: 16),
//                                 buildText1(text: controller.detailData?.openTime ?? "",size: 12,color: CustomColors.greyColor),
//                                 Icon(Icons.remove,color: CustomColors.greyColor,size: 15,),
//                                 buildText1(text: controller.detailData?.closeTime ?? "",size: 12,color: CustomColors.greyColor),
//                               ],
//                             )
//                                 : const SizedBox.shrink(),
//                             buildSizeBox(20.0, 0.0),
//
//                             Container(
//                               padding: const EdgeInsets.only(
//                                   bottom: 15,top: 10,
//                                   left: 20, right: 20
//                               ),
//                               width: Get.width,
//                               height: 80,
//                               // color: CustomColors.whiteColor,
//                               child: ElevatedButton(
//                                 onPressed: () {
//                                   if(controller.detailData?.subscriptions != null && controller.detailData!.subscriptions!.isNotEmpty){
//                                     isPlanSelected = controller.detailData!.subscriptions!.any((element) => element.isSelected == true);
//                                     int index = controller.detailData!.subscriptions!.indexWhere((element) => element.isSelected == true);
//                                     if(isPlanSelected == true){
//                                       // PrintLog.printLog(
//                                       //     "Selected Plan Name: ${widget.subscriptions?[index].name}"
//                                       //     "\nSelected Plan ID: ${widget.subscriptions?[index].id}"
//                                       //     "\nSelected Date: $selectedDate"
//                                       //         "\nEnd Date: ${selectedDate.add(const Duration(days: 30))}"
//                                       //         "\nOpen Time: ${widget.openTime}"
//                                       //         "\nEnd Time: ${widget.closeTime}"
//                                       // );
//
//                                       Get.toNamed(seatArrangementScreenRoute,
//                                           arguments: SeatArrangementScreen(
//                                             floorPlan: controller.detailData?.floorPlan ?? [],
//                                             planName: controller.detailData?.subscriptions?[index].name ?? "",
//                                             planID: controller.detailData?.subscriptions?[index].id ?? "0",
//                                             planAmount: controller.detailData?.subscriptions?[index].amount ?? "0",
//                                             selectedDate: selectedDate,
//                                             selectedEndDate: selectedDate.add(Duration(days: int.parse(controller.detailData?.subscriptions?[index].numberOfDays ?? "0") ?? 0)),
//                                             closeTime: controller.detailData?.closeTime ?? "",
//                                             openTime: controller.detailData?.openTime ?? "",
//                                             libraryName: controller.detailData?.firmName ?? "",
//                                           )
//                                       );
//                                     }else{
//                                       ToastCustom.showToast( msg: kChoosePlanToastString);
//                                     }
//                                   }else{
//                                     ToastCustom.showToast( msg: kNoAnyPlanToastString);
//                                   }
//                                 },
//                                 style: ButtonStyle(
//                                     backgroundColor:
//                                     MaterialStateProperty.all<Color>(
//                                         CustomColors.bluearrowcolor),
//                                     shape: MaterialStateProperty.all<
//                                         RoundedRectangleBorder>(
//                                         RoundedRectangleBorder(
//                                           borderRadius: BorderRadius.circular(90),
//                                         ))),
//                                 child: buildText1(text: kProceedToBookNow,fontFamily: FontFamily.josefinRegular,color: CustomColors.whiteColor,size: 18),
//                               ),
//                             ),
//                           ],
//                         ),
//                       )
//                     ],
//                   ),
//                   body: SingleChildScrollView(
//                     physics: const ClampingScrollPhysics(),
//                     child: Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 15.0),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         mainAxisSize: MainAxisSize.min,
//                         children: <Widget>[
//
//                           /// Header
//                           Container(
//                             margin: const EdgeInsets.only(top: 10.0,bottom: 20.0),
//                             width: Get.width,
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               children: [
//                                 buildText1(text: "Select Date & Time",color: CustomColors.whiteColor,size: 18,fontFamily: FontFamily.josefinBold),
//                                 buildSizeBox(10.0, 0.0),
//                                 Row(
//                                   mainAxisAlignment: MainAxisAlignment.center,
//                                   crossAxisAlignment: CrossAxisAlignment.center,
//                                   children: <Widget>[
//                                     InkWell(
//                                       onTap: (){
//                                         setState(() {
//                                           targetDateTime = DateTime(
//                                               targetDateTime.year, targetDateTime.month - 1);
//                                           currentMonth =
//                                               DateFormat.yMMM().format(targetDateTime);
//                                         });
//                                       },
//                                       child: Padding(
//                                         padding: const EdgeInsets.all(5.0),
//                                         child: Icon(Icons.arrow_back_rounded, color: CustomColors.whiteColor),
//                                       ),
//                                     ),
//                                     buildText1(text: currentMonth,color: CustomColors.whiteColor,fontFamily: FontFamily.josefinRegular,size: 18),
//                                     InkWell(
//                                       onTap: (){
//                                         setState(() {
//                                           targetDateTime = DateTime(
//                                               targetDateTime.year, targetDateTime.month + 1);
//                                           currentMonth =
//                                               DateFormat.yMMM().format(targetDateTime);
//                                         });
//                                       },
//                                       child: Padding(
//                                         padding: const EdgeInsets.all(5.0),
//                                         child: Icon(Icons.arrow_forward_rounded, color: CustomColors.whiteColor,),
//                                       ),
//                                     ),
//
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//
//                           Container(
//                             height: 350,
//                             width: Get.width,
//                             color: Colors.transparent,
//                             padding: const EdgeInsets.only(left: 0.0, right: 0.0, top: 10.0),
//                             child: CalendarCarousel<Event>(
//
//                               todayBorderColor: CustomColors.transparentColor,
//                               daysHaveCircularBorder: true,
//
//                               weekdayTextStyle: TextStyle(color: CustomColors.whiteColor),
//                               daysTextStyle: TextStyle(color: CustomColors.whiteColor ),
//                               weekendTextStyle: TextStyle(color: CustomColors.whiteColor),
//                               todayTextStyle: TextStyle(color: CustomColors.whiteColor),
//                               selectedDayTextStyle: TextStyle(color: CustomColors.bluearrowcolor),
//                               nextDaysTextStyle: TextStyle(color: CustomColors.transparentColor),
//                               prevDaysTextStyle: TextStyle(color: CustomColors.transparentColor),
//                               inactiveDaysTextStyle: TextStyle(color: CustomColors.greyColor,fontSize: 16),
//                               inactiveWeekendTextStyle: TextStyle(color: CustomColors.greyColor),
//
//                               showOnlyCurrentMonthDate: false,
//                               weekFormat: false,
//                               // markedDatesMap: _markedDateMap,
//
//                               selectedDateTime: selectedDate,
//                               targetDateTime: targetDateTime,
//                               customGridViewPhysics: const NeverScrollableScrollPhysics(),
//                               showHeader: false,
//                               selectedDayButtonColor: CustomColors.whiteColor,
//                               selectedDayBorderColor: CustomColors.whiteColor,
//
//                               todayButtonColor: CustomColors.bluearrowcolor,
//
//                               /// User for last date
//                               minSelectedDate: lastSelectionDate,
//                               maxSelectedDate: maxSelectedDate.add(const Duration(days: 360)),
//
//
//                               onCalendarChanged: (DateTime date) {
//                                 setState(() {
//                                   targetDateTime = date;
//                                   currentMonth = DateFormat.yMMM().format(targetDateTime);
//                                 });
//                                 PrintLog.printLog("On change calendar:::::::");
//                               },
//                               onDayLongPressed: (DateTime date) {
//                                 PrintLog.printLog("On long pressed date:::::::$date");
//                               },
//                               onDayPressed: (date, events) {
//                                 setState(() => selectedDate = date);
//                                 DateTime newExpDate = DateFormat("yyyy-MM-dd").parse(date.toString());
//                                 PrintLog.printLog("On Day pressed:::::::${newExpDate.day}");
//                               },
//                             ),
//                           ), //
//                         ],
//                       ),
//                     ),
//                   ))
//           ),
//           isLoading: controller.isLoading,
//         );
//       },
//     );
//
//   }
// }
