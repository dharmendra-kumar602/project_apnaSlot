import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomCheckBox.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import '../../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../../Dashboard/Home/HomeScreen/HomeApiResponse.dart';
import '../../Detail/DetailsController.dart';
import '../LibrarySheetArrangement/SheetArrangementScreen.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart'
    show CalendarCarousel;
import 'package:flutter_calendar_carousel/classes/event.dart';

class NewLibraryBookScheduleScreen extends StatefulWidget {
  DateTime? currentDate;
  String? libraryID;
  bool? isDetail;
  HomeData? homeData;
  List<HomeData>? detailsListData;
  int? currentIndex;

  NewLibraryBookScheduleScreen({Key? key,required this.currentIndex,required this.detailsListData,this.homeData,required this.isDetail,required this.libraryID, this.currentDate}) : super(key: key);

  @override
  State<StatefulWidget> createState() { return _NewLibraryBookScheduleScreenState(); }
}

class _NewLibraryBookScheduleScreenState extends State<NewLibraryBookScheduleScreen> {

  bool isPlanSelected = false;
  String subStartTime = "";
  String subCloseTime = "";
  String planDuration = "";
  String planPrice = "";

  /// Current Month
  DateTime targetDateTime = DateTime.now();
  /// Current Month
  String currentMonth = DateFormat.yMMM().format(DateTime.now());
  /// Selected Date
  DateTime selectedDate = DateTime.now();
  /// Max selected date
  DateTime maxSelectedDate = DateTime.now();
  /// last selected date
  DateTime lastSelectionDate = DateTime.now().subtract(const Duration(days: 1));

  DetailController detailCTRL = Get.put(DetailController());


  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100),(){
      init();
    });
    firstCheckBoxClick();
    super.initState();
  }

  Future<void> init()async{
    detailCTRL.detailsListData = widget.detailsListData;
    targetDateTime =  widget.homeData?.currentDate != null ? DateTime.parse(widget.homeData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
    selectedDate =    widget.homeData?.currentDate != null ? DateTime.parse(widget.homeData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
    maxSelectedDate = widget.homeData?.currentDate != null ? DateTime.parse(widget.homeData?.currentDate ?? "${DateTime.now()}") : DateTime.now();
    lastSelectionDate = widget.homeData?.currentDate != null ? DateTime.parse(widget.homeData?.currentDate ?? "${DateTime.now()}").subtract(const Duration(days: 1)) : DateTime.now().subtract(const Duration(days: 1));
    currentMonth =   widget.homeData?.currentDate  != null ? DateFormat.yMMM().format(DateTime.parse(widget.homeData?.currentDate ?? "${DateTime.now()}")) : DateFormat.yMMM().format(DateTime.now());
    planDuration =  detailCTRL.detailsListData?[widget.currentIndex ?? 0].subscriptions?.first.numberOfDays ?? "";
    planPrice = detailCTRL.detailsListData?[widget.currentIndex ?? 0].subscriptions?.first.amount?.toStringAsFixed(0) ?? "0";
    // ((element) { 
    //   planDuration = element.numberOfDays ?? "";
    //   planPrice = element.amount?.toStringAsFixed(0).toString() ?? "";
    // });
    // detailCTRL.detailsListData?[widget.currentIndex ?? 0].subscriptions?.forEach((element) { 
    //   planPrice = element.amount?.toStringAsFixed(0).toString() ?? "";
    // });
    setState(() { });
  }
  /// First checkBox checked
  Future<void> firstCheckBoxClick()async{
    if(widget.homeData?.subscriptions != null && widget.homeData!.subscriptions!.isNotEmpty){
      subStartTime =  widget.homeData?.subscriptions?.first.startTime ?? "";
        subCloseTime = widget.homeData?.subscriptions?.first.closeTime ?? "";
      bool checked = widget.homeData!.subscriptions!.any((element) => element.isSelected == true);
      if(checked){
        int indexChecked = widget.homeData!.subscriptions!.indexWhere((element) => element.isSelected == true);
        widget.homeData?.subscriptions?[indexChecked].isSelected = true;
        isPlanSelected = true;
        subStartTime =  widget.homeData?.subscriptions?[indexChecked].startTime ?? "";
        subCloseTime = widget.homeData?.subscriptions?[indexChecked].closeTime ?? "";
      }else{
        widget.homeData?.subscriptions?[0].isSelected = true;
        isPlanSelected = true;
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder<DetailController>(
      init: detailCTRL,
      builder: (controller) {
        return LoadScreen(
          widget: controller.isError ?
          ErrorScreen(
            onTap: () {
              init();
            },
          )
              : controller.isNetworkError ?
          NoInternetConnectionScreen(
            onTap: () {
              init();
            },
          )
              : controller.isEmpty ?
          EmptyDataScreen(
            onTap: () {
              init();
            },
            isShowBtn: false,
            string: kEmptyData,
          )
              :
          SafeArea(
              child: Scaffold(
                  backgroundColor: CustomColors.bluearrowcolor,
                  appBar: CustomAppBar.appBar(
                    onTap: () {
                      Get.back();
                    },
                    title: controller.detailsListData?[widget.currentIndex ?? 0].firmName ?? "",
                    titleColor: Colors.white,
                    backgroundColor: CustomColors.bluearrowcolor,
                    leadingColor: Colors.white,
                  ),
                  bottomNavigationBar: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        width: Get.width,
                        decoration: BoxDecoration(
                          color: CustomColors.whiteColor,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(40),
                            topRight: Radius.circular(40),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: CustomColors.blackColor.withOpacity(0.3),
                              offset: const Offset(
                                0.0,
                                0.0,
                              ),
                              blurRadius: 10.0,
                              spreadRadius: 2.0,
                            ), //BoxShadow
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            controller.detailsListData?[widget.currentIndex ?? 0].subscriptions != null && controller.detailsListData![widget.currentIndex ?? 0].subscriptions!.isNotEmpty ?
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                buildSizeBox(25.0, 0.0),
                                buildHeadingBold(text: kSchedule),
                                buildSizeBox(10.0, 0.0),
                                Container(
                                  height: 30,
                                  width: Get.width,
                                  margin: const EdgeInsets.only(bottom: 10),
                                  child: ListView.builder(
                                      padding: EdgeInsets.zero,
                                      itemCount: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?.length,
                                      shrinkWrap: true,
                                      physics: const ClampingScrollPhysics(),
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (context,index){
                                        return Padding(
                                          padding: const EdgeInsets.only(right: 15.0),
                                          child: InkWell(
                                            onTap: (){
                                              controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?.forEach((element) {
                                                element.isSelected = false;
                                              });
                                              if(controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].isSelected == false){
                                                controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].isSelected = true;
                                              }else{
                                                controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].isSelected = false;
                                              }
                                              
                                              subStartTime = controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].startTime ?? "";
                                              subCloseTime = controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].closeTime ?? "";
                                              planDuration = controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].numberOfDays ?? "0";
                                              planPrice = controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].amount?.toStringAsFixed(0) ?? "0";
                                              setState(() {
                                              });
                                              print('subStartTime : $subStartTime \nsubCloseTime : $subCloseTime');
                                            },
                                            child: CheckBoxCustomWithText.box(
                                                isSelected: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].isSelected ?? false,
                                                text: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].name ?? ""
                                            ),
                                          ),
                                          // child: CustomCheckBoxWithText(
                                          //   value: widget.subscriptions?[index].isSelected ?? false,
                                          //   label: widget.subscriptions?[index].name ?? "",
                                          //   space: 8,
                                          //   radius: 2,
                                          //   onChanged: (value){
                                          //
                                          //   },
                                          // ),
                                        );
                                      }
                                  ),
                                ),
                                const Divider(height: 1,color: Colors.grey),
                              ],
                            ): const SizedBox.shrink(),

                            buildSizeBox(20.0, 0.0),

                            /// Opening Hours
                            controller.detailsListData?[widget.currentIndex ?? 0].openTime != null && controller.detailsListData?[widget.currentIndex ?? 0].openTime != "" ?
                            Row(
                              children: [
                                buildText1(text: 'Schedule timing : ',size: 16),
                                buildText1(text: subStartTime,size: 12,color: CustomColors.greyColor),
                                Icon(Icons.remove,color: CustomColors.greyColor,size: 15,),
                                buildText1(text: subCloseTime,size: 12,color: CustomColors.greyColor),
                              ],
                            )
                                : const SizedBox.shrink(),
                            buildSizeBox(10.0, 0.0),

                            planDuration.isNotEmpty ?
                            buildHeading(
                              text: "${'Plan Duration : '}$planDuration days",//'Booking Date : 1 July - 30July',
                              color: CustomColors.bluearrowcolor,
                            ) : const SizedBox.shrink(),
                            planDuration.isNotEmpty ? buildSizeBox(10.0, 0.0) : const SizedBox.shrink(),

                            planPrice.isNotEmpty ?
                            buildHeading(text: '$kPrice₹$planPrice') : const SizedBox.shrink(),

                            ///Proceed to book now
                            Container(
                              padding: const EdgeInsets.only(
                                  bottom: 15,top: 10,
                                  left: 20, right: 20
                              ),
                              width: Get.width,
                              height: 80,
                              // color: CustomColors.whiteColor,
                              child: ElevatedButton(
                                onPressed: () {
                                  if(controller.detailsListData?[widget.currentIndex ?? 0].subscriptions != null && controller.detailsListData![widget.currentIndex ?? 0].subscriptions!.isNotEmpty){
                                    isPlanSelected = controller.detailsListData![widget.currentIndex ?? 0].subscriptions!.any((element) => element.isSelected == true);
                                    int index = controller.detailsListData![widget.currentIndex ?? 0].subscriptions!.indexWhere((element) => element.isSelected == true);
                                    if(isPlanSelected == true){
                                      // PrintLog.printLog(
                                      //     "Selected Plan Name: ${widget.subscriptions?[index].name}"
                                      //     "\nSelected Plan ID: ${widget.subscriptions?[index].id}"
                                      //     "\nSelected Date: $selectedDate"
                                      //         "\nEnd Date: ${selectedDate.add(const Duration(days: 30))}"
                                      //         "\nOpen Time: ${widget.openTime}"
                                      //         "\nEnd Time: ${widget.closeTime}"
                                      // );

                                      Get.toNamed(seatArrangementScreenRoute,
                                          arguments: SeatArrangementScreen(
                                            subcriptionId: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].id ?? "",
                                            // floorPlan: controller.detailsListData?[widget.currentIndex ?? 0].floorPlan ?? [],
                                            planName: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].name ?? "",
                                            planID: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].id ?? "0",
                                            planAmount: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].amount?.toStringAsFixed(0) ?? "0",
                                            selectedDate: selectedDate,
                                            selectedEndDate: selectedDate.add(Duration(days: int.parse(controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].numberOfDays ?? "0"))),
                                            closeTime: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].closeTime ?? "",
                                            openTime: controller.detailsListData?[widget.currentIndex ?? 0].subscriptions?[index].startTime ?? "",
                                            libraryName: controller.detailsListData?[widget.currentIndex ?? 0].firmName ?? "",
                                            libraryID: controller.detailsListData?[widget.currentIndex ?? 0].id ?? "",
                                            subStartTime: subStartTime,
                                            subCloseTime: subCloseTime,
                                          )
                                      );
                                    }else{
                                      ToastCustom.showToast( msg: kChoosePlanToastString);
                                    }
                                  }else{
                                    ToastCustom.showToast( msg: kNoAnyPlanToastString);
                                  }
                                },
                                style: ButtonStyle(
                                    backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        CustomColors.bluearrowcolor),
                                    shape: MaterialStateProperty.all<
                                        RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(90),
                                        ))),
                                child: buildText1(text: kProceedToBookNow,fontFamily: FontFamily.josefinRegular,color: CustomColors.whiteColor,size: 18),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  body: SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[

                          /// Header
                          Container(
                            margin: const EdgeInsets.only(top: 10.0,bottom: 20.0),
                            width: Get.width,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                buildText1(text: "Select Date & Time",color: CustomColors.whiteColor,size: 18,fontFamily: FontFamily.josefinBold),
                                buildSizeBox(10.0, 0.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          targetDateTime = DateTime(
                                              targetDateTime.year, targetDateTime.month - 1);
                                          currentMonth =
                                              DateFormat.yMMM().format(targetDateTime);
                                        });
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Icon(Icons.arrow_back_rounded, color: CustomColors.whiteColor),
                                      ),
                                    ),
                                    buildText1(text: currentMonth,color: CustomColors.whiteColor,fontFamily: FontFamily.josefinRegular,size: 18),
                                    InkWell(
                                      onTap: (){
                                        setState(() {
                                          targetDateTime = DateTime(
                                              targetDateTime.year, targetDateTime.month + 1);
                                          currentMonth =
                                              DateFormat.yMMM().format(targetDateTime);
                                        });
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Icon(Icons.arrow_forward_rounded, color: CustomColors.whiteColor,),
                                      ),
                                    ),

                                  ],
                                ),
                              ],
                            ),
                          ),

                          Container(
                            height: 350,
                            width: Get.width,
                            color: Colors.transparent,
                            padding: const EdgeInsets.only(left: 0.0, right: 0.0, top: 10.0),
                            child: CalendarCarousel<Event>(

                              todayBorderColor: CustomColors.transparentColor,
                              daysHaveCircularBorder: true,

                              weekdayTextStyle: TextStyle(color: CustomColors.whiteColor),
                              daysTextStyle: TextStyle(color: CustomColors.whiteColor ),
                              weekendTextStyle: TextStyle(color: CustomColors.whiteColor),
                              todayTextStyle: TextStyle(color: CustomColors.whiteColor),
                              selectedDayTextStyle: TextStyle(color: CustomColors.bluearrowcolor),
                              nextDaysTextStyle: TextStyle(color: CustomColors.transparentColor),
                              prevDaysTextStyle: TextStyle(color: CustomColors.transparentColor),
                              inactiveDaysTextStyle: TextStyle(color: CustomColors.greyColor,fontSize: 16),
                              inactiveWeekendTextStyle: TextStyle(color: CustomColors.greyColor),

                              showOnlyCurrentMonthDate: false,
                              weekFormat: false,
                              // markedDatesMap: _markedDateMap,

                              selectedDateTime: selectedDate,
                              targetDateTime: targetDateTime,
                              customGridViewPhysics: const NeverScrollableScrollPhysics(),
                              showHeader: false,
                              selectedDayButtonColor: CustomColors.whiteColor,
                              selectedDayBorderColor: CustomColors.whiteColor,

                              todayButtonColor: CustomColors.bluearrowcolor,

                              /// User for last date
                              minSelectedDate: lastSelectionDate,
                              maxSelectedDate: maxSelectedDate.add(const Duration(days: 360)),


                              onCalendarChanged: (DateTime date) {
                                setState(() {
                                  targetDateTime = date;
                                  currentMonth = DateFormat.yMMM().format(targetDateTime);
                                });
                                PrintLog.printLog("On change calendar:::::::");
                              },
                              onDayLongPressed: (DateTime date) {
                                PrintLog.printLog("On long pressed date:::::::$date");
                              },
                              onDayPressed: (date, events) {
                                setState(() => selectedDate = date);
                                DateTime newExpDate = DateFormat("yyyy-MM-dd").parse(date.toString());
                                PrintLog.printLog("On Day pressed:::::::${newExpDate.day}");
                              },
                            ),
                          ), //
                        ],
                      ),
                    ),
                  ))
          ),
          isLoading: controller.isLoading,
        );
      },
    );

  }
}
