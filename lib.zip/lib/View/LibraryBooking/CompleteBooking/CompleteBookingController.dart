

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import '../../../Controller/ApiController/ApiController.dart';
import '../../../Controller/ApiController/WebConstant.dart';
import '../../../Controller/Helper/Camera/CameraScreen.dart';
import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/ImagePicker/ImagePicker.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../../Controller/Helper/TextController/TextValidator/TextValidator.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../../../main.dart';
import 'package:dio/dio.dart' as dio;
import '../../Dashboard/Dashboard/DashboardScreen.dart';
import 'completeBookingResponse.dart';
import 'package:intl/intl.dart' show DateFormat;



class CompleteBookingController extends GetxController{

  ApiController apiCtrl = ApiController();

  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;

  ImagePickerController? imagePicker = Get.put(ImagePickerController());

  TextEditingController nameCT = TextEditingController();
  TextEditingController emailCT = TextEditingController();
  TextEditingController mobileCT = TextEditingController();
  TextEditingController dobCT = TextEditingController();
  TextEditingController addressCT = TextEditingController();
  TextEditingController cityCT = TextEditingController();
  TextEditingController aadhaarNumberCT = TextEditingController();

  FocusNode nameFC = FocusNode();
  FocusNode emailFC = FocusNode();
  FocusNode mobileFC = FocusNode();
  FocusNode dobFC = FocusNode();
  FocusNode addressFC = FocusNode();
  FocusNode cityFC  = FocusNode();
  FocusNode aadhaarNumberFC = FocusNode();

  Future textFieldClear()async{
  nameCT.clear();
  emailCT.clear();
  mobileCT.clear();
  dobCT.clear();
  addressCT.clear();
  cityCT.clear();
  aadhaarNumberCT.clear();
  }

  Future textFieldDispose()async{
    nameCT.dispose();
    emailCT.dispose();
    mobileCT.dispose();
    dobCT.dispose();
    addressCT.dispose();
    cityCT.dispose();
    aadhaarNumberCT.dispose();
  }

  String? profileImage;
  String? adhaarImage;
  double? spacingTextField = 10.0;
  bool isChecked = true;
  bool aadhaarImagePicked = false;

  bool isName = false;
  bool isEmail = false;
  bool isValidEmail = false;
  bool isMobile = false;
  bool isDOB = false;
  bool isValidMobile = false;
  bool isAddress = false;
  bool isCity = false;
  bool isAadhaar = false;
  bool isValidAadhaar = false;

  String? selectedDate;
  String? selectedDateTimeStamp;
  final DateFormat formatter = DateFormat("dd-MM-yyyy");

  Future<void> init()async{
    nameCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName) ?? "";
    emailCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userEmail) ?? "";
    mobileCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userMobileNo) ?? "";
    addressCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAddress) ?? "";
    cityCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userCityName) ?? "";
    aadhaarNumberCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAadhaarNumber) ?? "";
    profileImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg) ?? "";
    adhaarImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAadhaarImage);
    update();
  }

  void getImage(source, BuildContext context) {
    imagePicker?.getImage(source, context, "profileImage").then((value) => update());
  }
  
    void getImage2(source, BuildContext context) {
    imagePicker?.getImage(source, context, "documentImage").then((value) {
      aadhaarImagePicked = true;
      adhaarImage = imagePicker?.documentImage?.path;
      update();
    });
  }

  ///Custom Image Picker New
  Future<void> addImage({required BuildContext context})async {
    aadhaarImagePicked = true;
    Navigator.pop(context);
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const CameraScreen()
          )).then((value) async {
        if (value != null) {
          print(value);
          // final imageData = File(value);
          adhaarImage = value;
          print("Captured Image : $adhaarImage");
          update();
        }
      });
      update();
  }

  Future<CompleteBookingResponse?> completeBooking({required BuildContext context, required XFile? profileImage, required String name, required String email, required String mobileNumber, required String address, required String city, required String aadhaarNumber, required String bookingNumber, String? aadhaarImage, String? type, String? dob}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);


    dio.FormData formData = dio.FormData.fromMap({
      "booking_number":bookingNumber,
      "name":name,
      "email":email,
      "mobile_no":mobileNumber,
      "dob":dob,
      "address":address,
      "city":city,
      "aadhar_no":aadhaarNumber,
      "type":type
    });

    if(profileImage != null && profileImage.path != "" ){
      PrintLog.printLog("Profile image update ::::::${profileImage.path}");
      formData.files.add(MapEntry("profile_image", await dio.MultipartFile.fromFile(profileImage.path, filename:profileImage.path.split('/').last)));
    }

     if(aadhaarImage != null && aadhaarImage != "" ){
      PrintLog.printLog("Aadhaar image update ::::::${aadhaarImage}");
      formData.files.add(MapEntry("aadhaar_image", await dio.MultipartFile.fromFile(aadhaarImage, filename:aadhaarImage.split('/').last)));
    }

    PrintLog.printLog('Update fields :::::: ${formData.fields}');
    PrintLog.printLog('Update files  :::::: ${formData.files}');


    String url = WebApiConstant.API_URL_COMPLETE_BOOKING;

    await apiCtrl.completeBookingApi(context:context,url: url, formData: formData,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              changeLoadingValue(false);
              changeSuccessValue(true);
              Get.offAllNamed(dashboardScreenRoute,arguments: DashboardScreen(screenIndex: 2));
              ToastCustom.showToast( msg: result.message ?? "");

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              ToastCustom.showToast( msg: result.message ?? "");
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            ToastCustom.showToast( msg: result.message ?? "");
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }

  /// Check Fill User Details
  checkDetails({required BuildContext context, required String bookingNumber})async{
    isName = TxtValidation.normalTextField(nameCT);
    isEmail = TxtValidation.normalTextField(emailCT);
    isValidEmail = TxtValidation.validateEmailTextField(emailCT);
    isMobile = TxtValidation.normalTextField(mobileCT);
    isDOB = TxtValidation.normalTextField(dobCT);
    isValidMobile = TxtValidation.validateMobileTextField(mobileCT);
    isAddress = TxtValidation.normalTextField(addressCT);
    isCity = TxtValidation.normalTextField(cityCT);
    isAadhaar = TxtValidation.normalTextField(aadhaarNumberCT);
    isValidAadhaar = TxtValidation.validateAadhaarTextField(aadhaarNumberCT);


    if(!isName && !isMobile && !isValidMobile && !isDOB && !isEmail && !isValidEmail && !isAddress && !isCity && !isAadhaar && !isValidAadhaar){
      PrintLog.printLog(":::Success...$profileImage.\n or: $adhaarImage");
      if((profileImage != null && profileImage != "" && profileImage != "null" || imagePicker?.profileImage != null) && adhaarImage != null && adhaarImage != "" && adhaarImage != "null"){
        await completeBooking(
            context: context,
            name: nameCT.text.toString().trim(),
            mobileNumber: mobileCT.text.toString().trim(),
            email: emailCT.text.toString().trim(),
            city: cityCT.text.toString().trim(),
            address: addressCT.text.toString().trim(),
            aadhaarNumber: aadhaarNumberCT.text.toString().trim(),
            profileImage: imagePicker?.profileImage != null ? imagePicker!.profileImage:null,
            aadhaarImage: adhaarImage != null && aadhaarImagePicked == true ? adhaarImage ?? "":null,
            bookingNumber: bookingNumber,
            type: isChecked == true ? "self" : "other",
            dob: selectedDate ?? ""
        ).then((value) {
          aadhaarImagePicked = false;
        });
      } else{
        
        if((profileImage == null || profileImage == "" || profileImage == "null") && imagePicker?.profileImage == null){
          ToastCustom.showToast( msg: kUpdatePictureToastMsg);
        } else if((adhaarImage == null || adhaarImage == "" || adhaarImage == "null") && imagePicker?.documentImage == null) {
          ToastCustom.showToast( msg: kUpdateYourAadharImage);
        }
      }
    }
    update();
  }

  /// On Tap Open Calender
  Future<void> openTapCalender({required BuildContext context}) async {
    showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1975),
        lastDate: DateTime(2050),
        builder: (BuildContext? context, Widget? child) {
          return Theme(
            data: ThemeData.light().copyWith(
              colorScheme: ColorScheme.light(primary: CustomColors.bluearrowcolor),
              buttonTheme: const ButtonThemeData(textTheme: ButtonTextTheme.primary),
            ),
            child: child ?? const SizedBox.shrink(),
          );
        }).then((pickedDate) {

      if (pickedDate == null) {
        return;
      }else{
        selectedDate = formatter.format(pickedDate);
        dobCT.text = selectedDate ?? "";
        PrintLog.printLog("selected Date : $selectedDate");
        update();
      }
    });
  }



  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

  //  Future<void> saveUserData({UpdateProfileData? data})async{
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userId, variableValue: data?.id.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userName, variableValue: data?.name.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userEmail, variableValue: data?.email.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userMobileNo, variableValue: data?.mobileNo.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userProfileImg, variableValue: data?.profileImage.toString() ?? "");
  //    ///
  //    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userCityId, variableValue: data?.userCityId.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userCityName, variableValue: data?.city.toString() ?? "");
  //    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userStateId, variableValue: data?.userStateId.toString() ?? "");
  //    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userStateName, variableValue: data?.userStateName.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAadhaarNumber, variableValue: data?.aadharNo.toString() ?? "");
  //    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAddress, variableValue: data?.address.toString() ?? "");
  //  }
}

