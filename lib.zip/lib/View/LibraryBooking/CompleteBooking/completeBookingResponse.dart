// class CompleteBookingResponse {
//   bool? error;
//   String? message;
//   int? errorCode;
//   String? state;
//   CompleteBookingData? data;
//
//   CompleteBookingResponse(
//       {this.error, this.message, this.errorCode, this.state, this.data});
//
//   CompleteBookingResponse.fromJson(Map<String, dynamic> json) {
//     error = json['error'];
//     message = json['message'];
//     errorCode = json['errorCode'];
//     state = json['state'];
//     data = json['data'] != null ? new CompleteBookingData.fromJson(json['data']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['error'] = this.error;
//     data['message'] = this.message;
//     data['errorCode'] = this.errorCode;
//     data['state'] = this.state;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     return data;
//   }
// }
//
// class CompleteBookingData {
//   String? id;
//   String? name;
//   String? email;
//   String? mobileNo;
//   String? profileImage;
//   String? userType;
//   String? gender;
//   String? age;
//   String? city;
//   String? aadharNo;
//   String? address;
//
//
//   CompleteBookingData(
//       {this.id,
//         this.name,
//         this.email,
//         this.mobileNo,
//         this.profileImage,
//         this.userType,
//         this.age,
//         this.city,
//         this.aadharNo,
//         this.address,});
//
//   CompleteBookingData.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     name = json['name'] != null ? json['name'].toString():null;
//     email = json['email'] != null ? json['email'].toString():null;
//     mobileNo = json['mobile_no'] != null ? json['mobile_no'].toString():null;
//     profileImage = json['profile_image'] != null ? json['profile_image'].toString():null;
//     userType = json['user_type'] != null ? json['user_type'].toString():null;
//     gender = json['gender'] != null ? json['gender'].toString():null;
//     age = json['age'] != null ? json['age'].toString():null;
//     city = json['city'] != null ? json['city'].toString():null;
//     aadharNo = json['aadhar_no'] != null ? json['aadhar_no'].toString():null;
//     address = json['address'] != null ? json['address'].toString():null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['name'] = this.name;
//     data['email'] = this.email;
//     data['mobile_no'] = this.mobileNo;
//     data['profile_image'] = this.profileImage;
//     data['user_type'] = this.userType;
//     data['gender'] = this.gender;
//     data['age'] = this.age;
//     data['city'] = this.city;
//     data['aadhar_no'] = this.aadharNo;
//     data['address'] = this.address;
//     return data;
//   }
// }


class CompleteBookingResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;

  CompleteBookingResponse(
      {this.error, this.message, this.errorCode, this.state});

  CompleteBookingResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    return data;
  }
}

