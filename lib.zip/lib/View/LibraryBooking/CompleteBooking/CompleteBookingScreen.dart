
import 'dart:io';

import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../Controller/Helper/ImagePicker/ImagePicker.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../../Controller/Helper/TextController/TextValidator/TextValidator.dart';
import '../../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../Controller/WidgetController/TextField/CustomTextField.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import 'CompleteBookingController.dart';


class CompleteBookingScreen extends StatefulWidget{
  String bookingNumber;
  CompleteBookingScreen({Key? key,required this.bookingNumber}) : super(key: key);

  @override
  State<CompleteBookingScreen> createState() => _CompleteBookingScreenState();

}

class _CompleteBookingScreenState extends State<CompleteBookingScreen> {

  CompleteBookingController compBookCT = Get.put(CompleteBookingController());

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100),(){
      compBookCT.init();
    });
    super.initState();
  }

  @override
  void dispose() {
    compBookCT.imagePicker?.profileImage = null;
    compBookCT.imagePicker?.documentImage = null;
    Get.delete<CompleteBookingController>();
    // compBookCT.textFieldClear();
    // compBookCT.textFieldDispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return GetBuilder<CompleteBookingController>(
          init: compBookCT,
          builder: (controller) {
          return WillPopScope(
            onWillPop: () async => false,
            child: SafeArea(
              child: GestureDetector(
                  onTap: () => FocusScope.of(context).unfocus(),
                  child: LoadScreen(
                    widget: Scaffold(
                        appBar: PreferredSize(
                          preferredSize: const Size.fromHeight(70),
                          child: CustomAppBar.appBar(
                            title: kCompleteBookingTitle,
                            onTap: () {
                              Get.back();
                            },centerTitle: true,
                            showBackBtn: false
                          ),
                        ),
                        backgroundColor: CustomColors.whiteColor,
                        bottomNavigationBar: Padding(
                          padding: const EdgeInsets.only(left: 20,right: 20,bottom: 20),
                          child: ButtonCustom(
                            onPress: () async {
                              await controller.checkDetails(context: context,bookingNumber: widget.bookingNumber);
                            }, text: kCompleteBooking,
                            buttonWidth: Get.width,
                            buttonHeight: 50.0,
                          ),
                        ),
                        body: SingleChildScrollView(
                          child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                children: [
                                  Container(
                                    // width: 100,
                                    padding: const EdgeInsets.all(3),
                                    decoration: BoxDecoration(
                                      color: CustomColors.bluearrowcolor.withOpacity(0.05),
                                      borderRadius: BorderRadius.circular(5)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [

                                        //Self
                                        Row(
                                          children: [
                                            Checkbox(
                                                value: controller.isChecked,
                                                checkColor: CustomColors.whiteColor,
                                                activeColor:  CustomColors.bluearrowcolor,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2)),
                                                visualDensity: const VisualDensity(horizontal: -4,vertical: -2),
                                                onChanged: (val){
                                                  controller.imagePicker?.profileImage = null;
                                                  controller.isChecked = !controller.isChecked;
                                                  controller.init();
                                                  setState(() {});
                                                }),
                                            buildText1(text: 'Self',size: 16)
                                          ],
                                        ),

                                        //Other
                                        Row(
                                          children: [
                                            Checkbox(
                                                value: controller.isChecked == false,
                                                checkColor: CustomColors.whiteColor,
                                                activeColor:  CustomColors.bluearrowcolor,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2)),
                                                visualDensity: const VisualDensity(horizontal: -4,vertical: -2),
                                                onChanged: (val){
                                                  controller.isChecked = !controller.isChecked;
                                                  if(controller.isChecked == false){
                                                    controller.nameCT.text = "";
                                                    controller.emailCT.text = "";
                                                    controller.mobileCT.text = "";
                                                    controller.addressCT.text = "";
                                                    controller.cityCT.text = "";
                                                    controller.aadhaarNumberCT.text = "";
                                                    controller.profileImage = null;
                                                    controller.imagePicker?.profileImage = null;
                                                    // controller.imagePicker?.documentImage = null;
                                                    controller.adhaarImage = null;
                                                    controller.aadhaarImagePicked = false;
                                                    controller.selectedDate = "";
                                                  }
                                                  setState(() {});
                                                }),
                                            buildText1(text: 'Other',size: 16)
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  buildSizeBox(20.0, 0.0),

                                  ///Profile image
                                  Container(
                                    color: CustomColors.whiteColor,
                                    padding: const EdgeInsets.only(top: 0.0, bottom: 30.0),
                                    child: Center(
                                      child: SizedBox(
                                          height: 90,
                                          width: 90,
                                          child: Stack(
                                            children: [
                                              SizedBox(
                                                height: 90,
                                                width: 90,
                                                child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(50.0),
                                                    child: controller.imagePicker?.profileImage != null ?
                                                    Image.file(File(controller.imagePicker?.profileImage?.path ?? ""),fit: BoxFit.fitWidth)
                                                        : controller.profileImage != "null" && controller.profileImage != null && controller.profileImage.toString() != "" ?
                                                    ImageHelper(
                                                      image: controller.profileImage ?? "",
                                                      height: MediaQuery.of(context).size.shortestSide,
                                                      width: MediaQuery.of(context).size.width,
                                                      fit: BoxFit.fitWidth,
                                                      alignment: Alignment.center,
                                                    ) : DefaultWidget.image(),
                                                ),
                                              ),
                                              Positioned(
                                                bottom: 0.0,
                                                right: 0.0,
                                                child: Container(
                                                  height: 30,
                                                  width: 30,
                                                  decoration: const BoxDecoration(
                                                      borderRadius: BorderRadius.all(
                                                          Radius.circular(20)),
                                                      color: Colors.white),
                                                  child: InkWell(
                                                    onTap: () {
                                                      _showPicker(context);
                                                    },
                                                    child: CircleAvatar(
                                                      radius: 18,
                                                      backgroundColor: Colors.white,
                                                      child: Icon(
                                                        Icons.camera_alt,
                                                        color: CustomColors.bluearrowcolor,
                                                        size: 17,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )),
                                    ),
                                  ),
                                  Visibility(
                                    visible: widget.bookingNumber != "null" && widget.bookingNumber != "",
                                      child: Column(
                                        children: [
                                          buildText1(text:"$kBookingNumber${widget.bookingNumber}",fontFamily: FontFamily.josefinBold),
                                          buildSizeBox(20.0, 0.0)
                                        ],
                                      )
                                  ),

                                  /// Name ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isName ? true:false,
                                      errorText: controller.isName ? kEnterName:'',
                                      controller: controller.nameCT,
                                      focus: controller.nameFC,
                                      hintText: kName,
                                      inputType: TextInputType.name,
                                      maxLength: 50
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// Email ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isEmail ? true : controller.isValidEmail ? true:false,
                                      errorText: controller.isEmail ? kEnterEmail : controller.isValidEmail ?kEnterValidEmail:"",
                                      controller: controller.emailCT,
                                      focus: controller.emailFC,
                                      hintText: kEmail,
                                      inputType: TextInputType.emailAddress,
                                      maxLength: 60
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// Mobile Number ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isMobile ? true : controller.isValidMobile ? true:false,
                                      errorText: controller.isMobile ? kEnterMobileNo : controller.isValidMobile ? kEnterValidMobileNo: '',
                                      controller: controller.mobileCT,
                                      focus: controller.mobileFC,
                                      hintText: kMobileNumber,
                                      inputType: TextInputType.phone,
                                      maxLength: 10
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// DOB
                                  CustomTextField(
                                      readOnly: true,
                                      isError: controller.isDOB ? true : false,
                                      errorText: controller.isDOB ? 'Enter date of birth' : '',
                                      controller: controller.dobCT,
                                      focus: controller.dobFC,
                                      hintText: 'Date of Birth',
                                      inputType: TextInputType.phone,
                                      maxLength: 10,
                                      onTap: (){
                                        controller.openTapCalender(context: context);
                                      },
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// Address ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isAddress ? true:false,
                                      errorText: controller.isAddress ? kEnterAddress:'',
                                      controller: controller.addressCT,
                                      focus: controller.addressFC,
                                      hintText: kAddress,
                                      inputType: TextInputType.streetAddress,
                                      maxLength: 250
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// City ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isCity ? true:false,
                                      errorText: controller.isCity ? kEnterCity:'',
                                      controller: controller.cityCT,
                                      focus: controller.cityFC,
                                      hintText: kCity,
                                      inputType: TextInputType.streetAddress,
                                      maxLength: 50
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// Aadhaar Number ctrl
                                  CustomTextField(
                                      readOnly: false,
                                      isError: controller.isAadhaar ? true : controller.isValidAadhaar ? true:false,
                                      errorText: controller.isAadhaar ? kEnterAadhaar : controller.isValidAadhaar ? kEnterValidAadhaar:"",
                                      controller: controller.aadhaarNumberCT,
                                      focus: controller.aadhaarNumberFC,
                                      hintText: kAadhaar,
                                      inputType: TextInputType.phone,
                                      maxLength: 12
                                  ),
                                  buildSizeBox(controller.spacingTextField, 0.0),

                                  /// Aadhaar Image Upload
                                  Container(
                                   padding: const EdgeInsets.symmetric(horizontal: 10),
                                   alignment: Alignment.centerLeft,
                                   height: 54,
                                   width: Get.width,
                                   color: CustomColors.greyColorLight,
                                   child: Row(
                                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                     children: [
                                       Expanded(child: buildText1(text: controller.imagePicker?.documentImage != null ? "Aadhaar Image Uploaded" : controller.adhaarImage != null && controller.adhaarImage != "" && controller.adhaarImage != "null" ? "Aadhaar Image Uploaded" : "Upload Aadhaar Image",size: 16,color: CustomColors.greyColor)),

                                       controller.adhaarImage != null && controller.adhaarImage != "" && controller.adhaarImage != 'null' ?
                                       Stack(
                                         children: [
                                           Container(
                                            padding: const EdgeInsets.all(3),
                                           clipBehavior: Clip.antiAlias,
                                           height: 45,
                                           width: 45,
                                           decoration: BoxDecoration(
                                             borderRadius: BorderRadius.circular(5)
                                           ),
                                           child: ClipRRect(
                                             borderRadius: BorderRadius.circular(5.0),
                                             child: 
                                             controller.adhaarImage != 'null' && controller.adhaarImage != null && controller.adhaarImage.toString() != "" && controller.aadhaarImagePicked == true ?
                                             Image.file(File(controller.adhaarImage ?? ""),fit: BoxFit.fitWidth)
                                              : controller.adhaarImage != 'null' && controller.adhaarImage != null && controller.adhaarImage.toString() != "" ? 
                                               ImageHelper(
                                                image: controller.adhaarImage ?? "",
                                                height: MediaQuery.of(context).size.shortestSide,
                                                width: MediaQuery.of(context).size.width,
                                                fit: BoxFit.fitWidth,
                                                alignment: Alignment.center,
                                              ) : DefaultWidget.image()),
                                         ),

                                         Positioned(
                                           right: 0,
                                           top: 0,
                                           child: InkWell(
                                             onTap: (){
                                               if(controller.imagePicker?.documentImage != null && controller.imagePicker?.documentImage != ""){
                                                controller.imagePicker?.documentImage = null;
                                               } else if(controller.adhaarImage != null && controller.adhaarImage != "" && controller.adhaarImage != "null"){
                                                controller.adhaarImage = null;
                                               }
                                               print('Image Removed');
                                               setState(() {});
                                             },
                                             child: Container(
                                               decoration: BoxDecoration(
                                               color: Colors.red[400],
                                               borderRadius: BorderRadius.circular(50.0)
                                           ),
                                               child: Icon(Icons.close,color: CustomColors.whiteColor,size: 15,))))
                                         ]
                                       ) :
                                       InkWell(
                                        onTap: (){
                                          _showPickerForAadhaarImage(context);
                                        },
                                        child: Icon(Icons.attachment_outlined,color: CustomColors.greyColor,size: 35,))
                                     ],
                                   ),
                                    )

                                ],
                              )
                          ),
                        )
                    ),
                    isLoading: controller.isLoading,
                  )
              ),
            ),
          );
        }
        );
  }

  /// Show Image Picker BottomSheet
  void _showPicker(context)async {
    await showModalBottomSheet(
        backgroundColor: CustomColors.transparentColor,
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
            child: Container(
                height: 110,
                padding: const EdgeInsets.only(top: 15,bottom: 15),
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pop("gallery");
                      },
                      child: Container(
                          padding: const EdgeInsets.only(top: 8,bottom: 8,left: 35,right: 35),
                          decoration: BoxDecoration(
                              border: Border.all(color: CustomColors.bluearrowcolor,width: 2),
                              borderRadius: const BorderRadius.all(Radius.circular(10))
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.photo_library,color: CustomColors.bluearrowcolor,size: 30,),
                              buildText1(text: kGallery),
                            ],
                          )
                      ),
                    ),
                    buildSizeBox(0.0,30.0),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pop("camera");
                      },
                      child: Container(
                          padding: const EdgeInsets.only(top: 8,bottom: 8,left: 35,right: 35),
                          decoration: BoxDecoration(
                              border: Border.all(color: CustomColors.bluearrowcolor,width: 2),
                              borderRadius: const BorderRadius.all(Radius.circular(10))
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.photo_camera,color: CustomColors.bluearrowcolor,size: 30,),
                              buildText1(text: kCamera),
                            ],
                          )
                      ),
                    ),
                  ],
                )
            ),
          );
        }).then((value) {
      if(value.toString().toLowerCase() == "gallery"){
         compBookCT.getImage("Gallery", context);
      }else if(value.toString().toLowerCase() == "camera"){
         compBookCT.getImage("Camera", context);
      }
    });
  }

   /// Show Image Picker BottomSheet
  void _showPickerForAadhaarImage(context) {
    showModalBottomSheet(
        backgroundColor: CustomColors.transparentColor,
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
            child: Container(
                height: 110,
                padding: const EdgeInsets.only(top: 15,bottom: 15),
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pop("gallery");
                      },
                      child: Container(
                          padding: const EdgeInsets.only(top: 8,bottom: 8,left: 35,right: 35),
                          decoration: BoxDecoration(
                              border: Border.all(color: CustomColors.bluearrowcolor,width: 2),
                              borderRadius: const BorderRadius.all(Radius.circular(10))
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.photo_library,color: CustomColors.bluearrowcolor,size: 30,),
                              buildText1(text: kGallery),
                            ],
                          )
                      ),
                    ),
                    buildSizeBox(0.0,30.0),
                    InkWell(
                      onTap: () {
                        compBookCT.addImage(context: context);
                        // Navigator.of(context).pop("camera");
                      },
                      child: Container(
                          padding: const EdgeInsets.only(top: 8,bottom: 8,left: 35,right: 35),
                          decoration: BoxDecoration(
                              border: Border.all(color: CustomColors.bluearrowcolor,width: 2),
                              borderRadius: const BorderRadius.all(Radius.circular(10))
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.photo_camera,color: CustomColors.bluearrowcolor,size: 30,),
                              buildText1(text: kCamera),
                            ],
                          )
                      ),
                    ),
                  ],
                )
            ),
          );
        }).then((value) {
      if(value.toString().toLowerCase() == "gallery"){
        compBookCT.getImage2("Gallery", context);
      }else if(value.toString().toLowerCase() == "camera"){
        compBookCT.getImage2("Camera", context);
      }
    });
  }

  
}


// if(profileImage == null || profileImage == "" || profileImage == "null" || imagePicker?.profileImage == null ){
//         ToastCustom.showToast( msg: kUpdatePictureToastMsg);
//         print('Profile image : ${profileImage}');
//       } else if(imagePicker?.documentImage == null){
//         ToastCustom.showToast( msg: 'Upload aadhar image');
//         print('Aadhar image : ${imagePicker?.documentImage}');
//       } else {
//         await compBookCT?.completeBooking(
//             context: context,
//             name: nameCT.text.toString().trim(),
//             mobileNumber: mobileCT.text.toString().trim(),
//             email: emailCT.text.toString().trim(),
//             city: cityCT.text.toString().trim(),
//             address: addressCT.text.toString().trim(),
//             aadhaarNumber: aadhaarNumberCT.text.toString().trim(),
//             profileImage: imagePicker?.profileImage != null ? imagePicker!.profileImage:null,
//             aadhaarImage: imagePicker?.documentImage != null ? imagePicker!.documentImage:null,
//           bookingNumber: widget.bookingNumber
//         );
//       }