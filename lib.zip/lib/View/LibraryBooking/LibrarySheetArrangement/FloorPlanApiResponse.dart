class FloorPlanApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  List<FloorPlanData>? data;

  FloorPlanApiResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  FloorPlanApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    if (json['data'] != null) {
      data = <FloorPlanData>[];
      json['data'].forEach((v) {
        data!.add(new FloorPlanData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class FloorPlanData {
  String? floorImage;
  String? floorName;
  String? floorPlanHeight;
  String? floorPlanWidth;
  List<Tables>? tables;

  FloorPlanData(
      {this.floorImage,
      this.floorName,
      this.floorPlanHeight,
      this.floorPlanWidth,
      this.tables});

  FloorPlanData.fromJson(Map<String, dynamic> json) {
    floorImage = json['floor_image'] != null ? json['floor_image'].toString():null;
    floorName = json['floor_name'] != null ? json['floor_name'].toString():null;
    floorPlanHeight = json['floor_plan_height'] != null ? json['floor_plan_height'].toString():null;
    floorPlanWidth = json['floor_plan_width'] != null ? json['floor_plan_width'].toString():null;
    if (json['tables'] != null) {
      tables = <Tables>[];
      json['tables'].forEach((v) {
        tables!.add(new Tables.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['floor_image'] = this.floorImage;
    data['floor_name'] = this.floorName;
    data['floor_plan_height'] = this.floorPlanHeight;
    data['floor_plan_width'] = this.floorPlanWidth;
    if (this.tables != null) {
      data['tables'] = this.tables!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Tables {
  String? seatId;
  String? seatName;
  String? xCord;
  String? yCord;
  String? alignment;
  String? isBooked;

  Tables(
      {this.seatId,
      this.seatName,
      this.xCord,
      this.yCord,
      this.alignment,
      this.isBooked});

  Tables.fromJson(Map<String, dynamic> json) {
    seatId = json['seat_id'] != null ? json['seat_id'].toString():null;
    seatName = json['seat_name'] != null ? json['seat_name'].toString():null;
    xCord = json['x_cord'] != null ? json['x_cord'].toString():null;
    yCord = json['y_cord'] != null ? json['y_cord'].toString():null;
    alignment = json['alignment'] != null ? json['alignment'].toString():null;
    isBooked = json['is_booked'] != null ? json['is_booked'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['seat_id'] = this.seatId;
    data['seat_name'] = this.seatName;
    data['x_cord'] = this.xCord;
    data['y_cord'] = this.yCord;
    data['alignment'] = this.alignment;
    data['is_booked'] = this.isBooked;
    return data;
  }
}




// class FloorPlanApiResponse {
//   bool? error;
//   String? message;
//   int? errorCode;
//   String? state;
//   FloorPlanData? data;

//   FloorPlanApiResponse(
//       {this.error, this.message, this.errorCode, this.state, this.data});

//   FloorPlanApiResponse.fromJson(Map<String, dynamic> json) {
//     error = json['error'];
//     message = json['message'];
//     errorCode = json['errorCode'];
//     state = json['state'];
//     data = json['data'] != null ? new FloorPlanData.fromJson(json['data']) : null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['error'] = this.error;
//     data['message'] = this.message;
//     data['errorCode'] = this.errorCode;
//     data['state'] = this.state;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     return data;
//   }
// }

// class FloorPlanData {
//   String? id;
//   String? bookingNumber;
//   String? customerId;
//   String? libraryId;
//   String? subscriptionId;
//   String? libraryTableId;
//   String? createdBy;
//   String? promoCode;
//   String? amount;
//   String? startDate;
//   String? endDate;
//   String? bookingDate;
//   String? paymentDate;
//   String? paymentMode;
//   String? paymentReferenceNo;
//   String? userInfo;
//   String? paidStatus;
//   String? createdAt;
//   String? updatedAt;
//   String? floorPlanHeight;
//   String? floorPlanWidth;
//   Subscription? subscription;
//   List<FloorPlan>? floorPlan;
//   List<GetFloors>? getFloors;
//   Subscription? getSelfSubscriptions;

//   FloorPlanData(
//       {this.id,
//       this.bookingNumber,
//       this.customerId,
//       this.libraryId,
//       this.subscriptionId,
//       this.libraryTableId,
//       this.createdBy,
//       this.promoCode,
//       this.amount,
//       this.startDate,
//       this.endDate,
//       this.bookingDate,
//       this.paymentDate,
//       this.paymentMode,
//       this.paymentReferenceNo,
//       this.userInfo,
//       this.paidStatus,
//       this.createdAt,
//       this.updatedAt,
//       this.floorPlanHeight,
//       this.floorPlanWidth,
//       this.subscription,
//       this.floorPlan,
//       this.getFloors,
//       this.getSelfSubscriptions});

//   FloorPlanData.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     bookingNumber = json['booking_number'] != null ? json['booking_number'].toString():null;
//     customerId = json['customer_id'] != null ? json['customer_id'].toString():null;
//     libraryId = json['library_id'] != null ? json['library_id'].toString():null;
//     subscriptionId = json['subscription_id'] != null ? json['subscription_id'].toString():null;
//     libraryTableId = json['library_table_id'] != null ? json['library_table_id'].toString():null;
//     createdBy = json['created_by'] != null ? json['created_by'].toString():null;
//     promoCode = json['promo_code'] != null ? json['promo_code'].toString():null;
//     amount = json['amount'] != null ? json['amount'].toString():null;
//     startDate = json['start_date'] != null ? json['start_date'].toString():null;
//     endDate = json['end_date'] != null ? json['end_date'].toString():null;
//     bookingDate = json['booking_date'] != null ? json['booking_date'].toString():null;
//     paymentDate = json['payment_date'] != null ? json['payment_date'].toString():null;
//     paymentMode = json['payment_mode'] != null ? json['payment_mode'].toString():null;
//     paymentReferenceNo = json['payment_reference_no'] != null ? json['payment_reference_no'].toString():null;
//     userInfo = json['user_info'] != null ? json['user_info'].toString():null;
//     paidStatus = json['paid_status'] != null ? json['paid_status'].toString():null;
//     createdAt = json['created_at'] != null ? json['created_at'].toString():null;
//     updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
//     floorPlanHeight = json['floor_plan_height'] != null ? json['floor_plan_height'].toString():null;
//     floorPlanWidth = json['floor_plan_width'] != null ? json['floor_plan_width'].toString():null;
//     subscription = json['subscription'] != null
//         ? new Subscription.fromJson(json['subscription'])
//         : null;
//     if (json['floor_plan'] != null) {
//       floorPlan = <FloorPlan>[];
//       json['floor_plan'].forEach((v) {
//         floorPlan!.add(new FloorPlan.fromJson(v));
//       });
//     }
//     if (json['get_floors'] != null) {
//       getFloors = <GetFloors>[];
//       json['get_floors'].forEach((v) {
//         getFloors!.add(new GetFloors.fromJson(v));
//       });
//     }
//     getSelfSubscriptions = json['get_self_subscriptions'] != null
//         ? new Subscription.fromJson(json['get_self_subscriptions'])
//         : null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['booking_number'] = this.bookingNumber;
//     data['customer_id'] = this.customerId;
//     data['library_id'] = this.libraryId;
//     data['subscription_id'] = this.subscriptionId;
//     data['library_table_id'] = this.libraryTableId;
//     data['created_by'] = this.createdBy;
//     data['promo_code'] = this.promoCode;
//     data['amount'] = this.amount;
//     data['start_date'] = this.startDate;
//     data['end_date'] = this.endDate;
//     data['booking_date'] = this.bookingDate;
//     data['payment_date'] = this.paymentDate;
//     data['payment_mode'] = this.paymentMode;
//     data['payment_reference_no'] = this.paymentReferenceNo;
//     data['user_info'] = this.userInfo;
//     data['paid_status'] = this.paidStatus;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     data['floor_plan_height'] = this.floorPlanHeight;
//     data['floor_plan_width'] = this.floorPlanWidth;
//     if (this.subscription != null) {
//       data['subscription'] = this.subscription!.toJson();
//     }
//     if (this.floorPlan != null) {
//       data['floor_plan'] = this.floorPlan!.map((v) => v.toJson()).toList();
//     }
//     if (this.getFloors != null) {
//       data['get_floors'] = this.getFloors!.map((v) => v.toJson()).toList();
//     }
//     if (this.getSelfSubscriptions != null) {
//       data['get_self_subscriptions'] = this.getSelfSubscriptions!.toJson();
//     }
//     return data;
//   }
// }

// class Subscription {
//   String? id;
//   String? libraryId;
//   String? name;
//   String? amount;
//   String? numberOfSeats;
//   String? numberOfDays;
//   String? startTime;
//   String? closeTime;
//   String? status;
//   String? deletedAt;
//   String? createdAt;
//   String? updatedAt;

//   Subscription(
//       {this.id,
//       this.libraryId,
//       this.name,
//       this.amount,
//       this.numberOfSeats,
//       this.numberOfDays,
//       this.startTime,
//       this.closeTime,
//       this.status,
//       this.deletedAt,
//       this.createdAt,
//       this.updatedAt});

//   Subscription.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     libraryId = json['library_id'] != null ? json['library_id'].toString():null;
//     name = json['name'] != null ? json['name'].toString():null;
//     amount = json['amount'] != null ? json['amount'].toString():null;
//     numberOfSeats = json['number_of_seats'] != null ? json['number_of_seats'].toString():null;
//     numberOfDays = json['number_of_days'] != null ? json['number_of_days'].toString():null;
//     startTime = json['start_time'] != null ? json['start_time'].toString():null;
//     closeTime = json['close_time'] != null ? json['close_time'].toString():null;
//     status = json['status'] != null ? json['status'].toString():null;
//     deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
//     createdAt = json['created_at'] != null ? json['created_at'].toString():null;
//     updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['library_id'] = this.libraryId;
//     data['name'] = this.name;
//     data['amount'] = this.amount;
//     data['number_of_seats'] = this.numberOfSeats;
//     data['number_of_days'] = this.numberOfDays;
//     data['start_time'] = this.startTime;
//     data['close_time'] = this.closeTime;
//     data['status'] = this.status;
//     data['deleted_at'] = this.deletedAt;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     return data;
//   }
// }

// class FloorPlan {
//   String? floorImage;
//   String? floorName;
//   String? floorPlanHeight;
//   String? floorPlanWidth;
//   List<Tables>? tables;

//   FloorPlan(
//       {this.floorImage,
//       this.floorName,
//       this.floorPlanHeight,
//       this.floorPlanWidth,
//       this.tables});

//   FloorPlan.fromJson(Map<String, dynamic> json) {
//     floorImage = json['floor_image'] != null ? json['floor_image'].toString():null;
//     floorName = json['floor_name'] != null ? json['floor_name'].toString():null;
//     floorPlanHeight = json['floor_plan_height'] != null ? json['floor_plan_height'].toString():null;
//     floorPlanWidth = json['floor_plan_width'] != null ? json['floor_plan_width'].toString():null;
//     if (json['tables'] != null) {
//       tables = <Tables>[];
//       json['tables'].forEach((v) {
//         tables!.add(new Tables.fromJson(v));
//       });
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['floor_image'] = this.floorImage;
//     data['floor_name'] = this.floorName;
//     data['floor_plan_height'] = this.floorPlanHeight;
//     data['floor_plan_width'] = this.floorPlanWidth;
//     if (this.tables != null) {
//       data['tables'] = this.tables!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

// class Tables {
//   String? seatId;
//   String? seatName;
//   String? xCord;
//   String? yCord;
//   String? alignment;
//   String? isBooked;

//   Tables(
//       {this.seatId,
//       this.seatName,
//       this.xCord,
//       this.yCord,
//       this.alignment,
//       this.isBooked});

//   Tables.fromJson(Map<String, dynamic> json) {
//     seatId = json['seat_id'] != null ? json['seat_id'].toString():null;
//     seatName = json['seat_name'] != null ? json['seat_name'].toString():null;
//     xCord = json['x_cord'] != null ? json['x_cord'].toString():null;
//     yCord = json['y_cord'] != null ? json['y_cord'].toString():null;
//     alignment = json['alignment'] != null ? json['alignment'].toString():null;
//     isBooked = json['is_booked'] != null ? json['is_booked'].toString():null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['seat_id'] = this.seatId;
//     data['seat_name'] = this.seatName;
//     data['x_cord'] = this.xCord;
//     data['y_cord'] = this.yCord;
//     data['alignment'] = this.alignment;
//     data['is_booked'] = this.isBooked;
//     return data;
//   }
// }

// class GetFloors {
//   String? id;
//   String? libraryId;
//   String? name;
//   String? topChair;
//   String? bottomChair;
//   String? leftChair;
//   String? rightChair;
//   String? table;
//   String? floorImage;
//   String? status;
//   String? createdAt;
//   String? updatedAt;
//   String? deletedAt;
//   List<GetTables>? getTables;

//   GetFloors(
//       {this.id,
//       this.libraryId,
//       this.name,
//       this.topChair,
//       this.bottomChair,
//       this.leftChair,
//       this.rightChair,
//       this.table,
//       this.floorImage,
//       this.status,
//       this.createdAt,
//       this.updatedAt,
//       this.deletedAt,
//       this.getTables});

//   GetFloors.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     libraryId = json['library_id'] != null ? json['library_id'].toString():null;
//     name = json['name'] != null ? json['name'].toString():null;
//     topChair = json['top_chair'] != null ? json['top_chair'].toString():null;
//     bottomChair = json['bottom_chair'] != null ? json['bottom_chair'].toString():null;
//     leftChair = json['left_chair'] != null ? json['left_chair'].toString():null;
//     rightChair = json['right_chair'] != null ? json['right_chair'].toString():null;
//     table = json['table'] != null ? json['table'].toString():null;
//     floorImage = json['floor_image'] != null ? json['floor_image'].toString():null;
//     status = json['status'] != null ? json['status'].toString():null;
//     createdAt = json['created_at'] != null ? json['created_at'].toString():null;
//     updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
//     deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
//     if (json['get_tables'] != null) {
//       getTables = <GetTables>[];
//       json['get_tables'].forEach((v) {
//         getTables!.add(new GetTables.fromJson(v));
//       });
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['library_id'] = this.libraryId;
//     data['name'] = this.name;
//     data['top_chair'] = this.topChair;
//     data['bottom_chair'] = this.bottomChair;
//     data['left_chair'] = this.leftChair;
//     data['right_chair'] = this.rightChair;
//     data['table'] = this.table;
//     data['floor_image'] = this.floorImage;
//     data['status'] = this.status;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     data['deleted_at'] = this.deletedAt;
//     if (this.getTables != null) {
//       data['get_tables'] = this.getTables!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

// class GetTables {
//   String? id;
//   String? libraryId;
//   String? floorId;
//   String? alignment;
//   String? tableNo;
//   String? topCordinate;
//   String? leftCordinate;
//   String? status;
//   String? deletedAt;
//   String? createdAt;
//   String? updatedAt;
//   GetBookingStatus? getBookingStatus;

//   GetTables(
//       {this.id,
//       this.libraryId,
//       this.floorId,
//       this.alignment,
//       this.tableNo,
//       this.topCordinate,
//       this.leftCordinate,
//       this.status,
//       this.deletedAt,
//       this.createdAt,
//       this.updatedAt,
//       this.getBookingStatus});

//   GetTables.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     libraryId = json['library_id'] != null ? json['library_id'].toString():null;
//     floorId = json['floor_id'] != null ? json['floor_id'].toString():null;
//     alignment = json['alignment'] != null ? json['alignment'].toString():null;
//     tableNo = json['table_no'] != null ? json['table_no'].toString():null;
//     topCordinate = json['top_cordinate'] != null ? json['top_cordinate'].toString():null;
//     leftCordinate = json['left_cordinate'] != null ? json['left_cordinate'].toString():null;
//     status = json['status'] != null ? json['status'].toString():null;
//     deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
//     createdAt = json['created_at'] != null ? json['created_at'].toString():null;
//     updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
//     getBookingStatus = json['get_booking_status'] != null
//         ? new GetBookingStatus.fromJson(json['get_booking_status'])
//         : null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['library_id'] = this.libraryId;
//     data['floor_id'] = this.floorId;
//     data['alignment'] = this.alignment;
//     data['table_no'] = this.tableNo;
//     data['top_cordinate'] = this.topCordinate;
//     data['left_cordinate'] = this.leftCordinate;
//     data['status'] = this.status;
//     data['deleted_at'] = this.deletedAt;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     if (this.getBookingStatus != null) {
//       data['get_booking_status'] = this.getBookingStatus!.toJson();
//     }
//     return data;
//   }
// }

// class GetBookingStatus {
//   String? id;
//   String? bookingNumber;
//   String? customerId;
//   String? libraryId;
//   String? subscriptionId;
//   String? libraryTableId;
//   String? createdBy;
//   String? promoCode;
//   String? amount;
//   String? startDate;
//   String? endDate;
//   String? bookingDate;
//   String? paymentDate;
//   String? paymentMode;
//   String? paymentReferenceNo;
//   String? userInfo;
//   String? paidStatus;
//   String? createdAt;
//   String? updatedAt;

//   GetBookingStatus(
//       {this.id,
//       this.bookingNumber,
//       this.customerId,
//       this.libraryId,
//       this.subscriptionId,
//       this.libraryTableId,
//       this.createdBy,
//       this.promoCode,
//       this.amount,
//       this.startDate,
//       this.endDate,
//       this.bookingDate,
//       this.paymentDate,
//       this.paymentMode,
//       this.paymentReferenceNo,
//       this.userInfo,
//       this.paidStatus,
//       this.createdAt,
//       this.updatedAt});

//   GetBookingStatus.fromJson(Map<String, dynamic> json) {
//     id = json['id'] != null ? json['id'].toString():null;
//     bookingNumber = json['booking_number'] != null ? json['booking_number'].toString():null;
//     customerId = json['customer_id'] != null ? json['customer_id'].toString():null;
//     libraryId = json['library_id'] != null ? json['library_id'].toString():null;
//     subscriptionId = json['subscription_id'] != null ? json['subscription_id'].toString():null;
//     libraryTableId = json['library_table_id'] != null ? json['library_table_id'].toString():null;
//     createdBy = json['created_by'] != null ? json['created_by'].toString():null;
//     promoCode = json['promo_code'] != null ? json['promo_code'].toString():null;
//     amount = json['amount'] != null ? json['amount'].toString():null;
//     startDate = json['start_date'] != null ? json['start_date'].toString():null;
//     endDate = json['end_date'] != null ? json['end_date'].toString():null;
//     bookingDate = json['booking_date'] != null ?  json['booking_date'].toString():null;
//     paymentDate = json['payment_date'] != null ? json['payment_date'].toString():null;
//     paymentMode = json['payment_mode'] != null ? json['payment_mode'].toString():null;
//     paymentReferenceNo = json['payment_reference_no'] != null ? json['payment_reference_no'].toString():null;
//     userInfo = json['user_info'] != null ? json['user_info'].toString():null;
//     paidStatus = json['paid_status'] != null ? json['paid_status'].toString():null;
//     createdAt = json['created_at'] != null ? json['created_at'].toString():null;
//     updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['booking_number'] = this.bookingNumber;
//     data['customer_id'] = this.customerId;
//     data['library_id'] = this.libraryId;
//     data['subscription_id'] = this.subscriptionId;
//     data['library_table_id'] = this.libraryTableId;
//     data['created_by'] = this.createdBy;
//     data['promo_code'] = this.promoCode;
//     data['amount'] = this.amount;
//     data['start_date'] = this.startDate;
//     data['end_date'] = this.endDate;
//     data['booking_date'] = this.bookingDate;
//     data['payment_date'] = this.paymentDate;
//     data['payment_mode'] = this.paymentMode;
//     data['payment_reference_no'] = this.paymentReferenceNo;
//     data['user_info'] = this.userInfo;
//     data['paid_status'] = this.paidStatus;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     return data;
//   }
// }
