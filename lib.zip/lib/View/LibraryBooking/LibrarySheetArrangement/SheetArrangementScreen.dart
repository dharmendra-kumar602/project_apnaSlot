import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/Button/ButtonCustom.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:custom_clock/analog_clock.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../Dashboard/Home/HomeScreen/HomeApiResponse.dart';
import '../../Detail/DetailsApiResponse.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import 'package:intl/intl.dart' show DateFormat;
import '../coupon_code/coupon_code_response.dart';
import '../coupon_code/coupon_code_screen.dart';
import 'SubmitBookingController.dart';




class SeatArrangementScreen extends StatefulWidget {
  // List<HomeLibraryFloorPlan>? floorPlan;
  String? closeTime;
  String? openTime;
  String? planName;
  String? planID;
  String? planAmount;
  String? libraryName;
  String? libraryID;
  String? subStartTime;
  String? subCloseTime;
  String? subcriptionId;
  DateTime? selectedDate;
  DateTime? selectedEndDate;

  SeatArrangementScreen({Key? key,required this.libraryID,required this.libraryName,required this.planID,required this.selectedEndDate,required this.selectedDate,required this.planAmount,required this.planName,required this.closeTime,required this.openTime, required this.subCloseTime, required this.subStartTime, required this.subcriptionId}) : super(key: key);

  @override
  State<StatefulWidget> createState() { return _SeatArrangementScreenState(); }

}

class _SeatArrangementScreenState extends State<SeatArrangementScreen> {

  String? startDay;
  String? startMonth;
  String? endDay;
  String? endMonth;

  String? selectedFloorName;
  String? selectedSheetName;
  String? selectedSheetId;

  ApplyCouponCodeApiResponse? couponCode;

  SubmitBookingController submitCTRL = Get.put(SubmitBookingController());


  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100),()async{
      await submitCTRL.floorPlan(startDate: widget.selectedDate ?? DateTime.now(), context: context, subscriptionId: widget.subcriptionId ?? "", libraryId: widget.libraryID ?? "").then((value) {
        init();
      });
    
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> init()async{

    startDay = widget.selectedDate?.day.toString() ?? "";
    startMonth = DateFormat("MMM").format(widget.selectedDate!);

    endDay = widget.selectedEndDate?.subtract(const Duration(days: 1)).day.toString() ?? "";
    endMonth = DateFormat("MMM").format(widget.selectedEndDate!.subtract(const Duration(days: 1)));

    print('Subcription ID : ${widget.subcriptionId} \nLibrary ID : ${widget.libraryID} \nStartDate : ${widget.selectedDate}');

    setState(() {});

    PrintLog.printLog(
      "floorPlan length: ${submitCTRL.floorPlanData?.length}"
      "\nClose Time: ${widget.closeTime}"
      "\nOpen Time: ${widget.openTime}"
      "\nPlan Name: ${widget.planName}"
      "\nPlan ID: ${widget.planID}"
      "\nPlan Amount: ${widget.planAmount}"
      "\nLibrary Name: ${widget.libraryName}"
      "\nSelected Start Date: ${widget.selectedDate}"
      "\nSelected End Date: ${widget.selectedEndDate}"
    );

  }

  @override
  Widget build(BuildContext context){
    return GetBuilder<SubmitBookingController>(
        init: submitCTRL,
        builder: (controller) {
          return LoadScreen(
            widget: Scaffold(
              backgroundColor: Colors.white,
              appBar: CustomAppBar.appBar(
                onTap: (){
                  Get.back();
                },
                title: widget.libraryName ?? "",
              ),
              bottomNavigationBar: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Card(
                    margin: EdgeInsets.zero,
                    elevation: 50,
                    child: Container(
                      width: Get.width,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            offset: Offset(
                              0.0,
                              0.0,
                            ),
                            blurRadius: 10.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          selectedSheetName != null && selectedSheetName.toString() != "" ?
                          Column(
                              children: [
                                buildSizeBox(10.0, 0.0),
                                buildHeadingBold(text: '$kSeat : $selectedSheetName'),
                                buildSizeBox(10.0, 0.0),

                                /// Price

                                couponCode != null && couponCode?.discountAmount != null && couponCode?.discountAmount != "" ?
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    buildHeadingBold(text: kPrice),
                                    buildHeadingBoldCutPrice(text: widget.planAmount ?? ""),
                                    buildHeadingBold(text: " ${(int.parse(widget.planAmount.toString()) - int.parse(couponCode?.discountAmount.toString() ?? "0.0"))}"),
                                    buildHeadingBold(text: '/${widget.planName}'),
                                  ],
                                ):buildHeadingBold(text: '$kPrice₹${widget.planAmount}/${widget.planName}'),

                                buildSizeBox(couponCode != null ? 0.0:10.0, 0.0),
                                couponCode != null && couponCode?.promoCode != null && couponCode?.promoCode != "" ?
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    buildText1(text: "Applied ${couponCode?.promoCode} Coupon"),
                                    IconButton(
                                        iconSize: 20,
                                        onPressed: (){
                                          couponCode = null;
                                          setState(() { });
                                        },
                                        icon: Icon(Icons.clear,color: CustomColors.redColor,)
                                    )
                                  ],
                                ) :
                                InkWell(
                                  onTap: (){
                                    Get.toNamed(couponCodeScreenRoute,arguments: CouponCodesScreen(libraryID: widget.libraryID ?? "",subscriptionID: widget.planID ?? "",))?.then((value) {
                                      if(value != null){
                                        couponCode = value;
                                        setState(() { });
                                      }
                                    });
                                    // Navigator.push(
                                    //     context,
                                    //     MaterialPageRoute(
                                    //         builder: (context) => const CouponCodesScreen()));
                                  },
                                  child: Container(height:20,width:150,color:CustomColors.transparentColor,child: Center(child: buildText1(text: kApplyCoupon))) ,
                                )

                              ]
                          ): const SizedBox(),

                          buildSizeBox(10.0, 0.0),

                          /// Payment
                          Container(
                            width: Get.width,
                            height: 50,
                            margin: const EdgeInsets.only(left: 20,right: 20,bottom: 20),
                            child: ElevatedButton(
                              onPressed: () async {
                                if(selectedSheetName != null && selectedSheetName.toString() != ""){
                                        await controller.submitBooking(context: context,subscriptionId: widget.planID.toString(),tableId: selectedSheetId.toString(),isRenew: false,couponCode: couponCode?.promoCode ?? "",startDate: widget.selectedDate)
                                            .then((value) {
                                        PrintLog.printLog("controller isSuccess value ;${controller.isSuccess}");
                                      });
                                }else{
                                  ToastCustom.showToast( msg: kChooseYourSheet);
                                }
                              },
                              style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all<Color>(
                                      CustomColors.bluearrowcolor),
                                  shape:
                                  MaterialStateProperty.all<RoundedRectangleBorder>(
                                      RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(90),
                                      ))),
                              child: buildText1(text: kPayment,size: 18,color: CustomColors.whiteColor),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
              body: controller.floorPlanData != null ? 
              SingleChildScrollView(
                child: Column(
                  children: [
                    /// Watch or Booking Date
                    Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        width: Get.width,
                        color: CustomColors.greyColorLight,
                        child: Column(
                          children: [
                            SizedBox(
                              width: Get.width,
                              height: 60,
                              child: AnalogClock(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 5.0, color: CustomColors.bluearrowcolor),
                                    color: Colors.transparent,
                                    shape: BoxShape.circle),
                                tickColor: CustomColors.bluearrowcolor,
                                showSecondHand: false,
                                showDigitalClock: true,
                                showNumbers: false,
                                showAllNumbers: false,
                                minuteHandColor: const Color.fromRGBO(75, 182, 170, 1),
                                hourHandColor: CustomColors.bluearrowcolor,
                                datetime: DateFormat('dd-MM-yyyy h:mm: a', 'en_US').parseLoose('01-11-2020 ${widget.openTime}'), //
                              ),
                            ),
                            SizedBox(
                                width: Get.width,
                                height: 55,
                                // color: Colors.blue,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    buildHeading(
                                      text: "$kBookingDate${startDay ?? ""}  ${startMonth ?? ""} - ${endDay ?? ""}  ${endMonth ?? ""}",//'Booking Date : 1 July - 30July',
                                      color: CustomColors.bluearrowcolor,
                                    ),
                                    buildSizeBox(10.0, 0.0),

                                    buildHeading(
                                      text: "Schedule timing : ${widget.subStartTime ?? ""} - ${widget.subCloseTime ?? ""}",//'Booking Date : 1 July - 30July',
                                      color: CustomColors.bluearrowcolor,
                                    ),
                                  ],
                                ))
                          ],
                        )
                    ),


                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      width: Get.width,
                      // height: 200,
                      color: Colors.white,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildSizeBox(20.0, 0.0),
                          buildHeading(text: kWhereDoYouSit),
                          buildSizeBox(10.0, 0.0),

                          /// Where do you want to sit?
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      borderRadius:
                                      const BorderRadius.all(Radius.circular(5)),
                                      color: CustomColors.greyColorLight,
                                    ),
                                  ),
                                  buildSizeBox(10.0, 10.0),

                                  buildHeading(
                                    text: kUnavailable,
                                    size: 14,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      borderRadius:
                                      const BorderRadius.all(Radius.circular(5)),
                                      color: Colors.white,
                                      border: Border.all(color: Colors.grey.shade200),
                                    ),
                                  ),
                                  buildSizeBox(10.0, 10.0),

                                  buildHeading(
                                    text: kAvailable,
                                    size: 14,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: const BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(5)),
                                      color: Color.fromRGBO(10, 194, 10, 1),
                                    ),
                                  ),
                                  buildSizeBox(10.0, 10.0),

                                  buildHeading(
                                    text: kSelected,
                                    size: 14,
                                  ),
                                ],
                              )
                            ],
                          ),
                          buildSizeBox(20.0, 0.0),


                          /// Seat Arrangement
                          SizedBox(
                            width: Get.width,
                            height: 40,
                            child: Stack(
                              children: [
                                Container(
                                  margin: const EdgeInsets.symmetric(horizontal: 5),
                                  width: Get.width,
                                  color: CustomColors.bluearrowcolor,
                                  child: Center(
                                    child: buildHeading(
                                      text: kSeatArrangement,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Positioned(
                                    left: -5,
                                    top: 10,
                                    bottom: 10,
                                    child: Container(
                                      width: 20,
                                      height: 50,
                                      decoration: const BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle
                                      ),
                                    )
                                ),
                                Positioned(
                                    right: -5,
                                    top: 10,
                                    bottom: 10,
                                    child: Container(
                                      width: 20,
                                      height: 50,
                                      decoration: const BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle
                                      ),
                                    )
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),

                    ///Floors
                    ListView.builder(
                      itemCount: controller.floorPlanData?.length,
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      scrollDirection: Axis.vertical,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          physics: const ClampingScrollPhysics(),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10,right: 10),
                            child: Row(
                              children: [
                                Stack(
                                  children: [

                                    SizedBox(
                                      height: double.parse(controller.floorPlanData?[index].floorPlanHeight.toString() ?? "0"),
                                      width: double.parse(controller.floorPlanData?[index].floorPlanWidth.toString() ?? "0"),
                                      child: controller.floorPlanData?[index].floorImage != null ?
                                      ImageHelper(
                                        image: controller.floorPlanData?[index].floorImage ?? "",
                                        height: MediaQuery.of(context).size.height,
                                        width: MediaQuery.of(context).size.width,
                                        fit: BoxFit.cover,
                                        alignment: Alignment.topCenter,
                                      )
                                          : DefaultWidget.whiteBg(),
                                    ),

                                    if(controller.floorPlanData?[index].tables != null && controller.floorPlanData![index].tables!.isNotEmpty)
                                      for(int a=0;a<controller.floorPlanData![index].tables!.length;a++)
                                        Positioned(
                                            top:controller.floorPlanData?[index].tables?[a].yCord.toString() != "null" ? double.parse(controller.floorPlanData?[index].tables?[a].yCord.toString() ?? "0") : 0.0,
                                            left: controller.floorPlanData?[index].tables?[a].xCord.toString() != "null" ? double.parse(controller.floorPlanData?[index].tables?[a].xCord.toString() ?? "0"):0.0,
                                            child: InkWell(
                                              onTap: (){

                                                if(controller.floorPlanData?[index].tables?[a].isBooked.toString() != "1"){
                                                  setState(() {
                                                    selectedFloorName = controller.floorPlanData?[index].floorName.toString();
                                                    selectedSheetId = controller.floorPlanData?[index].tables?[a].seatId.toString();
                                                    selectedSheetName =controller.floorPlanData?[index].tables?[a].seatName.toString();
                                                  });
                                                }else if(controller.floorPlanData?[index].tables?[a].isBooked.toString() == "2"){
                                                  ToastCustom.showToast( msg: kSeatNotAvailable);
                                                }else{
                                                  ToastCustom.showToast( msg: kAlreadyBookedSeat);
                                                }
                                              },
                                              child: customSeat(
                                                  isBooked: controller.floorPlanData?[index].tables?[a].isBooked.toString() ?? "",
                                                  text: controller.floorPlanData?[index].tables?[a].seatName.toString() ?? "",
                                                  rotate: controller.floorPlanData?[index].tables?[a].alignment.toString().toLowerCase() ?? "",
                                                isSelected: selectedSheetId == controller.floorPlanData?[index].tables?[a].seatId.toString()
                                              ),

                                            )
                                        ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    )


                  ],
                ),
              ) : const SizedBox.shrink(),
            ),
            isLoading: controller.isLoading,
          );
        });

  }


  Widget CustomNoSeatDialog(){
    return Dialog(
              clipBehavior: Clip.antiAlias,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height*0.5,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5)
                      ),
                      child: Column(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            color: CustomColors.bluearrowcolor,
                            height: 50,
                            child: buildHeading(text: 'No seats available',color: Colors.white,)
                          ),
                          buildSizeBox(15.0, 0.0),
                          SvgPicture.asset(strSvgChair),
                          buildSizeBox(15.0, 0.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                              Container(height: 2,width: 20,color: CustomColors.greyColorDark,),

                            ],
                          ),
                          buildSizeBox(15.0, 0.0),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: buildText2(text: "For instance, Mr. Jones of BookingWiz.com notes that if you want to fly to Asia on Northwest and there are no seats",textAlign: TextAlign.justify,color: CustomColors.greyColor),
                          ),
                          buildSizeBox(20.0, 0.0),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: ButtonCustom(onPress: (){}, text: 'Continue', buttonWidth: MediaQuery.of(context).size.width, buttonHeight: 40),
                          )
                        ],
                      ),
                    ),
                  );
  }

  Widget customSeat({required String text, required String rotate, required String isBooked, required bool isSelected}){
    return RotationTransition(
      turns: rotate.toString() == "left" ? const AlwaysStoppedAnimation(90 / 360) : rotate.toString() == "right" ? const AlwaysStoppedAnimation(270 / 360) : rotate.toString() == "top" ? const AlwaysStoppedAnimation(180 / 360):const AlwaysStoppedAnimation(0 / 360),
      child: Container(
        height: 38,
        width: 30,
        color: Colors.transparent,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              // top: 0,
              bottom: 0,
              child: Container(
                height: 26,
                width: 26,
                decoration: BoxDecoration(
                  border: Border.all(width: 2,color: Colors.black),
                  shape: BoxShape.circle,
                  color: isSelected ? Colors.green : isBooked.toString() == "1" ? Colors.grey : Colors.white,
                ),
              ),
            ),
            Center(
              child: Container(
                height: 23,
                width: 30,
                decoration: BoxDecoration(
                  border: Border.all(width: 2,color: Colors.black),
                  color: isSelected ? Colors.green : isBooked.toString() == "1" ? Colors.grey: Colors.white,
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: RotationTransition(
                  turns: rotate.toString() == "left" ? const AlwaysStoppedAnimation(270 / 360) : rotate.toString() == "right" ? const AlwaysStoppedAnimation(90 / 360) : rotate.toString() == "top" ? const AlwaysStoppedAnimation(180 / 360):const AlwaysStoppedAnimation(0 / 360),
                  child: buildText1(text: text,size: 9)
              ),
            )
          ],
        ),
      ),
    );
  }
}
