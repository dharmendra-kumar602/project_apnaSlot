// class SubmitBookingResponse {
//   bool? error;
//   String? message;
//   int? errorCode;
//   String? state;
//   SubmitBookingData? data;
//
//   SubmitBookingResponse(
//       {this.error, this.message, this.errorCode, this.state, this.data});
//
//   SubmitBookingResponse.fromJson(Map<String, dynamic> json) {
//     error = json['error'];
//     message = json['message'];
//     errorCode = json['errorCode'];
//     state = json['state'];
//     data = json['data'] != null ? new SubmitBookingData.fromJson(json['data']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['error'] = this.error;
//     data['message'] = this.message;
//     data['errorCode'] = this.errorCode;
//     data['state'] = this.state;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     return data;
//   }
// }
//
// class SubmitBookingData {
//   String? token;
//   String? orderid;
//   String? amount;
//   String? appId;
//   String? stage;
//   String? notifyUrl;
//   int? isSeatAvailable;
//
//   SubmitBookingData(
//       {this.token,
//         this.orderid,
//         this.amount,
//         this.appId,
//         this.stage,
//         this.notifyUrl,
//         this.isSeatAvailable});
//
//   SubmitBookingData.fromJson(Map<String, dynamic> json) {
//     token = json['token'] != null ? json['token'].toString():null;
//     orderid = json['orderid'] != null ? json['orderid'].toString():null;
//     amount = json['amount'] != null ? json['amount'].toString():null;
//     appId = json['app_id'] != null ? json['app_id'].toString():null;
//     stage = json['stage'] != null ? json['stage'].toString():null;
//     notifyUrl = json['notifyUrl'] != null ? json['notifyUrl'].toString():null;
//     isSeatAvailable = json['is_seat_available'] != null ? int.parse(json['is_seat_available'].toString()):null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['token'] = this.token;
//     data['orderid'] = this.orderid;
//     data['amount'] = this.amount;
//     data['app_id'] = this.appId;
//     data['stage'] = this.stage;
//     data['notifyUrl'] = this.notifyUrl;
//     data['is_seat_available'] = this.isSeatAvailable;
//     return data;
//   }
// }

class SubmitBookingResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  SubmitBookingData? data;

  SubmitBookingResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  SubmitBookingResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    data = json['data'] != null ? new SubmitBookingData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class SubmitBookingData {
  String? paymentSessionId;
  String? orderId;
  int? cfOrderId;
  String? amount;
  String? appId;
  String? stage;
  String? notifyUrl;
  int? isSeatAvailable;

  SubmitBookingData(
      {this.paymentSessionId,
        this.orderId,
        this.cfOrderId,
        this.amount,
        this.appId,
        this.stage,
        this.notifyUrl,
        this.isSeatAvailable});

  SubmitBookingData.fromJson(Map<String, dynamic> json) {
    paymentSessionId = json['payment_session_id'] != null ? json['payment_session_id'].toString():null;
    orderId = json['order_id'] != null ? json['order_id'].toString():null;
    cfOrderId = json['cf_order_id'] != null && json['cf_order_id'] != ""? int.parse(json['cf_order_id'].toString()):null;
    amount = json['amount'] != null ? json['amount'].toString():null;
    appId = json['app_id'] != null ? json['app_id'].toString():null;
    stage = json['stage'] != null ? json['stage'].toString():null;
    notifyUrl = json['notifyUrl'] != null ? json['notifyUrl'].toString():null;
    isSeatAvailable = json['is_seat_available'] != null && json['is_seat_available'] != "" ? int.parse(json['is_seat_available'].toString()):null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['payment_session_id'] = this.paymentSessionId;
    data['order_id'] = this.orderId;
    data['cf_order_id'] = this.cfOrderId;
    data['amount'] = this.amount;
    data['app_id'] = this.appId;
    data['stage'] = this.stage;
    data['notifyUrl'] = this.notifyUrl;
    data['is_seat_available'] = this.isSeatAvailable;
    return data;
  }
}

