
import 'package:apna_slot/Controller/WidgetController/Toast/ToastCustom.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../Controller/ApiController/ApiController.dart';
import '../../../Controller/ApiController/WebConstant.dart';
import '../../../Controller/CashFree/CashFreeController.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../main.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'FloorPlanApiResponse.dart';
import 'SubmitApiResponse.dart';




class SubmitBookingController extends GetxController{

  ApiController apiCtrl = ApiController();
  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;
  SubmitBookingData? submitBookingData;
  List<FloorPlanData>? floorPlanData;


  Future<SubmitBookingResponse?> submitBooking({required bool isRenew,required BuildContext context, required String subscriptionId, required String tableId, required String couponCode,required DateTime? startDate}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "subscription_id":subscriptionId,
      "table_id":tableId,
      "is_renew": isRenew == true ? "1":"0",
      "start_date": DateFormat("dd-MM-yyyy").format(startDate ?? DateTime.now()).toString()

    };
    if(couponCode != ""){
      dictparm.addEntries({"promo_code":couponCode}.entries);
    }


    String url = WebApiConstant.API_URL_SUBMIT_BOOKING;

    await apiCtrl.submitBookingApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {
      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {

              submitBookingData = result.data;
              if(result.data?.isSeatAvailable == 1){
                PopupCustom.seatNotAvailablePopUP(context: context, message: result.message ?? "",
                    onTap: (){
                      Get.back();
                    },
                    onValue: (e){

                    }
                );
              }else{

                changeSuccessValue(true);
                CashFreeCustom.getInstance().then((value) {
                  CashFreeCustom.cashFreeOnTap(
                      environment: result.data?.stage ?? "",
                      orderID: result.data?.orderId.toString() ?? "",
                      sessionID: result.data?.paymentSessionId ?? ""

                    // environment: "SANDBOX",
                    // orderID: "AS0000100",
                    // sessionID: "session_J6H9oomT8OvH4cF3TavKQk7fFPAH0M74Y3AGmu4PU4oSZwUPTxRitZ-vqY65XEaPrec9RmfkQFSmafhwcfm1aFbWudvD99j0Hy1nVQXCLAa-"
                  );
                });
              }
              result.data == null ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
              ToastCustom.showToast(msg: result.message ?? "");

            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          ToastCustom.showToast(msg: result.message ?? "");
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }


    Future<FloorPlanApiResponse?> floorPlan({required DateTime startDate,required BuildContext context, required String subscriptionId, required String libraryId}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "start_date": DateFormat("dd-MM-yyyy").format(startDate ?? DateTime.now()).toString(),
      "library_id": libraryId,
      "subscription_id":subscriptionId,
    };

    String url = WebApiConstant.API_URL_FLOOR_PLAN;

    await apiCtrl.floorPlanApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {
      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              floorPlanData = result.data;
              result.data == null ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
              ToastCustom.showToast(msg: result.message ?? "");

            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          ToastCustom.showToast(msg: result.message ?? "");
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }




  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

}

