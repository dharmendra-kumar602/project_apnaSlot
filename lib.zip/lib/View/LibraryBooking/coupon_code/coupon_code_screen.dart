
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/Toast/ToastCustom.dart';
import 'package:flutter/material.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:get/get.dart';
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import '../LibrarySheetArrangement/SubmitBookingController.dart';
import 'coupon_code_controller.dart';


class CouponCodesScreen extends StatefulWidget {
  String libraryID;
  String subscriptionID;
  CouponCodesScreen({Key? key,required this.subscriptionID,required this.libraryID}) : super(key: key);

  @override
  State<CouponCodesScreen> createState() => _CouponCodesScreenState();
}

class _CouponCodesScreenState extends State<CouponCodesScreen> {

  CouponCodeController couponCodeCtrl = Get.put(CouponCodeController());


  @override
  void initState(){
    init();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }
  Future<void> init()async{
    couponCodeCtrl.isNetworkError = false;
    couponCodeCtrl.isEmpty = false;
    if(await ConnectionValidator().check()){
      await couponCodeCtrl.couponCodeApi(context: context,libraryID: widget.libraryID).then((value) {

      });
    }else{
      couponCodeCtrl.isNetworkError = true;
      setState(() {

      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CouponCodeController>(
      init: couponCodeCtrl,
      builder: (controller){
        return LoadScreen(
          widget: Scaffold(
          backgroundColor: Colors.white,
          appBar: CustomAppBar.appBar(
            onTap: () {  Get.back();  },
            backgroundColor: CustomColors.bluearrowcolor,
            titleColor: CustomColors.whiteColor,
            leadingColor: CustomColors.whiteColor,
            title: kApplyCoupon,
          ),
          body:
          controller.isError ?
          ErrorScreen(
            onTap: () {
              init();
            },
          )
              : controller.isNetworkError ?
          NoInternetConnectionScreen(
            onTap: () {
              init();
            },
          )
              : controller.isEmpty ?
          EmptyDataScreen(
            onTap: () {
              init();
            },
            isShowBtn: false,
            string: controller.couponCodeApiResponse != null ? controller.couponCodeApiResponse?.message :kEmptyData,
          )
              : controller.couponCodeData != null && controller.isEmpty == false ?
          SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Container(
                  margin: const EdgeInsets.only(top: 10),
                  height: Get.height - 80,
                  child:
                  ListView.separated(
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: controller.couponCodeData?.length ?? 0,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    separatorBuilder: (context, index) => const Divider(color: Colors.black12),
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        color: CustomColors.whiteColor,
                        margin: const EdgeInsets.symmetric(vertical: 0),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: ListTile(
                          title: buildText1(text: controller.couponCodeData?[index].code.toString().toUpperCase() ?? "", color: Colors.black
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 3,),
                              buildText1(
                                  text: controller.couponCodeData?[index].description.toString() ?? "",
                                  color: CustomColors.bluearrowcolor
                              )
                            ],
                          ),
                          trailing: InkWell(
                              onTap: () async {
                                await controller.applyCouponCodeApi(context: context, libraryID: widget.libraryID, subscriptionID: widget.subscriptionID, promoID: controller.couponCodeData?[index].id.toString() ?? "",).then((value) {
                                  if(controller.applyCouponCodeApiResponse?.message?.contains("Invalid") == false){
                                    Navigator.of(context).pop(controller.applyCouponCodeApiResponse);
                                  }else{
                                    ToastCustom.showToast(msg: controller.applyCouponCodeApiResponse?.message ?? "");
                                  }
                                });
                              },
                              child: Container(
                                width: 50,
                                alignment: Alignment.center,
                                child: buildText1(text: kApply, color: Colors.teal),
                              )
                          ),
                        ),
                      );
                    },
                  ))
          )
              : const SizedBox.shrink()
            ,

        ), isLoading: controller.isLoading,
        );
      }
    );
  }
}

