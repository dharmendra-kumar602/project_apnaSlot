
class CouponCodeApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  List<CouponCodeData>? data;

  CouponCodeApiResponse(
      {this.error,
        this.message,
        this.errorCode,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.data});

  CouponCodeApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    if (json['data'] != null) {
      data = <CouponCodeData>[];
      json['data'].forEach((v) {
        data!.add(new CouponCodeData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CouponCodeData {
  int? id;
  String? code;
  String? description;

  CouponCodeData({this.id, this.code, this.description});

  CouponCodeData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? int.parse(json['id'].toString()):null;
    code = json['code'] != null ? json['code'].toString():null;
    description = json['description'] != null ? json['description'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['code'] = this.code;
    data['description'] = this.description;
    return data;
  }
}


// class ApplyCouponCodeApiResponse {
//   bool? error;
//   String? message;
//   int? errorCode;
//   bool? authenticate;
//   String? authenticateMessage;
//   String? state;
//
//   ApplyCouponCodeApiResponse(
//       {this.error,
//         this.message,
//         this.errorCode,
//         this.authenticate,
//         this.authenticateMessage,
//         this.state});
//
//   ApplyCouponCodeApiResponse.fromJson(Map<String, dynamic> json) {
//     error = json['error'];
//     message = json['message'];
//     errorCode = json['errorCode'];
//     authenticate = json['authenticate'];
//     authenticateMessage = json['authenticate_message'];
//     state = json['state'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['error'] = this.error;
//     data['message'] = this.message;
//     data['errorCode'] = this.errorCode;
//     data['authenticate'] = this.authenticate;
//     data['authenticate_message'] = this.authenticateMessage;
//     data['state'] = this.state;
//     return data;
//   }
// }

class ApplyCouponCodeApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  String? promoId;
  String? promoCode;
  String? subscriptionAmount;
  String? discountAmount;
  String? total;

  ApplyCouponCodeApiResponse(
      {this.error,
        this.message,
        this.errorCode,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.promoId,
        this.promoCode,
        this.subscriptionAmount,
        this.discountAmount,
        this.total});

  ApplyCouponCodeApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'] != null && json['error'].toString().toLowerCase() == "true" ? true:false;
    message = json['message'] != null ? json['message'].toString():null;
    errorCode = json['errorCode'] != null ? int.parse(json['errorCode'].toString()):null;
    authenticate = json['authenticate'] != null && json['authenticate'].toString().toLowerCase() == "true" ? true:false;
    authenticateMessage = json['authenticate_message'] != null ? json['authenticate_message'].toString():null;
    state = json['state'] != null ? json['state'].toString():null;
    promoId = json['promo_id'] != null ? json['promo_id'].toString():null;
    promoCode = json['promo_code'] != null ? json['promo_code'].toString():null;
    subscriptionAmount = json['subscription_amount'] != null ? json['subscription_amount'].toString():null;
    discountAmount = json['discountAmount'] != null ? json['discountAmount'].toString():null;
    total = json['total'] != null ? json['total'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    data['promo_id'] = this.promoId;
    data['promo_code'] = this.promoCode;
    data['subscription_amount'] = this.subscriptionAmount;
    data['discountAmount'] = this.discountAmount;
    data['total'] = this.total;
    return data;
  }
}




