import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/RedirectToCall/RedirectToCallWidget.dart';
import 'package:apna_slot/Controller/Helper/RedirectToEmail/RedirectToEmailWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:apna_slot/View/Profile/MyQrCode/MyQrCodeScreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/AdditionalWidget/CustomeRattingBar.dart';
import '../../../Controller/WidgetController/AdditionalWidget/HelpSupportWidget.dart';
import '../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../Dashboard/History/HistoryController.dart';
import '../../Dashboard/History/HistoryResponse.dart';
import '../../LibraryBooking/LibrarySheetArrangement/SubmitBookingController.dart';

class MyDetailsScreen extends StatefulWidget {
  String bookingNo;
  String subsType;
  String price;
  bool isShowRenewSubscription;
  VoidCallback reNewSubs;
  HistoryData? historyData;
  MyDetailsScreen({Key? key,required this.isShowRenewSubscription, required this.price,required this.subsType,required this.bookingNo, required this.reNewSubs, required this.historyData}) : super(key: key);

  @override
  State<MyDetailsScreen> createState() => _MyDetailsScreenState();
}

class _MyDetailsScreenState extends State<MyDetailsScreen> {

  String userName = "";
  String userEmail = "";
  String userImage = "";

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> getData() async {
    userName = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName) ?? "";
    userEmail = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userEmail) ?? "";
    userImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg) ?? "";
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar.appBar(
        onTap: (){
          Get.back();
        },
        title: kBookingDetails,
      ),
      backgroundColor: CustomColors.whiteColor,
      bottomNavigationBar: widget.isShowRenewSubscription == true ? Padding(
        padding: const EdgeInsets.only(left: 20,right: 20,bottom: 20),
        child: ButtonCustom(
          onPress: widget.reNewSubs,
          text: kRenewSubscription,
          buttonWidth: Get.width,
          buttonHeight: 50.0,
        ),
      ) : const SizedBox.shrink(),
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Column(
          children: [
            /// Image
            Container(
              width: 70,
              height: 70,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle
              ),
              child: userImage != "" ?
              ImageHelper(
                image: userImage,
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
                alignment: Alignment.topCenter,
              ):DefaultWidget.image(),
            ),
            buildSizeBox(15.0, 0.0),

            /// Name
            buildHeading(text: userName),
            buildSizeBox(15.0, 0.0),

            widget.price != "" ?
            Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              width:Get.width,
              height: 90,
              color:  CustomColors.greyColor.withOpacity(0.05),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildHeading(
                        text: kSubscriptionType,
                        size: 22,
                      ),
                      buildHeadingBold(text: '₹${widget.price.toString()}/${widget.subsType}'),
                    ],
                  ),

                  /// QR Code
                  InkWell(
                        onTap: (){
                          // Get.toNamed(myQrCodeScreenRoute,arguments: MyQrCodeScreen(bookingNo: widget.bookingNo));
                        },
                        child: QrImageView(
                          padding: const EdgeInsets.all(15),
                          data: widget.bookingNo,
                          version: QrVersions.auto,
                          // size: Get.width*0.40,
                        ),
                      ),
                ],
              ),
            )
                : const SizedBox.shrink(),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                   /// Facility
                    widget.historyData?.facilityType != null && widget.historyData!.facilityType!.isNotEmpty ?
                    SizedBox(
                      height: 30,
                      width: Get.width,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          buildText1(text: kFacility,color: CustomColors.blackColor),

                          Expanded(
                            child: ListView.builder(
                              itemCount: widget.historyData?.facilityType?.length,
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              scrollDirection: Axis.horizontal,
                              physics: const ClampingScrollPhysics(),
                              itemBuilder: (context, index) {
                                return Row(
                                  children: [
                                    SizedBox(
                                      height: 16,
                                      width: 16,
                                      child:
                                      ImageHelper(
                                        image:widget. historyData?.facilityType?[index].image.toString() ?? "",
                                        height: MediaQuery.of(context).size.shortestSide,
                                        width: MediaQuery.of(context).size.width,
                                        fit: BoxFit.fitWidth,
                                        alignment: Alignment.center,
                                      )
                                      // Image.network(
                                      //     historyData?.facilityType?[index].image.toString() ?? ""
                                      // ),
                                    ),
                                    buildSizeBox(0.0, 5.0),
                                    buildText1(text: widget.historyData?.facilityType?[index].name.toString() ?? "",color: CustomColors.greyColor),
                                    buildSizeBox(0.0, 10.0),
                                  ],
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ) : const SizedBox.shrink(),
                    buildSizeBox(5.0, 0.0),

                    ///Subscription Type
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildText1(text: '$kSubscriptionType : ',color: CustomColors.blackColor) ,
                          buildText1(text: widget.historyData?.subsName ?? "",color: CustomColors.greyColor),
                        ]
                    ),
                    buildSizeBox(15.0, 0.0),

                    /// Schedule Timing
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   crossAxisAlignment: CrossAxisAlignment.start,                   
                    //   children: [
                    //     buildText1(text: 'Schedule timing',color: CustomColors.blackColor) ,
                    //     buildText1(text: widget.historyData?.timeSlot ?? "",color: CustomColors.greyColor),
                    //   ],
                    // ),
                    // buildSizeBox(15.0, 0.0),

                    ///Floor number
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildText1(text: kFloorNum,color: CustomColors.blackColor),
                        buildText1(text: widget.historyData?.floorNo ?? "",color: CustomColors.greyColor),
                      ],
                    ),
                    buildSizeBox(15.0, 0.0),

                    ///Booking Number
                    Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,  
                      children: [
                        buildText1(text: kBookingNumber,color: CustomColors.blackColor),
                        buildText1(text: widget.historyData?.bookingNumber ?? "",color: CustomColors.greyColor),
                      ],
                    ),
                    buildSizeBox(15.0, 0.0),

                    ///Expiry Date
                    Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: buildText1(text: kExpiryDate,color: CustomColors.blackColor),
                      ),
                      buildText1(text: widget.historyData?.endDate ?? "N/A",color: CustomColors.greyColor),
                    ],
                  ),
                  
                  buildSizeBox(20.0, 0.0),

                  const Divider(
                    height: 1,
                    color: Colors.grey,
                  ),
                  buildSizeBox(20.0, 0.0),

                  /// Contact Info:
                  buildText1(text:kContactInfo,size: 18),
                  buildSizeBox(10.0, 0.0),

                  /// Contact number
                  HelpAndSupportWidget.contactWidget(
                      onTap: (){
                        RedirectToCall.phoneNumberLaunch(phoneNumber: kHelpSupportContactNumber);
                        // _makePhoneCall(phoneNumber: kHelpSupportContactNumber);
                      },iconImage: strImgPhoneWhite, title: kHelpSupportContactNumber),
                  buildSizeBox(8.0, 0.0),

                  /// Contact email
                  HelpAndSupportWidget.contactWidget(
                      onTap:(){
                        RedirectToEmail.EmailLaunch(emailID: kHelpSupportContactEmail);
                        // _makeMail(address: kHelpSupportContactEmail);
                      } ,iconImage: strImgEmailWhite, title: kHelpSupportContactEmail),
                ],
              ),
              // color: Colors.pink,
            ),
            buildSizeBox(15.0, 0.0),

          ],
        ),
      ),
    );
  }
}
