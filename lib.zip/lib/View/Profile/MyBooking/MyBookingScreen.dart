// import 'package:apna_slot/features/app_info/presentation/widgets/common_widget/app_common_app_bar.dart';
// import 'package:apna_slot/features/app_info/presentation/widgets/common_widget/app_common_bottom_navigation_bar.dart';
// import 'package:apna_slot/features/app_info/presentation/widgets/common_widget/app_common_library_item_widget.dart';
// import 'package:apna_slot/features/app_info/presentation/widgets/common_widget/app_custom_add_review_dialog.dart';
// import 'package:apna_slot/features/my_bookings/presentation/manager/my_booking/my_booking_cubit.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:sizer/sizer.dart';
//
// class MyBookingScreen extends StatefulWidget {
//   const MyBookingScreen({Key? key}) : super(key: key);
//   @override
//   State<StatefulWidget> createState() {
//     return _MyBookingScreenState();
//   }
// }
//
// class _MyBookingScreenState extends State<MyBookingScreen> {
//   int _selectedIndex = 0;
//
//   void _onItemTapped(int index) {
//     setState(() {
//       _selectedIndex = index;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final myBookingsCubit = context.read<MyBookingsCubit>();
//
//     return SafeArea(
//         child: Scaffold(
//             extendBodyBehindAppBar: false,
//             appBar: PreferredSize(
//               preferredSize: Size.fromHeight(8.h),
//               child: AppCommonAppBar(
//                 title: 'My Booking',
//               ),
//             ),
//             bottomNavigationBar: AppCommonBottomNavigationBar(),
//             // BottomNavigationBar(
//             //   items: <BottomNavigationBarItem>[
//             //     const BottomNavigationBarItem(
//             //       icon: Icon(Icons.home),
//             //       label: 'Home',
//             //
//             //     ),
//             //     BottomNavigationBarItem(
//             //       icon: IconButton(icon: Icon(Icons.notifications_none),onPressed: (){
//             //         Navigator.pushNamed(context, AppRoutes.notificationPage);
//             //       },),
//             //
//             //       label: 'Alert',
//             //     ),
//             //     BottomNavigationBarItem(
//             //       icon: Icon(CupertinoIcons.doc_text),
//             //       label: 'History',
//             //     ),
//             //   ],
//             //   currentIndex: _selectedIndex,
//             //   selectedItemColor: Colors.blue,
//             //   // selectedItemColor: Colors.buttoncolor,
//             //   unselectedItemColor: Colors.black,
//             //   iconSize: 20,
//             //   onTap: _onItemTapped,
//             //   elevation: 1,
//             // ),
//
//             body: Container(
//               width: 100.w,
//               // height: 60.h - 24,
//               height: 100.h,
//               child: ListView.builder(
//                   physics: BouncingScrollPhysics(),
//                   padding: EdgeInsets.zero,
//                   itemCount: 5,
//                   itemBuilder: (context, index) {
//                     return AppCommonLibraryItemWidget(
//                       facility: [],
//                       libraryAddress: 'Library Address',
//                       libraryName: 'Library Name',
//                       openingHour: '8AM',
//                       closingHour: '8PM',
//                       ignoreRatingBarGesture: true,
//                       showIcon: true,
//                       isBookingPage: true,
//                       addReviewCallBack: () {
//                         showDialog(
//                             context: context,
//                             builder: (BuildContext context) {
//                               return AppCustomAddReviewDialog(
//                                 reviewController: myBookingsCubit.reviewCtrl,
//                                 onTap: () {
//                                   myBookingsCubit.addReview();
//                                 },
//                               );
//                             });
//                       },
//                     );
//                   }),
//             )));
//   }
// }
