
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart' as dio;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../Controller/ApiController/ApiController.dart';
import '../../../Controller/ApiController/WebConstant.dart';
import '../../../Controller/Helper/Camera/CameraScreen.dart';
import '../../../Controller/Helper/ImagePicker/ImagePicker.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../../Controller/Helper/TextController/TextValidator/TextValidator.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../../../main.dart';
import 'ProfileResponse.dart';



class ProfileController extends GetxController{

  UpdateProfileData? updateProfileData;

  ApiController apiCtrl = ApiController();

  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;

  String? profileImage;
  double? spacingTextField = 10.0;

  bool isName = false;
  bool isEmail = false;
  bool isValidEmail = false;
  bool isMobile = false;
  bool isValidMobile = false;
  bool isAddress = false;
  bool isCity = false;
  bool isAadhaar = false;
  bool isValidAadhaar = false;

  String? aadhaarImage, aadhaarImagePath;

  bool? profileImagePicked = false;

  TextEditingController nameCT = TextEditingController();
  TextEditingController emailCT = TextEditingController();
  TextEditingController mobileCT = TextEditingController();
  TextEditingController addressCT = TextEditingController();
  TextEditingController cityCT = TextEditingController();
  TextEditingController aadhaarNumberCT = TextEditingController();

  FocusNode nameFC = FocusNode();
  FocusNode emailFC = FocusNode();
  FocusNode mobileFC = FocusNode();
  FocusNode addressFC = FocusNode();
  FocusNode cityFC  = FocusNode();
  FocusNode aadhaarNumberFC = FocusNode();

  ImagePickerController? imagePicker = Get.put(ImagePickerController());

    Future textFieldClear()async{
    nameCT.clear();
    emailCT.clear();
    mobileCT.clear();
    addressCT.clear();
    cityCT.clear();
    aadhaarNumberCT.clear();
  }
  Future textFieldDispose()async{
    nameCT.dispose();
    emailCT.dispose();
    mobileCT.dispose();
    addressCT.dispose();
    cityCT.dispose();
    aadhaarNumberCT.dispose();
  }

  Future<void> init()async{
    nameCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName) ?? "";
    emailCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userEmail) ?? "";
    mobileCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userMobileNo) ?? "";
    addressCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAddress) ?? "";
    cityCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userCityName) ?? "";
    aadhaarNumberCT.text = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAadhaarNumber) ?? "";
    profileImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg) ?? "";
    aadhaarImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAadhaarImage)?.toLowerCase() != "null" ? AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userAadhaarImage):null;
    update();
  }

    void getImage(source, BuildContext context) {
    imagePicker?.getImage(source, context, "profileImage").then((value) => update());
  }
  void getImage2(source, BuildContext context) {
    imagePicker?.getImage(source, context, "documentImage").then((value){
      aadhaarImagePath = imagePicker?.documentImage?.path ;
      update();
    });
  }

  Future<UpdateProfileResponse?> updateProfile({required BuildContext context, required XFile? profileImage, required String name, required String email, required String mobileNumber, required String address, required String city, required String aadhaarNumber}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    // try{

    dio.FormData formData = dio.FormData.fromMap({
      "name":name,
      "email":email,
      "mobile_no":mobileNumber,
      "user_type":"Student",
  
      "address":address,
      "city":city,
      "aadhar_no":aadhaarNumber,

    });

    if(profileImage != null && profileImage.path != "" ){
      PrintLog.printLog("Profile image update ::::::${profileImage.path}");
      formData.files.add(MapEntry("profile_image", await dio.MultipartFile.fromFile(profileImage.path, filename:profileImage.path.split('/').last)));
    }
     if(aadhaarImagePath != null && aadhaarImagePath != "" ){
      PrintLog.printLog("Aadhar image update ::::::${aadhaarImagePath}");
      formData.files.add(MapEntry("aadhar_image", await dio.MultipartFile.fromFile(aadhaarImagePath ?? "", filename:aadhaarImagePath?.split('/').last)));
    }

    PrintLog.printLog('Update fields :::::: ${formData.fields}');
    PrintLog.printLog('Update files  :::::: ${formData.files}');


    String url = WebApiConstant.API_URL_UPDATE_PROFILE;

    await apiCtrl.updateProfileApi(context:context,url: url, formData: formData,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              updateProfileData = result.data;
              await saveUserData(data: result.data);
              changeLoadingValue(false);
              changeSuccessValue(true);

              ToastCustom.showToast( msg: result.message ?? "");

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              ToastCustom.showToast( msg: result.message ?? "");
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
    // } catch (e){
    //   print('testing......111$e');
    // }
  }

  Future<void> addAadhaarImage({required BuildContext context})async {
    Navigator.pop(context);
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const CameraScreen()
          )).then((value) async {
        if (value != null) {
          PrintLog.printLog(value);
          aadhaarImagePath = value;
          PrintLog.printLog("Captured Image : ${aadhaarImagePath}");
          update();
        }
      });
      update();
  }

  //   Future<void> addProfileImage({required BuildContext context})async {
  //   profileImagePicked = true;
  //   Navigator.pop(context);
  //     Navigator.push(
  //         context,
  //         MaterialPageRoute(
  //             builder: (context) => const CameraScreen()
  //         )).then((value) async {
  //       if (value != null) {
  //         print(value);
  //         final imageData = File(value);
  //         profileImage = value;
  //         print("Captured Image : ${profileImage}");
  //         update();
  //       }
  //     });
  //     update();
  // }



  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

    checkDetails(context)async{
    isName = TxtValidation.normalTextField(nameCT);
    isEmail = TxtValidation.normalTextField(emailCT);
    isValidEmail = TxtValidation.validateEmailTextField(emailCT);
    isMobile = TxtValidation.normalTextField(mobileCT);
    isValidMobile = TxtValidation.validateMobileTextField(mobileCT);
    isAddress = TxtValidation.normalTextField(addressCT);
    isCity = TxtValidation.normalTextField(cityCT);
    isAadhaar = TxtValidation.normalTextField(aadhaarNumberCT);
    isValidAadhaar = TxtValidation.validateAadhaarTextField(aadhaarNumberCT);



    if(!isName && !isMobile && !isValidMobile && !isEmail && !isValidEmail && !isAddress && !isCity && !isAadhaar && !isValidAadhaar){
        PrintLog.printLog(":::Success....");
        await updateProfile(
            context: context,
            name: nameCT.text.toString().trim(),
            mobileNumber: mobileCT.text.toString().trim(),
            email: emailCT.text.toString().trim(),
            city: cityCT.text.toString().trim(),
            address: addressCT.text.toString().trim(),
            aadhaarNumber: aadhaarNumberCT.text.toString().trim(),
            profileImage: imagePicker?.profileImage != null ? imagePicker!.profileImage:null,
        ).then((value){
          Navigator.pop(context);
        });
    } else {
      if(aadhaarImagePath == null && aadhaarImage == null){
        ToastCustom.showToast(msg: 'Upload aadhaar image');
      }
    }
    update();
  }

  Future<void> saveUserData({UpdateProfileData? data})async{
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userId, variableValue: data?.id.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userName, variableValue: data?.name.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userEmail, variableValue: data?.email.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userMobileNo, variableValue: data?.mobileNo.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userProfileImg, variableValue: data?.profileImage.toString() ?? "");
    ///
    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userCityId, variableValue: data?.userCityId.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userCityName, variableValue: data?.city.toString() ?? "");
    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userStateId, variableValue: data?.userStateId.toString() ?? "");
    // await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userStateName, variableValue: data?.userStateName.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAadhaarNumber, variableValue: data?.aadharNo.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAddress, variableValue: data?.address.toString() ?? "");
    await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userAadhaarImage, variableValue: data?.aadharImage ?? "");
  }
}

