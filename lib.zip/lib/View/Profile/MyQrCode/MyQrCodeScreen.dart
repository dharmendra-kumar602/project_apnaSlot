import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:qr_flutter/qr_flutter.dart';

// import 'package:qr_flutter/qr_flutter.dart';
// import 'package:sizer/sizer.dart';
import '../../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';

class MyQrCodeScreen extends StatefulWidget {
  String bookingNo;
  MyQrCodeScreen({Key? key,required this.bookingNo}) : super(key: key);

  @override
  State<MyQrCodeScreen> createState() => _MyQrCodeScreenState();
}

class _MyQrCodeScreenState extends State<MyQrCodeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar.appBar(
        onTap: (){
          Get.back();
        },
        backgroundColor: CustomColors.bluearrowcolor,
        titleColor: CustomColors.whiteColor,
        leadingColor: CustomColors.whiteColor,
        title: kMyQrCode,
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Card(
          elevation: 20,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 15,right: 15,top: 30,bottom: 30),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                QrImageView(
                  data: widget.bookingNo,
                  version: QrVersions.auto,
                  size: Get.width*0.70,
                ),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: buildTextWithHeight(
                      text: kMyQrCodeDes,
                    size: 18,
                    height: 1.2
                  ),

                )
              ],
            ),
          ),
        ),
      ),
    );
  }

}