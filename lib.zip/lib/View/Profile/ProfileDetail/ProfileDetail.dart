import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/Helper/Shared%20Preferences/SharedPreferences.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../Controller/RouteController/RouteNames.dart';
import '../../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../../Controller/WidgetController/AdditionalWidget/ProfileButton.dart';
import '../../../Controller/WidgetController/BottomSheet/BottomSheetCustom.dart';
import '../../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';

class ProfileDetailScreen extends StatefulWidget {
  const ProfileDetailScreen({Key? key}) : super(key: key);

  @override
  State<ProfileDetailScreen> createState() => _ProfileDetailScreenState();
}

class _ProfileDetailScreenState extends State<ProfileDetailScreen> {

  String userName = "";
  String userEmail = "";
  String userImage = "";

  @override
  void initState() {
    super.initState();
    getData();
  }

  Future<void> getData() async {
    userName = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName) ?? "";
    userEmail = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userEmail) ?? "";
    userImage = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg) ?? "";
  }

  @override
  Widget build(BuildContext context) {
    print(userImage);
    return Scaffold(
      backgroundColor: CustomColors.whiteColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              
              SizedBox(
                height: 80,
                width: Get.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle
                      ),
                      child: userImage != "" && userImage!='null' ?
                      ImageHelper(
                        image: userImage ,
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        fit: BoxFit.cover,
                        alignment: Alignment.topCenter,
                      ):DefaultWidget.image(),
                    ),
                    buildSizeBox(0.0, 10.0),

                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildHeadingBold(
                            text: userName,
                            size: 18,
                          ),
                          buildSizeBox(5.0, 0.0),

                          buildHeading(
                            text: userEmail,
                            size: 14,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),

              buildSizeBox(20.0, 0.0),

              /// Edit profile
              ProfileButton.button(
                  onTap: (){
                    PrintLog.printLog("Edit Profile");
                    Get.back();
                    Get.toNamed(updateProfileScreenRoute);
                  },
                  svgName: strSvgPen,
                  title: kEditProfile
              ),

              /// Help & Support
              ProfileButton.button(
                  onTap: (){
                    PrintLog.printLog("Help & Support");
                    Get.toNamed(helpAndSupportScreenRoute);
                  },
                  svgName: strSvgHelp,
                  title: kHelpAndSupport
              ),

              /// Privacy Policy
              ProfileButton.button(
                  onTap: (){
                    PrintLog.printLog("Privacy Policy");
                    PopupCustom.termAndConditionPopUP(context: context, type: "privacy");
                  },
                  svgName: strSvgEarth,
                  title: kPrivacyStatement
              ),

              /// Term & condition
              ProfileButton.button(
                  onTap: (){
                    PrintLog.printLog("Term & condition");
                    PopupCustom.termAndConditionPopUP(context: context, type: "terms");
                  },
                  // svgName: strSvgTermAndCondition,
                  svgName: strSvgHelp,
                  title: kTermsAndConditions
              ),
              /// Share App
              ProfileButton.button(
                  onTap: (){
                    BottomSheetCustom.share(context: context, link: strAppShareLink);
                  },
                  svgName: strSvgShare,
                  title: kShareApp
              ),
              /// Log out
              ProfileButton.button(
                  onTap: () async {
                    PopupCustom.userLogoutPopUP(context: context);
                    // PopupCustom.showCompleteBookingPopUP(context: context,bookingNumber: "AS0000014");
                   // await LogoutCustom.logout();
                  },
                  svgName: strSvgLogout,
                  title: kLogOut
              ),

            ],
          ),
        ),
      ),
    );
  }
}
