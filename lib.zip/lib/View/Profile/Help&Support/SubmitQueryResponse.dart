class SubmitQueryResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;

  SubmitQueryResponse({this.error, this.message, this.errorCode, this.state});

  SubmitQueryResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    return data;
  }
}

class QueryHeadingResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  List<QueryHeading>? data;
  List<BookingData>? bookingData;

  QueryHeadingResponse({this.error, this.message, this.errorCode, this.state, this.data, this.bookingData});

  QueryHeadingResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    if (json['data'] != null) {
      data = <QueryHeading>[];
      json['data'].forEach((v) {
        data!.add(new QueryHeading.fromJson(v));
      });
      if (json['booking'] != null) {
        bookingData = <BookingData>[];
        json['booking'].forEach((v) {
          bookingData!.add(new BookingData.fromJson(v));
        });
      }
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class QueryHeading {
  int? id;
  String? name;
  bool isSelected = false;

  QueryHeading({this.id, this.name});

  QueryHeading.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? int.parse(json['id'].toString()):null;
    name = json['name'] != null ? json['name'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class BookingData {
  String? id;
  String? bookingNumber;
  String? customerId;
  String? libraryId;
  String? libraryName;
  String? subscriptionId;
  String? libraryTableId;
  String? createdBy;
  String? promoCode;
  String? amount;
  String? startDate;
  String? endDate;
  String? bookingDate;
  String? paymentDate;
  String? paymentMode;
  String? paymentReferenceNo;
  String? userInfo;
  String? paidStatus;
  String? createdAt;
  String? updatedAt;

  BookingData(
      {this.id,
        this.bookingNumber,
        this.customerId,
        this.libraryId,
        this.libraryName,
        this.subscriptionId,
        this.libraryTableId,
        this.createdBy,
        this.promoCode,
        this.amount,
        this.startDate,
        this.endDate,
        this.bookingDate,
        this.paymentDate,
        this.paymentMode,
        this.paymentReferenceNo,
        this.userInfo,
        this.paidStatus,
        this.createdAt,
        this.updatedAt});

  BookingData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    bookingNumber = json['booking_number'] != null ? json['booking_number'].toString():null;
    customerId = json['customer_id'] != null ? json['customer_id'].toString():null;
    libraryId = json['library_id'] != null ? json['library_id'].toString():null;
    libraryName = json['library_name'] != null ? json['library_name'].toString():null;
    subscriptionId = json['subscription_id'] != null ? json['subscription_id'].toString():null;
    libraryTableId = json['library_table_id'] != null ? json['library_table_id'].toString():null;
    createdBy = json['created_by'] != null ? json['created_by'].toString():null;
    promoCode = json['promo_code'] != null ? json['promo_code'].toString():null;
    amount = json['amount'] != null ? json['amount'].toString():null;
    startDate = json['start_date'] != null ? json['start_date'].toString():null;
    endDate = json['end_date'] != null ? json['end_date'].toString():null;
    bookingDate = json['booking_date'] != null ? json['booking_date'].toString():null;
    paymentDate = json['payment_date'] != null ? json['payment_date'].toString():null;
    paymentMode = json['payment_mode'] != null ? json['payment_mode'].toString():null;
    paymentReferenceNo = json['payment_reference_no'] != null ? json['payment_reference_no'].toString():null;
    userInfo = json['user_info'] != null ? json['user_info'].toString():null;
    paidStatus = json['paid_status'] != null ? json['paid_status'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['booking_number'] = this.bookingNumber;
    data['customer_id'] = this.customerId;
    data['library_id'] = this.libraryId;
    data['library_name'] = this.libraryName;
    data['subscription_id'] = this.subscriptionId;
    data['library_table_id'] = this.libraryTableId;
    data['created_by'] = this.createdBy;
    data['promo_code'] = this.promoCode;
    data['amount'] = this.amount;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['booking_date'] = this.bookingDate;
    data['payment_date'] = this.paymentDate;
    data['payment_mode'] = this.paymentMode;
    data['payment_reference_no'] = this.paymentReferenceNo;
    data['user_info'] = this.userInfo;
    data['paid_status'] = this.paidStatus;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

