
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/Helper/RedirectToCall/RedirectToCallWidget.dart';
import 'package:apna_slot/Controller/Helper/RedirectToEmail/RedirectToEmailWidget.dart';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/TextField/CustomTextField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../../Controller/WidgetController/AdditionalWidget/HelpSupportWidget.dart';
import '../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../Controller/WidgetController/CheckBox/CheckBoxCustom.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import 'HelpAndSupportController.dart';
import 'SubmitQueryResponse.dart';

class HelpAndSupportScreen extends StatefulWidget {
  const HelpAndSupportScreen({Key? key}) : super(key: key);

  @override
  State<HelpAndSupportScreen> createState () => _HelpAndSupportScreenState();
}

class _HelpAndSupportScreenState extends State<HelpAndSupportScreen> {

  HelpAndSupportController helpCtrl = Get.put(HelpAndSupportController());
  TextEditingController textCtrl = TextEditingController();

  QueryHeading? dropdownValue;
  BookingData? dropDownValue2;

  @override
  void initState() {
    init();
    super.initState();
  }

  @override
  void dispose() {
    textCtrl.dispose();
    super.dispose();
  }

  Future<void> init()async{
    await helpCtrl.getQueryHeading(context: context);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HelpAndSupportController>(
        init: helpCtrl,
        builder: (controller) {
          return LoadScreen(
            widget: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Scaffold(
                  resizeToAvoidBottomInset : false,
                  backgroundColor: CustomColors.whiteColor,
                  /// App bar
                  appBar: PreferredSize(
                    preferredSize: const Size.fromHeight(70),
                    child: CustomAppBar.appBar(
                      title: kHelpAndSupport,
                      onTap: () {
                        Get.back();
                      },
                    ),
                  ),
            
                  body: Padding(
                    padding: const EdgeInsets.only(left: 20,right: 20),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          /// Image
                          // Row(
                          //   crossAxisAlignment: CrossAxisAlignment.center,
                          //   mainAxisAlignment: MainAxisAlignment.center,
                          //   children: [
                          //     SizedBox(
                          //       width: Get.width * 30/100,
                          //       height: Get.width * 30/100,
                          //       child: const CircleAvatar(
                          //         backgroundImage: AssetImage(str_imgHelpAndSupport),
                          //       ),
                          //     ),
                          //   ],
                          // ),
                          // buildSizeBox(20.0, 0.0),
            
                          /// Ask Query
                          // buildText1(text:kAskQuery,size: 20),
                          // buildSizeBox(10.0, 0.0),

                          /// Choose Library
                          Visibility(
                            visible: dropDownValue2 != null,
                            child: buildText1(text:kSelectedBookingNo,fontFamily: FontFamily.josefinBold),
                          ),
                          dropDownValue2 != null ? buildSizeBox(5.0, 0.0) : const SizedBox.shrink(),

                          Container(
                            height: 45,
                            padding: const EdgeInsets.only(left: 8,right: 0),
                            width: Get.width,
                            decoration: BoxDecoration(
                                color: CustomColors.bluearrowcolor.withOpacity(0.05),
                                // border: Border.all(color: CustomColors.bluearrowcolor),
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<BookingData>(
                                value: dropDownValue2,
                                icon: const Icon(Icons.keyboard_arrow_down_sharp),
                                iconSize: 24,
                                elevation: 16,
                                borderRadius: BorderRadius.circular(5),
                                hint: buildText1(text:kSelectBookingNo),
                                isExpanded: true,
                                onChanged: (newValue) {
                                  setState(() {
                                    dropDownValue2 = newValue;
                                  });
                                },
                                menuMaxHeight: 300,
                                items: helpCtrl.bookingData?.map<DropdownMenuItem<BookingData>>((BookingData value) {
                                  return DropdownMenuItem<BookingData>(
                                    value: value,
                                    child: Row(
                                      children: [
                                        // buildText1(text: 'Booking No : '),
                                        Expanded(child: buildText1(text: "${value.bookingNumber ?? ""} (${value.libraryName ?? ""})"),)
                                      ],
                                    )
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                          buildSizeBox(10.0, 0.0),

                          /// Choose Query Heading
                          Visibility(
                            visible: dropdownValue != null,
                              child: buildText1(text:kSelectedQuery,fontFamily: FontFamily.josefinBold),
                          ),
                          dropdownValue != null ? buildSizeBox(5.0, 0.0) : const SizedBox.shrink(),
            
                         Container(
                            height: 45,
                            padding: const EdgeInsets.only(left: 8,right: 0),
                            width: Get.width,
                            decoration: BoxDecoration(
                              color: CustomColors.bluearrowcolor.withOpacity(0.05),
                              // border: Border.all(color: CustomColors.bluearrowcolor),
                              borderRadius: BorderRadius.circular(5)
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<QueryHeading>(
                                value: dropdownValue,
                                icon: const Icon(Icons.keyboard_arrow_down_sharp),
                                iconSize: 24,
                                elevation: 16,
                                borderRadius: BorderRadius.circular(5),
                                hint: buildText1(text:kSelectQuery),
                                isExpanded: true,
                                onChanged: (newValue) {
                                  setState(() {
                                    dropdownValue = newValue;
                                  });
                                },
                                menuMaxHeight: 300,
                                items: helpCtrl.queryHeading?.map<DropdownMenuItem<QueryHeading>>((QueryHeading value) {
                                  return DropdownMenuItem<QueryHeading>(
                                    value: value,
                                    child: buildText1(text:value.name ?? ""),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                          buildSizeBox(10.0,0.0),

                          /// TextField
                          CustomTextFieldRaiseQuery(
                            controller: textCtrl,
                            textInputAction: TextInputAction.done,
                            keyboardType: TextInputType.text,
                            readOnly: false,
                            autofocus: false,
                            hintText: 'Write your query here',
                            onTap: (){
            
                            },
                            onChanged: (value){
            
                            },
                          ),
                          buildSizeBox(30.0, 0.0),
            
                          /// Submit
                          ButtonCustom(
                            onPress: onPressSubmit,
                            text: kSubmit,
                            buttonWidth: Get.width,
                            buttonHeight: 50.0,
                          ),
                          buildSizeBox(30.0, 0.0),
                          // const Divider(height: 1,color: Colors.grey),
                          // buildSizeBox(30.0, 0.0),
            
                          /// Contact Info:
                          // buildText1(text:kContactInfo,size: 20),
                          // buildSizeBox(10.0, 0.0),
                          //
                          // /// Contact number
                          // HelpAndSupportWidget.contactWidget(
                          //     onTap: (){
                          //       RedirectToCall.phoneNumberLaunch(phoneNumber: kHelpSupportContactNumber);
                          //     },iconImage: strImgPhoneWhite, title: kHelpSupportContactNumber),
                          // buildSizeBox(10.0, 0.0),
                          //
                          // /// Contact email
                          // HelpAndSupportWidget.contactWidget(
                          //     onTap:(){
                          //       RedirectToEmail.EmailLaunch(emailID: kHelpSupportContactEmail);
                          //     } ,iconImage: strImgEmailWhite, title: kHelpSupportContactEmail),
            
                        ],
                      ),
                    ),
                  )
              ),
            ),
            isLoading: controller.isLoading,
          );
        });
  }

  onPressSubmit() async {
    if(dropDownValue2 != null){
      if(dropdownValue != null){
        if(textCtrl.text.toString().trim().isNotEmpty){
          PrintLog.printLog("Query submit:::....");
          await helpCtrl.submitQuery(context: context,message: textCtrl.text.toString().trim(),queryHeading: dropdownValue,bookingData: dropDownValue2).then((value) {
            setState((){
              textCtrl.clear();
              dropdownValue = null;
              dropDownValue2 = null;
              FocusScope.of(context).unfocus();
            });
          });
        }else{
          ToastCustom.showToast( msg: kQueryToastString);
        }
      }else{
        ToastCustom.showToast( msg: kQueryReasonString);
      }
    } else {
      ToastCustom.showToast( msg: kPleaseSelectBookingNo);
    }


  }



}