import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../../Controller/ApiController/ApiController.dart';
import '../../../Controller/ApiController/WebConstant.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../main.dart';
import 'SubmitQueryResponse.dart';



class HelpAndSupportController extends GetxController{


  ApiController apiCtrl = ApiController();
  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;

  List<QueryHeading>? queryHeading;
  List<BookingData>? bookingData;

  Future<SubmitQueryResponse?> submitQuery({required BuildContext context, required String message,QueryHeading? queryHeading,BookingData? bookingData}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);


    Map<String, dynamic> dictparm = {
      "message":message
    };
    if(queryHeading != null){
      dictparm.addEntries({"heading_id":queryHeading.id}.entries);
    }
    if(bookingData != null){
      dictparm.addEntries({"booking_number":bookingData.bookingNumber}.entries);
    }
    if(bookingData != null){
      dictparm.addEntries({"library_id":bookingData.libraryId}.entries);
    }



    String url = WebApiConstant.API_URL_POST_QUERY;

    await apiCtrl.submitQueryApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              PopupCustom.submitQueryPopUP(context: context,title: result.message ?? "",description:kQueryDes );
              changeLoadingValue(false);
              changeSuccessValue(true);
              PrintLog.printLog(result.message);

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }

  Future<QueryHeadingResponse?> getQueryHeading({required BuildContext context}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);


    Map<String, dynamic> dictparm = {
      "":""
    };

    String url = WebApiConstant.API_URL_GET_QUERY_HEADING;

    await apiCtrl.queryHeadingApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              queryHeading = result.data;
              bookingData = result.bookingData;
              changeLoadingValue(false);
              changeSuccessValue(true);
              PrintLog.printLog(result.message);

            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }



  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

}

