//
// import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
// import 'package:apna_slot/core/config/colors.dart';
// import 'package:apna_slot/features/app_info/presentation/widgets/common_text_view_widget/app_common_content.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:sizer/sizer.dart';
//
//
// class AppCustomBookSheetDialog extends StatelessWidget {
//
//   final TextEditingController? bookSheetController;
//   void Function()? onTap;
//   AppCustomBookSheetDialog({this.bookSheetController, this.onTap});
//
//   dialogContent(BuildContext context) {
//
//     return Container(
//       decoration: new BoxDecoration(
//         color: Colors.white,
//         shape: BoxShape.rectangle,
//         borderRadius: BorderRadius.circular(5),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black26,
//             blurRadius: 10.0,
//             offset: const Offset(0.0, 10.0),
//           ),
//         ],
//       ),
//       child: Column(
//         mainAxisSize: MainAxisSize.min, // To make the card compact
//         children: <Widget>[
//           Container(
//             height: 8.h,
//             decoration: BoxDecoration(
//               color: AppColors.bluearrowcolor,
//               borderRadius: BorderRadius.only(
//                 topLeft: Radius.circular(5),
//                 topRight: Radius.circular(5),
//               ),
//             ),
//             // child: Center(
//             //     child: AppCommonHeading(text: 'No seats available',color: Colors.white,)
//             // ),
//           ),
//           Container(
//             padding: EdgeInsets.symmetric(vertical: 2.h,horizontal: 5.w),
//             child: Column(
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SvgPicture.asset('assets/icons/chair.svg',),
//                   ],
//                 ),
//                 SizedBox(height: 1.h,),
//                 Container(
//                     width: 100.w,
//                     height: 2.h,
//                     padding: EdgeInsets.all(1.w),
//                     // color: AppColors.greyColorLight,
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: List.generate(8, (index) => Container(
//                         // margin: EdgeInsets.symmetric(horizontal: 2.w),
//                         width: 5.w,height: 2,color: Colors.grey,)),
//                     )
//                 ),
//                 SizedBox(height: 1.h,),
//                 Container(
//                     width: 100.w,
//                     height: 10.h,
//                     padding: EdgeInsets.all(1.w),
//                     // color: AppColors.greyColorLight,
//                     child: AppCommonContent(text: 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock,',maxLines: 3,lineHeight: 1.2,)
//                 ),
//                 SizedBox(height: 3.h,),
//                 Container(
//                   width: 80.w,
//                   height: 7.h,
//                   child: ElevatedButton(
//                     onPressed: onTap,
//                     child: Text(
//                       'Continue',style: TextStyle(fontFamily: FontFamily.josefinRegular,color: Colors.white,fontSize: 18),
//                       textAlign: TextAlign.center,
//                     ),
//                     style: ButtonStyle(
//                         backgroundColor: MaterialStateProperty.all<Color>(AppColors.bluearrowcolor),
//                         shape: MaterialStateProperty.all<RoundedRectangleBorder>(
//                             RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(90),
//                             )
//                         )
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return Dialog(
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(5),
//       ),
//       elevation: 0.0,
//       backgroundColor: Colors.transparent,
//       child: dialogContent(context),
//     );
//   }
// }