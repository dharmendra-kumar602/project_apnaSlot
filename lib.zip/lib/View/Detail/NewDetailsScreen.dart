import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomCheckBox.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomeRattingBar.dart';
import 'package:apna_slot/Controller/WidgetController/Button/ButtonCustom.dart';
import 'package:apna_slot/Controller/WidgetController/Default%20Widget/DefaultWidget.dart';
import 'package:apna_slot/View/Review/ReviewScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:preload_page_view/preload_page_view.dart';
import '../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../Controller/Helper/RedirectToCall/RedirectToCallWidget.dart';
import '../../Controller/Helper/RedirectToMap/RedirectToMap.dart';
import '../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import '../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../Dashboard/Home/HomeScreen/HomeApiResponse.dart';
import '../LibraryBooking/LibraryBookShedual/NewLibraryBookScheduleScreen.dart';
import '../Review/ReviewController.dart';
import 'DetailsController.dart';


class NewDetailScreen extends StatefulWidget {
 final int libraryIndex;
 final  List<HomeData>? detailsListData;
const  NewDetailScreen({Key? key,required this.libraryIndex,required this.detailsListData}) : super(key: key);

  @override
  State<StatefulWidget> createState() { return _NewDetailScreenState(); }
}

class _NewDetailScreenState extends State<NewDetailScreen> {

  DetailController detailCTRL = Get.put(DetailController());
  ReviewController reviewCtrl = Get.put(ReviewController());
  int currentImageIndex = 0;

  TextEditingController reviewCT = TextEditingController();

  double reviewRating = 0.0;
  String? userId;
  String? reviewID;



  @override
  void initState() {
    init();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future init() async {
    PrintLog.printLog("CurrentPage open :${widget.libraryIndex}");
    await detailData();
  }

  Future<void> detailData()async{
    detailCTRL.detailsListData = widget.detailsListData;
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DetailController>(
        init: detailCTRL,
        builder: (controller) {
          return LoadScreen(
              widget: controller.isError ?
              ErrorScreen(
                onTap: () {
                  init();
                },
                isShowBackBtn: true,
              )
                  : controller.isNetworkError ?
              NoInternetConnectionScreen(
                onTap: () {
                  init();
                },
                isShowBackBtn: true,
              )
                  : controller.isEmpty ?
              EmptyDataScreen(
                onTap: () {
                  init();
                },
                isShowBtn: false,
                string: kEmptyData,
                isShowBackBtn: true,
              )
                  : controller.detailsListData != null && controller.isEmpty == false ?
              PreloadPageView.builder(
                controller: PreloadPageController(viewportFraction: 1.0, keepPage: true, initialPage: widget.libraryIndex,),
                physics: const ClampingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: controller.detailsListData?.length,
                preloadPagesCount: 2,
                itemBuilder: (context, pageIndex) {
                  return Scaffold(
                      appBar: CustomAppBar.appBar(
                        title: controller.detailsListData?[pageIndex].firmName ?? '',
                        onTap: (){
                          Get.back();
                        },
                      ),
                      backgroundColor: CustomColors.whiteColor,
                      bottomNavigationBar: 
                      controller.detailsListData?[pageIndex].subscriptions != null && controller.detailsListData![pageIndex].subscriptions!.isNotEmpty && controller.detailsListData?[pageIndex].floorPlan != null && controller.detailsListData![pageIndex].floorPlan!.isNotEmpty ?
                       Padding(
                        padding: const EdgeInsets.only(bottom: 10,left: 15,right: 15),
                        child: ButtonCustom(
                            onPress: (){
                              Get.toNamed(
                                  newLibraryBookScheduleScreenRoute,
                                  arguments: NewLibraryBookScheduleScreen(
                                    //   subscriptions: controller.detailData?.subscriptions ?? [],
                                    //   floorPlan: controller.detailData?.floorPlan ?? [],
                                    //   closeTime: controller.detailData?.closeTime ?? "",
                                    //   openTime: controller.detailData?.openTime ?? "",
                                    // libraryName: controller.detailData?.firmName ?? "",
                                    currentIndex: pageIndex,
                                    homeData: controller.detailsListData?[pageIndex],
                                    isDetail: true,
                                    detailsListData: controller.detailsListData,
                                    currentDate: DateTime.parse(controller.detailsListData?[pageIndex].currentDate ?? "${DateTime.now()}"),
                                    libraryID: controller.detailsListData?[pageIndex].id ?? "0",
                                  )
                              );
                            }, text: kBookNow,
                            buttonWidth: MediaQuery.of(context).size.width, buttonHeight: 50
                        ),
                      ) : const SizedBox.shrink(),
                      body:  SingleChildScrollView(
                        physics: const ClampingScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ///Image swiper
                            Stack(
                              children: [
                                Container(
                                  color: CustomColors.whiteColor,
                                  height: Get.height * 35 / 100,
                                  width: Get.width,
                                  child: controller.detailsListData?[pageIndex].libraryImages != null && controller.detailsListData![pageIndex].libraryImages!.isNotEmpty ?
                                  PageView.builder(
                                      itemCount: controller.detailsListData?[pageIndex].libraryImages?.length,
                                      onPageChanged: (value){
                                        currentImageIndex = value;
                                        setState(() {});
                                      },
                                      itemBuilder: (context, index){
                                        return Container(
                                          width: Get.width,
                                          child: controller.detailsListData?[pageIndex].libraryImages?[index] != null ?
                                          InkWell(
                                            onTap: (){
                                              // showDialog(
                                              //     context: context,
                                              //     builder: (_){
                                              //       return ViewImageSwiper(images: provider.productData?.image,index: index,colorData: provider.colorData,);
                                              //     }
                                              // );
                                            },
                                            child: ImageHelper(
                                              image: controller.detailsListData?[pageIndex].libraryImages?[index] ?? "",
                                              height: MediaQuery.of(context).size.height,
                                              width: MediaQuery.of(context).size.width,
                                              fit: BoxFit.fill,
                                              alignment: Alignment.topCenter,
                                            ),
                                          )
                                              : DefaultWidget.image(),
                                        );
                                      })
                                  : DefaultWidget.image(),
                                ),

                                Positioned(
                                  left: 0.0,
                                  bottom: 0.0,
                                  right: 0.0,
                                  child: Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: List.generate(
                                          controller.detailsListData?[pageIndex].libraryImages?.length ?? 0,
                                              (index) => controller.detailsListData![pageIndex].libraryImages!.length > 1 ? buildDot(context: context,index: index):const SizedBox.shrink()
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),

                            Padding(
                              padding: const EdgeInsets.only(left: 15,right: 15,bottom: 15,top: 15),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  InkWell(
                                    onTap: ()async{
                                     await RedirectToCall.phoneNumberLaunch(phoneNumber: controller.detailsListData?[pageIndex].mobileNumber ?? "");
                                    },
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 30,
                                          height: 30,
                                          decoration: BoxDecoration(
                                              color: CustomColors.bluearrowcolor,
                                              borderRadius: const BorderRadius.all(
                                                  Radius.circular(90)
                                              )
                                          ),
                                          child: Center(
                                            child: SvgPicture.asset(
                                              strSvgPhone,
                                              width: 15,
                                            ),
                                          ),
                                        ),
                                        buildSizeBox(10.0, 10.0),
                                        buildText1(text: controller.detailsListData?[pageIndex].mobileNumber ?? '',color: CustomColors.blackColor,size: 18)
                                      ],
                                    ),
                                  ),
                                  buildSizeBox(10.0, 0.0),

                                  /// Name
                                  buildHeadingBold(
                                    text:
                                    controller.detailsListData?[pageIndex].firmName ?? '',
                                    color: CustomColors.blackColor,
                                    size: 22,
                                    lineHeight: 1.3,
                                  ),
                                  buildSizeBox(5.0, 0.0),

                                  /// Address
                                  buildTextWithHeight(
                                      text: controller.detailsListData?[pageIndex].address ?? '',
                                      size: 16,
                                      height: 1.3,
                                      color: CustomColors.greyColor
                                  ),
                                  buildSizeBox(5.0, 0.0),

                                  /// Direction
                                  InkWell(
                                    onTap: (){
                                      RedirectToMap.redirect(
                                        lat: double.parse(controller.detailsListData?[pageIndex].latitude.toString() ?? kDefaultLat.toString()) ,
                                        lng: double.parse(controller.detailsListData?[pageIndex].longitude.toString() ?? kDefaultLat.toString()),
                                        name: controller.detailsListData?[pageIndex].firmName ?? "" ,
                                      );
                                    },
                                    child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,

                                      children: [
                                        buildHeading(text: kDirection,size: 18),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 10,bottom: 10),
                                          child: SvgPicture.asset(
                                            strSvgNavigation,
                                            width: 35,
                                          ),
                                        ),

                                      ],
                                    ),
                                  ),


                                  const Divider(height: 1,color: Colors.grey ),


                                  /// Description
                                  if (controller.detailsListData?[pageIndex].description != null)...[

                                      Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                                        child: buildTextWithHeight(text: controller.detailsListData?[pageIndex].description ?? '',color: CustomColors.greyColor,height: 1.5,size: 16),
                                      ),
                                      const Divider(height: 1,color: Colors.grey ),

                                  ],
                                  /// Facilities Animation Content
                                  controller.detailsListData?[pageIndex].facility != null && controller.detailsListData![pageIndex].facility!.isNotEmpty ?
                                  Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            buildHeading(text: kFacilities,size: 18),
                                            InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    controller.detailsListData?[pageIndex].isStretchedFacilities = !controller.detailsListData![pageIndex].isStretchedFacilities;
                                                  });
                                                },
                                                child:  Container(
                                                  width: 35,
                                                  height: 35,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(color: Colors.black),
                                                      color: Colors.white,
                                                      borderRadius: const BorderRadius.all(Radius.circular(20))
                                                  ),
                                                  child: Center(
                                                    child: controller.detailsListData?[pageIndex].isStretchedFacilities == true
                                                        ? SvgPicture.asset(strSvgMinus) : SvgPicture.asset(
                                                        strSvgPlus),
                                                  ),
                                                )
                                            )
                                          ],
                                        ),
                                      ),
                                      ExpandedSection(
                                        expand: controller.detailsListData?[pageIndex].isStretchedFacilities == true,
                                        height: MediaQuery.of(context).size.height*0.11,
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                buildText1(text: kOpenHour,size: 16,color: CustomColors.blackColor),
                                                buildText1(text: controller.detailsListData?[pageIndex].openTime ?? "",size: 14,color: CustomColors.greyColor),
                                                buildText1(text: " - ",size: 14,color: CustomColors.greyColor),
                                                buildText1(text: controller.detailsListData?[pageIndex].closeTime ?? "",size: 14,color: CustomColors.greyColor),
                                              ],
                                            ),

                                            /// Facility
                                            controller.detailsListData?[pageIndex].facility != null && controller.detailsListData![pageIndex].facility!.isNotEmpty ?
                                            SizedBox(
                                              height: 40,
                                              width: Get.width,
                                              child: Row(
                                                children: [
                                                  buildText1(text: kFacility,size: 16,color: CustomColors.blackColor),
                                                  Expanded(
                                                    child: ListView.builder(
                                                      itemCount: controller.detailsListData?[pageIndex].facility?.length,
                                                      shrinkWrap: true,
                                                      padding: EdgeInsets.zero,
                                                      scrollDirection: Axis.horizontal,
                                                      physics: const ClampingScrollPhysics(),
                                                      itemBuilder: (context, index) {
                                                        return Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          children: [
                                                            // controller.detailsListData?[pageIndex].facility?[index].image != null && controller.detailsListData?[pageIndex].facility?[index].image != "" ?
                                                            // Image.network(
                                                            //     controller.detailsListData?[pageIndex].facility?[index].image.toString() ?? "", height: 15,
                                                            // ) : const SizedBox.shrink(),
                                                            SizedBox(
                                                              height: 15,
                                                              width: 15,
                                                              child: ImageHelper(
                                                                  image: controller.detailsListData?[pageIndex].facility?[index].image.toString() ?? "",
                                                                  height: 15,
                                                                  width: 15,
                                                                  fit: BoxFit.contain,
                                                                  alignment: Alignment.center),
                                                            ),
                                                            buildSizeBox(0.0, 5.0),
                                                            buildText1(text: controller.detailsListData?[pageIndex].facility?[index].name ?? "",color: CustomColors.greyColor),
                                                            buildSizeBox(0.0, 10.0),
                                                          ],
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )
                                                : const SizedBox.shrink(),


                                          ],
                                        ),
                                      ),
                                      const Divider(height: 1,color: Colors.grey),
                                    ],
                                  )
                                      : const SizedBox.shrink(),



                                  /// Subscription Type Animation Content
                                  controller.detailsListData?[pageIndex].subscriptions != null && controller.detailsListData![pageIndex].subscriptions!.isNotEmpty ?
                                  Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            buildHeading(text: kSubscriptionType,size: 18),
                                            InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    controller.detailsListData?[pageIndex].isStretchedSubscriptionType = !controller.detailsListData![pageIndex].isStretchedSubscriptionType;
                                                  });
                                                },
                                                child:
                                                Container(
                                                  width: 35,
                                                  height: 35,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors
                                                              .black),
                                                      color: Colors.white,
                                                      borderRadius:
                                                      const BorderRadius
                                                          .all(Radius
                                                          .circular(
                                                          90))),
                                                  child: Center(
                                                    child: controller.detailsListData?[pageIndex].isStretchedSubscriptionType == true ? SvgPicture.asset(
                                                        strSvgMinus) : SvgPicture.asset(
                                                        strSvgPlus) ,
                                                  ),
                                                )

                                            )
                                          ],
                                        ),
                                      ),
                                      ExpandedSection(
                                        expand: controller.detailsListData?[pageIndex].isStretchedSubscriptionType == true,
                                        height: controller.detailsListData![pageIndex].subscriptions!.length *40,
                                        child: ListView.builder(
                                            itemCount: controller.detailsListData?[pageIndex].subscriptions?.length,
                                            padding: EdgeInsets.zero,
                                            physics: const ClampingScrollPhysics(),
                                            shrinkWrap: true,
                                            itemBuilder: (context,index){
                                              return Padding(
                                                padding: const EdgeInsets.only(bottom: 10),
                                                child: InkWell(
                                                  onTap: (){
                                                    controller.detailsListData?[pageIndex].subscriptions?.forEach((element) {
                                                      element.isSelected = false;
                                                    });
                                                    if(controller.detailsListData?[pageIndex].subscriptions?[index].isSelected == false){
                                                      controller.detailsListData?[pageIndex].subscriptions?[index].isSelected = true;
                                                    }else{
                                                      controller.detailsListData?[pageIndex].subscriptions?[index].isSelected = false;
                                                    }
                                                    setState(() {});
                                                  },
                                                  child: CheckBoxCustomWithText.box(
                                                      isSelected: controller.detailsListData?[pageIndex].subscriptions?[index].isSelected ?? false,
                                                      text: controller.detailsListData?[pageIndex].subscriptions?[index].name ?? ""
                                                  ),
                                                  // child: CustomCheckBoxWithText(
                                                  //   value: controller.detailData?.subscriptions?[index].isSelected,
                                                  //   label: controller.detailData?.subscriptions?[index].name ?? "",
                                                  //   radius: 0,
                                                  //   height: 40,
                                                  //   width: 50,
                                                  //   space: 20,
                                                  //   onChanged: (value){
                                                  //     // controller.detailData?.subscriptions?.forEach((element) {
                                                  //     //   element.isSelected = false;
                                                  //     // });
                                                  //     // if(controller.detailData?.subscriptions?[index].isSelected == false){
                                                  //     //   controller.detailData?.subscriptions?[index].isSelected = true;
                                                  //     // }else{
                                                  //     //   controller.detailData?.subscriptions?[index].isSelected = false;
                                                  //     // }
                                                  //   },
                                                  // ),
                                                ),
                                              );
                                            }
                                        ),
                                      ),
                                      const Divider(height: 1,color: Colors.grey),
                                    ],
                                  )
                                      : const SizedBox.shrink(),


                                  ///Review Animation Content
                                  controller.detailsListData?[pageIndex].isPurchased == true || controller.detailsListData != null && controller.detailsListData![pageIndex].reviews!.isNotEmpty ?
                                  Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            buildHeading(text: 'Review',size: 18),
                                            InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    controller.detailsListData?[pageIndex].isStretchedReview = !controller.detailsListData![pageIndex].isStretchedReview;
                                                  });
                                                },
                                                child:  Container(
                                                  width: 35,
                                                  height: 35,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors
                                                              .black),
                                                      color: Colors.white,
                                                      borderRadius:
                                                      const BorderRadius
                                                          .all(Radius
                                                          .circular(
                                                          90))),
                                                  child: Center(
                                                    child: controller.detailsListData?[pageIndex].isStretchedReview == true
                                                        ? SvgPicture.asset(
                                                        strSvgMinus) : SvgPicture.asset(
                                                        strSvgPlus),
                                                  ),
                                                )
                                            )
                                          ],
                                        ),
                                      ),
                                      ExpandedSection(
                                        expand: controller.detailsListData?[pageIndex].isStretchedReview == true,
                                        height: 70+(controller.detailsListData != null && controller.detailsListData!.isNotEmpty && controller.detailsListData![pageIndex].reviews != null ? controller.detailsListData![pageIndex].reviews!.length * 120:20),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Expanded(
                                              child: ListView.builder(
                                                  itemCount: controller.detailsListData?[pageIndex].reviews?.length,
                                                  padding: EdgeInsets.zero,
                                                  shrinkWrap: true,
                                                  physics: const ClampingScrollPhysics(),
                                                  itemBuilder: (context,index){
                                                    print("Review Length : ${controller.detailsListData?[pageIndex].reviews?.length}");
                                                    return index > 1 ?
                                                    const SizedBox.shrink()
                                                        : Transform.translate(
                                                      offset: const Offset(-12, 0,),
                                                      child: Column(
                                                        children: [
                                                          ListTile(
                                                            leading: Transform.translate(
                                                                offset: const Offset(0, -9),
                                                                child: Container(
                                                                  height: 40,
                                                                  width: 40,
                                                                  clipBehavior: Clip.antiAlias,
                                                                  decoration: BoxDecoration(
                                                                      shape: BoxShape.circle,
                                                                      border: Border.all(width: 0.3,color: CustomColors.greyColor)
                                                                  ),
                                                                  child: controller.detailsListData?[pageIndex].reviews?[index].image != null ?
                                                                  ImageHelperWhiteBgForProfile(
                                                                    image: controller.detailsListData?[pageIndex].reviews?[index].image ?? '',
                                                                    height: MediaQuery.of(context).size.height,
                                                                    width: MediaQuery.of(context).size.width,
                                                                    fit: BoxFit.cover,
                                                                    alignment: Alignment.topCenter,
                                                                  ):DefaultWidget.image(),
                                                                )
                                                            ),
                                                            title: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: [
                                                                buildHeading(text: controller.detailsListData?[pageIndex].reviews?[index].name ?? "",size: 16),
                                                                buildTextCommon(
                                                                  text: controller.detailsListData?[pageIndex].reviews?[index].address ?? "",
                                                                  size: 14,
                                                                ),
                                                                buildSizeBox(3.0, 0.0),
                                                                CustomRattingBar(
                                                                  ignoreGesture: true,
                                                                  stars: double.parse(controller.detailsListData?[pageIndex].reviews?[index].ratingCount ?? "0.0"),
                                                                  onRatingUpdate: (value){
                                                                    PrintLog.printLog("Star: $value");
                                                                  },
                                                                ),
                                                                buildSizeBox(10.0, 0.0)
                                                              ],
                                                            ),
                                                            subtitle: Column(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                buildTextWithHeight(
                                                                    text:
                                                                    controller.detailsListData?[pageIndex].reviews?[index].review ?? "",
                                                                    size: 14,
                                                                    height: 1.1,
                                                                    color: CustomColors.greyColor
                                                                ),
                                                                buildSizeBox(10.0, 0.0),
                                                                const Divider(height: 1,color: Colors.grey),
                                                                buildSizeBox(10.0, 0.0),
                                            
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  }
                                              ),
                                            ),
                                            controller.detailsListData != null && controller.detailsListData!.isNotEmpty && controller.detailsListData![pageIndex].reviews != null && controller.detailsListData![pageIndex].reviews!.length <= 2 ?
                                            Visibility(
                                              visible: controller.detailsListData?[pageIndex].isPurchased == true,
                                              child: Padding(
                                                padding: EdgeInsets.only(top: controller.detailsListData != null && controller.detailsListData!.isNotEmpty && controller.detailsListData![pageIndex].reviews!.isNotEmpty ? 10.0 : 0.0),
                                                child:
                                                InkWell(
                                                  onTap: () {
                                                    reviewRating = 1.0;
                                                    reviewCT.clear();
                                                    reviewID = "";
                                                    if(controller.detailsListData?[pageIndex].checkReview == true){
                                                      int indexID = controller.detailsListData![pageIndex].reviews!.indexWhere((element) => element.userId .toString() == AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId).toString());

                                                      if(indexID >= 0){
                                                        reviewID = controller.detailsListData?[pageIndex].reviews?[indexID].id.toString() ?? "";
                                                        reviewRating = double.parse(controller.detailsListData?[pageIndex].reviews?[indexID].ratingCount.toString() ?? "0.0");
                                                        reviewCT.text = controller.detailsListData?[pageIndex].reviews?[indexID].review ?? "";
                                                      }
                                                    }
                                                    // controller.detailsListData?[pageIndex].checkReview == false
                                                    // if(controller.detailsListData?[pageIndex].checkReview == false) {
                                                    //   // BottomSheetCustom.review(context: context, image: productData.image != null && productData.image!.isNotEmpty ? productData.image![0].toString() : "",title: productData.title.toString() ?? "",productID: productData.id.toString() ?? "",initialRating: "0.0",reviewID: "",des: "",onValue: (value){
                                                    //   //   init(categoryId: widget.id);
                                                    //   // });
                                                    // }else if (controller.detailsListData?[pageIndex].checkReview == true){
                                                    //   // PrintLog.printLog("Edit Review");
                                                    //   // int indexID = productData.reviews!.indexWhere((element) => element.cusId.toString() == customerId.toString());
                                                    //   // // bool indexID = productData.reviews!.any((element) => element.cusId.toString() == customerId.toString());
                                                    //   // // print("object...${indexID}");
                                                    //   //
                                                    //   // if(indexID >= 0){
                                                    //   //   BottomSheetCustom.review(context: context, image: productData.image != null && productData.image!.isNotEmpty ? productData.image![0].toString() : "",title: productData.title.toString() ?? "",productID: productData.id.toString() ?? "",initialRating: productData.reviews?[indexID].rating ?? "",reviewID: productData.reviews?[indexID].reviewId ?? "",des: productData.reviews?[indexID].review ?? "",onValue: (value){
                                                    //   //     if(value == true) {
                                                    //   //       init(categoryId: widget.id);
                                                    //   //     }
                                                    //   //   });
                                                    //   // }
                                                    // }

                                                    PopupCustom.addReviewPopUp(
                                                        context: context,
                                                        btnTitle: kSubmit,//controller.reviewApiResponse?.isSubscription == true ? kEditReview:kAddReview,
                                                        stars: reviewRating,
                                                        reviewController: reviewCT,
                                                        onTap: () async {
                                                          if(reviewCT.text.toString().trim().isNotEmpty){
                                                            PrintLog.printLog("Review Added: libraryId: ${controller.detailsListData?[pageIndex].id} \nRating count: $reviewRating \n comment: ${reviewCT.text}");
                                                            await reviewCtrl.updateReview(context: context,libraryID: controller.detailsListData?[pageIndex].id.toString() ?? "" ,comment: reviewCT.text.toString().trim(),ratingCount:reviewRating.toString(),reviewID: controller.detailsListData?[pageIndex].checkReview == true ? reviewID.toString():"").then((value) {
                                                              Get.back();
                                                              if(reviewCtrl.isSuccess == true){
                                                                int indexID2 = controller.detailsListData![pageIndex].reviews!.indexWhere((element) => element.userId .toString() == AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId).toString());
                                                                if(indexID2 >=0){
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].id = 201;
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].userId = int.parse(AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId).toString());
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].name = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName).toString();
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].review = reviewCT.text.toString().trim();
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].image = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg).toString();
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].ratingCount = reviewRating.toString();
                                                                  controller.detailsListData?[pageIndex].reviews?[indexID2].address = "";
                                                                }else{
                                                                  HomeReviews homeReview = HomeReviews();
                                                                  homeReview.id = 201;
                                                                  homeReview.userId = int.parse(AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId).toString());
                                                                  homeReview.name = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userName).toString();
                                                                  homeReview.review = reviewCT.text.toString().trim();
                                                                  homeReview.image = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userProfileImg).toString();
                                                                  homeReview.ratingCount = reviewRating.toString();
                                                                  homeReview.address = "";
                                                                  controller.detailsListData?[pageIndex].reviews?.add(homeReview);
                                                                  controller.detailsListData?[pageIndex].checkReview = true;
                                                                }
                                                                setState(() {});
                                                              }
                                                            });
                                                          }else{
                                                            ToastCustom.showToast(msg: kReviewToastString);
                                                          }
                                                        },
                                                        onRatingUpdate: (value){
                                                          reviewRating = value.toDouble();
                                                        },
                                                        onValue: (value){
                                                          if(value == true){
                                                            init();
                                                          }
                                                        }
                                                    );

                                                  },
                                                  child: Center(
                                                    child: Container(
                                                      alignment: Alignment.center,
                                                      height: 35,
                                                      width: 120,
                                                      margin: const EdgeInsets.only(bottom: 20),
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: CustomColors.bluearrowcolor),
                                                        color: CustomColors.whiteColor,
                                                        borderRadius: BorderRadius.circular(10),
                                                      ),
                                                      child: buildText1(text: controller.detailsListData?[pageIndex].checkReview == false ? kWriteReview:kUpdateReview, color: CustomColors.bluearrowcolor),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )
                                                :
                                            Row(
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              children: [
                                                InkWell(
                                                  onTap: (){
                                                    Get.toNamed(reviewScreenRoute,arguments: ReviewScreen(libraryID: controller.detailsListData?[pageIndex].id ?? "0"));
                                                  },
                                                  child: Container(
                                                    height: 30,
                                                    width: 80,
                                                    padding: const EdgeInsets.only(bottom: 10,right: 5),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.end,
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      children: [
                                                        buildText1(text: "${int.parse(controller.detailsListData?[pageIndex].totalReviews.toString() ?? "0")-2} $kMore",fontFamily: FontFamily.josefinBold,color: CustomColors.greyColor)
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            )

                                          ]
                                        ),
                                      ),


                                    ],
                                  )
                                      : const SizedBox.shrink(),



                                ],
                              ),
                            ),

                            // controller.detailsListData != null && controller.detailsListData!.isNotEmpty && controller.detailsListData![pageIndex].reviews != null && controller.detailsListData![pageIndex].reviews!.length <= 2 ?
                            // Visibility(
                            //   visible: controller.detailsListData?[pageIndex].isPurchased == true,
                            //   child: Padding(
                            //     padding: EdgeInsets.only(top: controller.detailsListData != null && controller.detailsListData!.isNotEmpty && controller.detailsListData![pageIndex].reviews!.isNotEmpty ? 30.0 : 0.0),
                            //     child:
                            //     InkWell(
                            //       onTap: () {
                            //         // controller.detailsListData?[pageIndex].checkReview == false
                            //         if(controller.detailsListData?[pageIndex].checkReview == false) {
                            //           // BottomSheetCustom.review(context: context, image: productData.image != null && productData.image!.isNotEmpty ? productData.image![0].toString() : "",title: productData.title.toString() ?? "",productID: productData.id.toString() ?? "",initialRating: "0.0",reviewID: "",des: "",onValue: (value){
                            //           //   init(categoryId: widget.id);
                            //           // });
                            //         }else if (controller.detailsListData?[pageIndex].checkReview == true){
                            //           // PrintLog.printLog("Edit Review");
                            //           // int indexID = productData.reviews!.indexWhere((element) => element.cusId.toString() == customerId.toString());
                            //           // // bool indexID = productData.reviews!.any((element) => element.cusId.toString() == customerId.toString());
                            //           // // print("object...${indexID}");
                            //           //
                            //           // if(indexID >= 0){
                            //           //   BottomSheetCustom.review(context: context, image: productData.image != null && productData.image!.isNotEmpty ? productData.image![0].toString() : "",title: productData.title.toString() ?? "",productID: productData.id.toString() ?? "",initialRating: productData.reviews?[indexID].rating ?? "",reviewID: productData.reviews?[indexID].reviewId ?? "",des: productData.reviews?[indexID].review ?? "",onValue: (value){
                            //           //     if(value == true) {
                            //           //       init(categoryId: widget.id);
                            //           //     }
                            //           //   });
                            //           // }
                            //         }
                            //
                            //       },
                            //       child: Center(
                            //         child: Container(
                            //           alignment: Alignment.center,
                            //           height: 35,
                            //           width: 120,
                            //           margin: const EdgeInsets.only(bottom: 20),
                            //           decoration: BoxDecoration(
                            //             border: Border.all(color: CustomColors.bluearrowcolor),
                            //             color: CustomColors.whiteColor,
                            //             borderRadius: BorderRadius.circular(10),
                            //           ),
                            //           child: buildText1(text: controller.detailsListData?[pageIndex].checkReview == false ? kWriteReview:kUpdateReview, color: CustomColors.bluearrowcolor),
                            //         ),
                            //       ),
                            //     ),
                            //   ),
                            // )
                            //     :
                            // Row(
                            //   crossAxisAlignment: CrossAxisAlignment.end,
                            //   mainAxisAlignment: MainAxisAlignment.end,
                            //   children: [
                            //     InkWell(
                            //       onTap: (){
                            //         Get.toNamed(reviewScreenRoute,arguments: ReviewScreen(libraryID: controller.detailsListData?[pageIndex].id ?? "0"));
                            //       },
                            //       child: Container(
                            //         height: 30,
                            //         width: 80,
                            //         padding: const EdgeInsets.only(bottom: 10,right: 5),
                            //         child: Row(
                            //           mainAxisAlignment: MainAxisAlignment.end,
                            //           crossAxisAlignment: CrossAxisAlignment.end,
                            //           children: [
                            //             buildText1(text: "${int.parse(controller.detailsListData?[pageIndex].totalReviews.toString() ?? "0")-2} $kMore",fontFamily: FontFamily.josefinBold,color: CustomColors.greyColor)
                            //           ],
                            //         ),
                            //       ),
                            //     ),
                            //   ],
                            // )

                          ],
                        ),
                      )
                  );
                },
              )
                  : const SizedBox.shrink(),
              isLoading: controller.isLoading
          );
        });
  }


  buildDot({required int index, required BuildContext context}) {
    return Container(
      height: 10,
      width: 10,
      margin: const EdgeInsets.only(bottom: 5, left: 1.0,right: 1.0),
      padding: const EdgeInsets.all(1.5),
      decoration: BoxDecoration(
        color: currentImageIndex == index ? CustomColors.bluearrowcolor : CustomColors.whiteColor,
        shape: BoxShape.circle,
      ),
    );
  }


}

class ExpandedSection extends StatefulWidget {
  final Widget child;
  final double height;
  final bool expand;

  const ExpandedSection(
      {this.expand = false, required this.child, required this.height});

  @override
  State<ExpandedSection> createState() => _ExpandedSectionState();
}

class _ExpandedSectionState extends State<ExpandedSection> with SingleTickerProviderStateMixin {
  AnimationController? expandController;
  Animation<double>? animation;

  @override
  void initState() {
    super.initState();
    prepareAnimations();
    _runExpandCheck();
  }

  ///Setting up the animation
  void prepareAnimations() {
    expandController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    animation = CurvedAnimation(
      parent: expandController!,
      curve: Curves.fastOutSlowIn,
    );
  }

  void _runExpandCheck() {
    if (widget.expand) {
      expandController!.forward();
    } else {
      expandController!.reverse();
    }
  }

  @override
  void didUpdateWidget(ExpandedSection oldWidget) {
    super.didUpdateWidget(oldWidget);
    _runExpandCheck();
  }

  @override
  void dispose() {
    expandController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
        axisAlignment: 1.0,
        sizeFactor: animation!,
        child: Container(
          padding: const EdgeInsets.only(bottom: 5),
          constraints: BoxConstraints(
              minWidth: double.infinity,
              maxHeight: widget.height
          ),
          child: Padding(
              padding: const EdgeInsets.only(bottom: 5), child: widget.child),
        ));
  }
}


















// class DetailScreen extends StatefulWidget {
//   LibraryDetailsPageArguments libraryDetailsPageArguments;

//   DetailScreen({Key? key, required this.libraryDetailsPageArguments})
//       : super(key: key);
//   _DetailScreenState createState() => _DetailScreenState();
// }

// class _DetailScreenState extends State<DetailScreen> {
//   bool isStrechedFacilities = false;
//   bool isStrechedSubscriptionType = false;
//   bool isStrechedReview = false;

//   @override
//   void initState() {
//     super.initState();
//     BlocProvider.of<LibraryDetailsCubit>(context)
//         .getLibraryDetails(id: widget.libraryDetailsPageArguments.libraryId);
//   }

//   int _current = 0;
//   final CarouselController _controller = CarouselController();

//   @override
//   Widget build(BuildContext context) {
//     final libraryDetailsCubit = context.read<LibraryDetailsCubit>();

//     return Scaffold(
//         appBar: PreferredSize(
//           preferredSize: Size.fromHeight(8.h),
//           child: AppCommonAppBar(
//             title: 'Details ',
//           ),
//         ),
//         body: BlocBuilder<LibraryDetailsCubit, LibraryDetailsState>(
//           builder: (context, state) {
//             if (state is LibraryDetailsLoadingState) {
//               return const Center(
//                 child: CircularProgressIndicator(),
//               );
//             }
//             if (state is LibraryDetailsSuccessState) {
//               return SingleChildScrollView(
//                 child: Column(
//                   children: [
//                     Stack(
//                       children: [
//                         CarouselSlider(
//                           items: List.generate(
//                               libraryDetailsCubit.getLibraryDetailsResponse!
//                                   .data.libraryImages.length,
//                                   (index) => libraryDetailsCubit
//                                   .getLibraryDetailsResponse!
//                                   .data
//                                   .libraryImages !=
//                                   [] &&
//                                   libraryDetailsCubit
//                                       .getLibraryDetailsResponse!
//                                       .data
//                                       .libraryImages
//                                       .isNotEmpty
//                                   ? Container(
//                                   decoration: BoxDecoration(
//                                       image: DecorationImage(
//                                           image: NetworkImage(
//                                               libraryDetailsCubit
//                                                   .getLibraryDetailsResponse!
//                                                   .data
//                                                   .libraryImages[index]
//                                                   .toString()),
//                                           fit: BoxFit.cover)))
//                                   : Placeholder(
//                                 color: Colors.red,
//                               )),
//                           options: CarouselOptions(
//                               height: 25.h,
//                               enlargeCenterPage: true,
//                               autoPlay: true,
//                               // disableCenter: false,
//                               aspectRatio: 16 / 9,
//                               autoPlayCurve: Curves.fastOutSlowIn,
//                               enableInfiniteScroll: true,
//                               autoPlayAnimationDuration:
//                               Duration(milliseconds: 200),
//                               viewportFraction: 1,
//                               onPageChanged: (index, reason) {
//                                 setState(() {
//                                   _current = index;
//                                 });
//                               }),
//                         ),
//                         Positioned(
//                             left: 10,
//                             right: 10,
//                             bottom: 10,
//                             child: Row(
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: libraryDetailsCubit
//                                   .getLibraryDetailsResponse!.data.libraryImages
//                                   .asMap()
//                                   .entries
//                                   .map((entry) {
//                                 return GestureDetector(
//                                     onTap: () =>
//                                         _controller.animateToPage(entry.key),
//                                     child: Container(
//                                       width: 3.w,
//                                       height: 3.w,
//                                       margin: EdgeInsets.symmetric(
//                                           vertical: 8.0, horizontal: 4.0),
//                                       decoration: BoxDecoration(
//                                         shape: BoxShape.circle,
//                                         color: _current == entry.key
//                                             ? Color.fromRGBO(74, 0, 224, 1)
//                                             : Colors.white,
//                                       ),
//                                     ));
//                               }).toList(),
//                             ))
//                       ],
//                     ),
//                     // AppCommonCarouselSlider(
//                     //   height: 25.h,
//                     // ),
//                     Container(
//                       padding:
//                       EdgeInsets.symmetric(vertical: 1.h, horizontal: 3.w),
//                       // color: Colors.pink,
//                       width: 100.w,
//                       height: 56.h,
//                       child: Column(
//                         children: [
//                           Expanded(
//                             child: ListView(
//                               // controller: ,
//                               physics: const BouncingScrollPhysics(),
//                               shrinkWrap: true,
//                               children: [
//                                 Row(
//                                   children: [
//                                     Container(
//                                       width: 7.w,
//                                       height: 7.w,
//                                       decoration: BoxDecoration(
//                                           color: AppColors.bluearrowcolor,
//                                           borderRadius: BorderRadius.all(
//                                               Radius.circular(90))),
//                                       child: Center(
//                                         child: SvgPicture.asset(
//                                           'assets/icons/phone.svg',
//                                           width: 3.w,
//                                         ),
//                                         // Image.asset('assets/icons/phone2.png',width: 3.w,),
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       width: 2.w,
//                                     ),
//                                     AppCommonHeading(
//                                       text:
//                                       '+91 ${libraryDetailsCubit.getLibraryDetailsResponse!.data!.mobileNumber}',
//                                       size: 2.5.h,
//                                     )
//                                   ],
//                                 ),
//                                 SizedBox(
//                                   height: 2.h,
//                                 ),
//                                 AppCommonHeadingBold(
//                                   text:
//                                   '${libraryDetailsCubit.getLibraryDetailsResponse!.data!.firmName}',
//                                   size: 2.7.h,
//                                   lineHeight: 1.3,
//                                 ),
//                                 SizedBox(
//                                   height: 1.h,
//                                 ),
//                                 AppCommonContent(
//                                   text:
//                                   '${libraryDetailsCubit.getLibraryDetailsResponse!.data!.address}',
//                                   size: 1.9.h,
//                                   lineHeight: 1.5,
//                                   maxLines: 2,
//                                 ),
//                                 SizedBox(
//                                   height: 2.h,
//                                 ),
//                                 Column(
//                                   children: [
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                       children: [
//                                         AppCommonHeadingBold(text: 'Direction'),
//                                         SvgPicture.asset(
//                                           'assets/icons/navigate.svg',
//                                           width: 7.w,
//                                         ),
//                                         // Image.asset('assets/icons/navigate.png',width: 7.w,),
//                                       ],
//                                     ),
//                                     SizedBox(
//                                       height: 2.h,
//                                     ),
//                                     const Divider(
//                                       height: 1,
//                                       color: Colors.grey,
//                                     ),
//                                     SizedBox(
//                                       height: 2.h,
//                                     ),
//                                     AppCommonContent(
//                                       text:
//                                       'This is a world class library in the town , feel free to visit ',
//                                       size: 1.9.h,
//                                       lineHeight: 1.5,
//                                       maxLines: 4,
//                                     ),
//                                     SizedBox(
//                                       height: 2.h,
//                                     ),
//                                     const Divider(
//                                       height: 1,
//                                       color: Colors.grey,
//                                     ),

//                                     /// Facilities Animation Content
//                                     Column(
//                                       children: [
//                                         Row(
//                                           mainAxisAlignment:
//                                           MainAxisAlignment.spaceBetween,
//                                           children: [
//                                             AppCommonHeadingBold(
//                                                 text: 'Facilities'),
//                                             IconButton(
//                                                 onPressed: () {
//                                                   setState(() {
//                                                     isStrechedFacilities =
//                                                     !isStrechedFacilities;
//                                                   });
//                                                 },
//                                                 icon: isStrechedFacilities
//                                                     ? Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/minus.svg'),
//                                                   ),
//                                                 )
//                                                     : Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/plus.svg'),
//                                                   ),
//                                                 ))
//                                           ],
//                                         ),
//                                         ExpandedSection(
//                                           expand: isStrechedFacilities,
//                                           height: 10.h,
//                                           child: Column(
//                                             children: [
//                                               Row(
//                                                 mainAxisAlignment:
//                                                 MainAxisAlignment
//                                                     .spaceBetween,
//                                                 children: [
//                                                   Row(
//                                                     children: [
//                                                       Text('Open hours : ',
//                                                           style: TextStyle(
//                                                               fontFamily: FontFamily
//                                                                   .josefinRegular,
//                                                               fontSize: 16)),
//                                                       Text(
//                                                         '8AM - 9PM',
//                                                         style: TextStyle(
//                                                             fontFamily: FontFamily
//                                                                 .josefinRegular,
//                                                             fontSize: 14,
//                                                             color: const Color
//                                                                 .fromRGBO(
//                                                                 139,
//                                                                 139,
//                                                                 139,
//                                                                 1)),
//                                                       )
//                                                     ],
//                                                   ),
//                                                 ],
//                                               ),
//                                               SizedBox(
//                                                 height: 2.h,
//                                               ),
//                                               Row(
//                                                 // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                                 children: [
//                                                   Text('Facility : ',
//                                                       style: TextStyle(
//                                                           fontFamily: FontFamily
//                                                               .josefinRegular,
//                                                           fontSize: 16)),
//                                                   SizedBox(
//                                                     width: 1.w,
//                                                   ),
//                                                   AppCommonIconWithText(
//                                                       text: libraryDetailsCubit
//                                                           .getLibraryDetailsResponse!
//                                                           .data
//                                                           .firmName
//                                                           .toString(),
//                                                       icon:
//                                                       'assets/icons/book.svg',
//                                                       isSvg: true),
//                                                   SizedBox(
//                                                     width: 4.w,
//                                                   ),
//                                                   AppCommonIconWithText(
//                                                       text: 'Wifi',
//                                                       icon:
//                                                       'assets/icons/wifi.png',
//                                                       isSvg: false)
//                                                 ],
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ],
//                                     ),

//                                     /// Facilities Animation Content
//                                     const Divider(
//                                       height: 1,
//                                       color: Colors.grey,
//                                     ),

//                                     /// Subscription Type Animation Content
//                                     Column(
//                                       children: [
//                                         Row(
//                                           mainAxisAlignment:
//                                           MainAxisAlignment.spaceBetween,
//                                           children: [
//                                             AppCommonHeadingBold(
//                                                 text: 'Subscription Type'),
//                                             IconButton(
//                                                 onPressed: () {
//                                                   setState(() {
//                                                     isStrechedSubscriptionType =
//                                                     !isStrechedSubscriptionType;
//                                                   });
//                                                 },
//                                                 icon: isStrechedSubscriptionType
//                                                     ? Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/minus.svg'),
//                                                   ),
//                                                 )
//                                                     : Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/plus.svg'),
//                                                   ),
//                                                 ))
//                                           ],
//                                         ),
//                                         ExpandedSection(
//                                           expand: isStrechedSubscriptionType,
//                                           height: 10.h,
//                                           child: Column(
//                                             mainAxisAlignment:
//                                             MainAxisAlignment.start,
//                                             crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                             children: [
//                                               AppCommonCheckBoxWithText(
//                                                 value: true,
//                                                 label: 'Monthly',
//                                                 radius: 0,
//                                                 height: 4.h,
//                                                 width: 5.w,
//                                                 space: 2.w,
//                                               ),

//                                               SizedBox(
//                                                 height: 1.h,
//                                               ),

//                                               AppCommonCheckBoxWithText(
//                                                 value: false,
//                                                 label:
//                                                 'Daily (Available with Premium Library plan)',
//                                                 radius: 0,
//                                                 height: 4.h,
//                                                 width: 5.w,
//                                                 space: 2.w,
//                                               ),

//                                               // AppCommonCheckBoxWithText(
//                                               //   label: 'Daily (Available with Premium Library plan)',
//                                               //   value: false,
//                                               // ),
//                                             ],
//                                           ),
//                                         ),
//                                       ],
//                                     ),

//                                     /// Subscription Type Animation Content
//                                     const Divider(
//                                       height: 1,
//                                       color: Colors.grey,
//                                     ),

//                                     /// Review Animation Content
//                                     Column(
//                                       children: [
//                                         Row(
//                                           mainAxisAlignment:
//                                           MainAxisAlignment.spaceBetween,
//                                           children: [
//                                             AppCommonHeadingBold(
//                                                 text: 'Review'),
//                                             IconButton(
//                                                 onPressed: () {
//                                                   setState(() {
//                                                     isStrechedReview =
//                                                     !isStrechedReview;
//                                                   });
//                                                 },
//                                                 icon: isStrechedReview
//                                                     ? Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/minus.svg'),
//                                                   ),
//                                                 )
//                                                     : Container(
//                                                   width: 7.w,
//                                                   height: 7.w,
//                                                   decoration: BoxDecoration(
//                                                       border: Border.all(
//                                                           color: Colors
//                                                               .black),
//                                                       color: Colors.white,
//                                                       borderRadius:
//                                                       BorderRadius
//                                                           .all(Radius
//                                                           .circular(
//                                                           90))),
//                                                   child: Center(
//                                                     child: SvgPicture.asset(
//                                                         'assets/icons/plus.svg'),
//                                                   ),
//                                                 ))
//                                           ],
//                                         ),
//                                         ExpandedSection(
//                                           expand: isStrechedReview,
//                                           height: 35.h,
//                                           child: Column(
//                                             children: [
//                                               ReviewItem(
//                                                 showDivider: true,
//                                               ),
//                                               SizedBox(
//                                                 height: 2.h,
//                                               ),
//                                               ReviewItem(
//                                                 showDivider: false,
//                                               )
//                                             ],
//                                           ),
//                                         ),
//                                       ],
//                                     ),

//                                     /// Review Animation Content
//                                     const Divider(
//                                       height: 1,
//                                       color: Colors.grey,
//                                     ),
//                                     SizedBox(
//                                       height: 5.h,
//                                     )
//                                   ],
//                                 )
//                               ],
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                     AppCommonButton(
//                       onPress: () {
//                         Navigator.pushNamed(context, AppRoutes.bookedSlotPage);
//                       },
//                       buttonWidth: 90.w,
//                       buttonHeight: 6.5.h,
//                       text: 'Book Now',
//                     ),
//                   ],
//                 ),
//               );
//             }
//             return Container();
//           },
//         ));
//   }
// }

// class ReviewItem extends StatelessWidget {
//   bool? showDivider = false;
//   ReviewItem({Key? key, this.showDivider}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.start,
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Container(
//         //   width: 20.w,
//         //   child:
//         // ),
//         CircleAvatar(
//           backgroundImage: AssetImage('assets/images/user.jpg'),
//         ),
//         SizedBox(
//           width: 2.w,
//         ),
//         Container(
//           width: 80.w,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               AppCommonHeading(text: 'Ravi saxena'),
//               AppCommonContent(
//                 text: 'Pratap Nagar, Jaipur',
//                 size: 14,
//               ),
//               AppCommonRatingBar(
//                 stars: 3,
//               ),
//               SizedBox(
//                 height: 1.h,
//               ),
//               AppCommonContent(
//                 text:
//                 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
//                 maxLines: 2,
//                 lineHeight: 1.1,
//               ),
//               SizedBox(
//                 height: 1.h,
//               ),
//               showDivider == true
//                   ? const Divider(
//                 height: 1,
//                 color: Colors.grey,
//               )
//                   : SizedBox(),
//             ],
//           ),
//         )
//       ],
//     );
//   }
// }

// class ExpandedSection extends StatefulWidget {
//   final Widget child;
//   final double height;
//   final bool expand;

//   ExpandedSection(
//       {this.expand = false, required this.child, required this.height});

//   @override
//   _ExpandedSectionState createState() => _ExpandedSectionState();
// }

// class _ExpandedSectionState extends State<ExpandedSection>
//     with SingleTickerProviderStateMixin {
//   AnimationController? expandController;
//   Animation<double>? animation;

//   @override
//   void initState() {
//     super.initState();
//     prepareAnimations();
//     _runExpandCheck();
//   }

//   ///Setting up the animation
//   void prepareAnimations() {
//     expandController =
//         AnimationController(vsync: this, duration: Duration(milliseconds: 500));
//     animation = CurvedAnimation(
//       parent: expandController!,
//       curve: Curves.fastOutSlowIn,
//     );
//   }

//   void _runExpandCheck() {
//     if (widget.expand) {
//       expandController!.forward();
//     } else {
//       expandController!.reverse();
//     }
//   }

//   @override
//   void didUpdateWidget(ExpandedSection oldWidget) {
//     super.didUpdateWidget(oldWidget);
//     _runExpandCheck();
//   }

//   @override
//   void dispose() {
//     expandController!.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return SizeTransition(
//         axisAlignment: 1.0,
//         sizeFactor: animation!,
//         child: Container(
//           padding: EdgeInsets.only(bottom: 5),
//           constraints: BoxConstraints(
//             //minHeight: 100,
//               minWidth: double.infinity,
//               maxHeight: widget.height
//             // widget.height > 5 ? 195 : widget.height == 1?55:widget.height * 50.0
//           ),
//           child: Padding(
//               padding: const EdgeInsets.only(bottom: 5), child: widget.child),
//         ));
//   }
// }

// class LibraryDetailsPageArguments {
//   String? libraryId;
//   LibraryDetailsPageArguments({this.libraryId});
// }
