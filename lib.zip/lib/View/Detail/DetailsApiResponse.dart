class GetDetailResponse {
  bool? error;
  String? message;
  int? errorCode;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  DetailData? data;

  GetDetailResponse(
      {this.error,
        this.message,
        this.errorCode,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.data});

  GetDetailResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    data = json['data'] != null ? new DetailData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class DetailData {
  String? id;
  String? userId;
  String? firmName;
  String? ownerName;
  String? gstin;
  String? panNumber;
  String? mobileNumber;
  String? city;
  String? state;
  String? address;
  String? area;
  String? pincode;
  String? country;
  String? communicationAddress;
  String? closeTime;
  String? openTime;
  String? bankName;
  String? ifscCode;
  String? accountNumber;
  String? accountHolderName;
  List<String>? libraryImages;
  String? latitude;
  String? longitude;
  String? subscriptionId;
  String? deletedAt;
  String? createdAt;
  String? updatedAt;
  String? floorPlanHeight;
  String? floorPlanWidth;
  List<DetailFacility>? facility;
  List<DetailReviews>? reviews;
  String? totalReviews;
  String? rating;
  List<DetailSubscriptions>? subscriptions;
  List<DetailFloorPlan>? floorPlan;
  String? description;
  List<DetailGetFloors>? getFloors;
  String? currentDate;

  DetailData(
      {this.id,
        this.userId,
        this.firmName,
        this.ownerName,
        this.gstin,
        this.panNumber,
        this.mobileNumber,
        this.city,
        this.state,
        this.address,
        this.area,
        this.pincode,
        this.country,
        this.communicationAddress,
        this.closeTime,
        this.openTime,
        this.bankName,
        this.ifscCode,
        this.accountNumber,
        this.accountHolderName,
        this.libraryImages,
        this.latitude,
        this.longitude,
        this.subscriptionId,
        this.deletedAt,
        this.createdAt,
        this.updatedAt,
        this.floorPlanHeight,
        this.floorPlanWidth,
        this.facility,
        this.reviews,
        this.totalReviews,
        this.rating,
        this.subscriptions,
        this.floorPlan,
        this.description,
        this.getFloors,
        this.currentDate});

  DetailData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    userId = json['user_id'] != null ? json['user_id'].toString():null;
    firmName = json['firm_name'] != null ? json['firm_name'].toString():null;
    ownerName = json['owner_name'] != null ? json['owner_name'].toString():null;
    gstin = json['gstin'] != null ? json['gstin'].toString():null;
    panNumber = json['pan_number'] != null ? json['pan_number'].toString():null;
    mobileNumber = json['mobile_number'] != null ? json['mobile_number'].toString():null;
    city = json['city'] != null ? json['city'].toString():null;
    state = json['state'] != null ? json['state'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    area = json['area'] != null ? json['area'].toString():null;
    pincode = json['pincode'] != null ? json['pincode'].toString():null;
    country = json['country'] != null ? json['country'].toString():null;
    communicationAddress = json['communication_address'] != null ? json['communication_address'].toString():null;
    closeTime = json['close_time'] != null ? json['close_time'].toString():null;
    openTime = json['open_time'] != null ? json['open_time'].toString():null;
    bankName = json['bank_name'] != null ? json['bank_name'].toString():null;
    ifscCode = json['ifsc_code'] != null ? json['ifsc_code'].toString():null;
    accountNumber = json['account_number'] != null ? json['account_number'].toString():null;
    accountHolderName = json['account_holder_name'] != null ? json['account_holder_name'].toString():null;
    libraryImages = json['library_images'].cast<String>();
    latitude = json['latitude'] != null ? json['latitude'].toString():null;
    longitude = json['longitude'] != null ? json['longitude'].toString():null;
    subscriptionId = json['subscription_id'] != null ? json['subscription_id'].toString():null;
    deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
    floorPlanHeight = json['floor_plan_height'] != null ? json['floor_plan_height'].toString():null;
    floorPlanWidth =  json['floor_plan_width'] != null ? json['floor_plan_width'].toString():null;
    if (json['facility'] != null) {
      facility = <DetailFacility>[];
      json['facility'].forEach((v) {
        facility!.add(new DetailFacility.fromJson(v));
      });
    }
    if (json['reviews'] != null) {
      reviews = <DetailReviews>[];
      json['reviews'].forEach((v) {
        reviews!.add(new DetailReviews.fromJson(v));
      });
    }
    if (json['subscriptions'] != null) {
      subscriptions = <DetailSubscriptions>[];
      json['subscriptions'].forEach((v) {
        subscriptions!.add(new DetailSubscriptions.fromJson(v));
      });
    }
    if (json['floor_plan'] != null) {
      floorPlan = <DetailFloorPlan>[];
      json['floor_plan'].forEach((v) {
        floorPlan!.add(new DetailFloorPlan.fromJson(v));
      });
    }
    description = json['description'] != null ? json['description'].toString():null;
    if (json['get_floors'] != null) {
      getFloors = <DetailGetFloors>[];
      json['get_floors'].forEach((v) {
        getFloors!.add(new DetailGetFloors.fromJson(v));
      });
    }
    totalReviews = json['total_reviews'] != null ? json['total_reviews'].toString():null;
    rating = json['rating'] != null ? json['rating'].toString():null;
    currentDate = json['current_date'] != null ? json['current_date'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['firm_name'] = this.firmName;
    data['owner_name'] = this.ownerName;
    data['gstin'] = this.gstin;
    data['pan_number'] = this.panNumber;
    data['mobile_number'] = this.mobileNumber;
    data['city'] = this.city;
    data['state'] = this.state;
    data['address'] = this.address;
    data['area'] = this.area;
    data['pincode'] = this.pincode;
    data['country'] = this.country;
    data['communication_address'] = this.communicationAddress;
    data['close_time'] = this.closeTime;
    data['open_time'] = this.openTime;
    data['bank_name'] = this.bankName;
    data['ifsc_code'] = this.ifscCode;
    data['account_number'] = this.accountNumber;
    data['account_holder_name'] = this.accountHolderName;
    data['library_images'] = this.libraryImages;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['subscription_id'] = this.subscriptionId;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['floor_plan_height'] = this.floorPlanHeight;
    data['floor_plan_width'] = this.floorPlanWidth;
    if (this.facility != null) {
      data['facility'] = this.facility!.map((v) => v.toJson()).toList();
    }
    if (this.reviews != null) {
      data['reviews'] = this.reviews!.map((v) => v.toJson()).toList();
    }
    if (this.subscriptions != null) {
      data['subscriptions'] =
          this.subscriptions!.map((v) => v.toJson()).toList();
    }
    if (this.floorPlan != null) {
      data['floor_plan'] = this.floorPlan!.map((v) => v.toJson()).toList();
    }
    data['description'] = this.description;
    if (this.getFloors != null) {
      data['get_floors'] = this.getFloors!.map((v) => v.toJson()).toList();
    }
    data['total_reviews'] = this.totalReviews;
    data['rating'] = this.rating;
    return data;
  }
}

class DetailFacility {
  String? name;
  String? image;

  DetailFacility({this.name, this.image});

  DetailFacility.fromJson(Map<String, dynamic> json) {
    name = json['name'] != null ? json['name'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['image'] = this.image;
    return data;
  }
}

class DetailReviews {
  String? name;
  String? address;
  String? ratingCount;
  String? review;
  String? image;

  DetailReviews({this.name, this.address, this.ratingCount, this.review, this.image});

  DetailReviews.fromJson(Map<String, dynamic> json) {
    name = json['name'] != null ? json['name'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    ratingCount =  json['rating_count'] != null ? json['rating_count'].toString():null;
    review = json['review'] != null ? json['review'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['address'] = this.address;
    data['rating_count'] = this.ratingCount;
    data['review'] = this.review;
    data['image'] = this.image;
    return data;
  }
}

class DetailSubscriptions {
  String? id;
  String? name;
  String? amount;
  String? startTime;
  String? closeTime;
  String? numberOfDays;
  bool? isSelected = false;

  DetailSubscriptions(
      {this.id, this.name, this.amount, this.startTime, this.closeTime,this.numberOfDays,});

  DetailSubscriptions.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    name = json['name'] != null ? json['name'].toString():null;
    amount = json['amount'] != null ? json['amount'].toString():null;
    startTime = json['start_time'] != null ? json['start_time'].toString():null;
    closeTime =  json['close_time'] != null ? json['close_time'].toString():null;
    numberOfDays = json['number_of_days'] != null ? json['number_of_days'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['amount'] = this.amount;
    data['start_time'] = this.startTime;
    data['close_time'] = this.closeTime;
    data['number_of_days'] = this.numberOfDays;
    return data;
  }
}

class DetailFloorPlan {
  String? floorImage;
  String? floorPlanHeight;
  String? floorPlanWidth;
  List<DetailTables>? tables;
  String? floorName;

  DetailFloorPlan({this.floorName,this.floorImage, this.tables, this.floorPlanHeight, this.floorPlanWidth});

  DetailFloorPlan.fromJson(Map<String, dynamic> json) {
    floorImage = json['floor_image'] != null ? json['floor_image'].toString():null;
    if (json['tables'] != null) {
      tables = <DetailTables>[];
      json['tables'].forEach((v) {
        tables!.add(new DetailTables.fromJson(v));
      });
    }
    floorPlanHeight = json['floor_plan_height'] != null ? json['floor_plan_height'].toString():null;
    floorPlanWidth = json['floor_plan_width'] != null ? json['floor_plan_width'].toString():null;
    floorName = json['floor_name'] != null ? json['floor_name'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['floor_image'] = this.floorImage;
    if (this.tables != null) {
      data['tables'] = this.tables!.map((v) => v.toJson()).toList();
    }
    data['floor_plan_height'] = this.floorPlanHeight;
    data['floor_plan_width'] = this.floorPlanWidth;
    data['floor_name'] = this.floorName;
    return data;
  }
}

class DetailTables {
  String? seatId;
  String? seatName;
  String? xCord;
  String? yCord;
  String? alignment;
  String? isBooked;

  DetailTables({this.seatId, this.seatName, this.xCord, this.yCord,this.alignment,this.isBooked});

  DetailTables.fromJson(Map<String, dynamic> json) {
    seatId = json['seat_id'] != null ? json['seat_id'].toString():null;
    seatName = json['seat_name'] != null ? json['seat_name'].toString():null;
    xCord = json['x_cord'] != null ? json['x_cord'].toString():null;
    yCord = json['y_cord'] != null ? json['y_cord'].toString():null;
    alignment = json['alignment'] != null ? json['alignment'].toString():null;
    isBooked = json['is_booked'] != null ? json['is_booked'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['seat_id'] = this.seatId;
    data['seat_name'] = this.seatName;
    data['x_cord'] = this.xCord;
    data['y_cord'] = this.yCord;
    data['alignment'] = this.alignment;
    data['is_booked'] = this.isBooked;
    return data;
  }
}

class DetailGetFloors {
  String? id;
  String? libraryId;
  String? name;
  String? topChair;
  String? bottomChair;
  String? leftChair;
  String? rightChair;
  String? table;
  String? floorImage;
  String? status;
  String? createdAt;
  String? updatedAt;
  String? deletedAt;
  List<DetailGetTables>? getTables;

  DetailGetFloors(
      {this.id,
        this.libraryId,
        this.name,
        this.topChair,
        this.bottomChair,
        this.leftChair,
        this.rightChair,
        this.table,
        this.floorImage,
        this.status,
        this.createdAt,
        this.updatedAt,
        this.deletedAt,
        this.getTables});

  DetailGetFloors.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    libraryId = json['library_id'] != null ? json['library_id'].toString():null;
    name = json['name'] != null ? json['name'].toString():null;
    topChair =   json['top_chair'] != null ? json['top_chair'].toString():null;
    bottomChair = json['bottom_chair'] != null ? json['bottom_chair'].toString():null;
    leftChair = json['left_chair'] != null ? json['left_chair'].toString():null;
    rightChair = json['right_chair'] != null ? json['right_chair'].toString():null;
    table =  json['table'] != null ? json['table'].toString():null;
    floorImage = json['floor_image'] != null ? json['floor_image'].toString():null;
    status = json['status'] != null ? json['status'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
    deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
    if (json['get_tables'] != null) {
      getTables = <DetailGetTables>[];
      json['get_tables'].forEach((v) {
        getTables!.add(new DetailGetTables.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['library_id'] = this.libraryId;
    data['name'] = this.name;
    data['top_chair'] = this.topChair;
    data['bottom_chair'] = this.bottomChair;
    data['left_chair'] = this.leftChair;
    data['right_chair'] = this.rightChair;
    data['table'] = this.table;
    data['floor_image'] = this.floorImage;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['deleted_at'] = this.deletedAt;
    if (this.getTables != null) {
      data['get_tables'] = this.getTables!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DetailGetTables {
  String? id;
  String? libraryId;
  String? floorId;
  String? alignment;
  String? tableNo;
  String? topCordinate;
  String? leftCordinate;
  String? status;
  String? deletedAt;
  String? createdAt;
  String? updatedAt;

  DetailGetTables(
      {this.id,
        this.libraryId,
        this.floorId,
        this.alignment,
        this.tableNo,
        this.topCordinate,
        this.leftCordinate,
        this.status,
        this.deletedAt,
        this.createdAt,
        this.updatedAt});

  DetailGetTables.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    libraryId = json['library_id'] != null ? json['library_id'].toString():null;
    floorId = json['floor_id'] != null ? json['floor_id'].toString():null;
    alignment = json['alignment'] != null ? json['alignment'].toString():null;
    tableNo = json['table_no'] != null ? json['table_no'].toString():null;
    topCordinate = json['top_cordinate'] != null ? json['top_cordinate'].toString():null;
    leftCordinate = json['left_cordinate'] != null ? json['left_cordinate'].toString():null;
    status = json['status'] != null ? json['status'].toString():null;
    deletedAt = json['deleted_at'] != null ? json['deleted_at'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['library_id'] = this.libraryId;
    data['floor_id'] = this.floorId;
    data['alignment'] = this.alignment;
    data['table_no'] = this.tableNo;
    data['top_cordinate'] = this.topCordinate;
    data['left_cordinate'] = this.leftCordinate;
    data['status'] = this.status;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
