class ReviewApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  List<ReviewData>? data;
  bool? isSubscription;
  String? status;

  ReviewApiResponse(
      {this.error,
        this.message,
        this.errorCode,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.data,
        this.isSubscription,
        this.status});

  ReviewApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    if (json['data'] != null) {
      data = <ReviewData>[];
      json['data'].forEach((v) {
        data!.add(new ReviewData.fromJson(v));
      });
    }
    isSubscription = json['is_subscription'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['is_subscription'] = this.isSubscription;
    data['status'] = this.status;
    return data;
  }
}

class ReviewData {
  String? id;
  String? userId;
  String? name;
  String? address;
  String? ratingCount;
  String? review;
  String? image;

  ReviewData({this.id,this.userId,this.name, this.address, this.ratingCount, this.review, this.image});

  ReviewData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    userId = json['user_id'] != null ? json['user_id'].toString():null;
    name = json['name'] != null ? json['name'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    ratingCount = json['rating_count'] != null ? json['rating_count'].toString():null;
    review = json['review'] != null ? json['review'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['address'] = this.address;
    data['rating_count'] = this.ratingCount;
    data['review'] = this.review;
    data['image'] = this.image;
    return data;
  }
}

/// Update Review

class UpdateReviewResponse {
  bool? error;
  String? message;
  int? errorCode;
  bool? authenticate;
  String? authenticateMessage;
  String? state;

  UpdateReviewResponse(
      {this.error,
        this.message,
        this.errorCode,
        this.authenticate,
        this.authenticateMessage,
        this.state});

  UpdateReviewResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    return data;
  }
}

