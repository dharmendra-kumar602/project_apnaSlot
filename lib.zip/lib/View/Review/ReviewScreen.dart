

import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/Helper/Shared%20Preferences/SharedPreferences.dart';
import 'package:apna_slot/Controller/WidgetController/Toast/ToastCustom.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../Controller/Helper/ColoController/CustomColors.dart';
import '../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../Controller/WidgetController/AdditionalWidget/CustomeRattingBar.dart';
import '../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../Controller/WidgetController/Default Widget/DefaultWidget.dart';
import '../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import '../../Controller/WidgetController/ImageHelper/ImageHelper.dart';
import '../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../Controller/WidgetController/StringDefine/StringDefine.dart';
import 'ReviewController.dart';
import 'ReviewResponse.dart';

class ReviewScreen extends StatefulWidget {
  String libraryID;

  ReviewScreen({Key? key,required this.libraryID}) : super(key: key);

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}


class _ReviewScreenState extends State<ReviewScreen> {

  ReviewController reviewCtrl = Get.put(ReviewController());
  TextEditingController reviewCT = TextEditingController();

  double reviewRating = 0.0;
  String? userId;
  String? reviewID;


  @override
  void initState() {
      init();
    super.initState();
  }

  @override
  void dispose() {
    reviewCT.dispose();
    super.dispose();
  }

  Future<void> init()async{
    userId = AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId);
    await reviewCtrl.getReviewApi(context: context, libraryID: widget.libraryID);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ReviewController>(
        init: reviewCtrl,
        builder: (controller) {
          return LoadScreen(
              widget:  SafeArea(
                child: GestureDetector(
                    onTap: () => FocusScope.of(context).unfocus(),
                    child: Scaffold(
                        appBar: CustomAppBar.appBar(
                          title: kReview,
                          onTap: () {
                            Get.back();
                          },
                        ),
                        backgroundColor: CustomColors.whiteColor,
                        bottomNavigationBar: Padding(
                          padding: const EdgeInsets.only(left: 20,right: 20,bottom: 20),
                          child: Visibility(
                            visible: controller.reviewApiResponse?.isSubscription != null,
                            child: ButtonCustom(
                              onPress: () async {
                                reviewRating = 1.0;
                                reviewCT.clear();
                                reviewID = "";
                                if(controller.reviewApiResponse?.isSubscription == true){
                                  int indexID = controller.reviewData!.indexWhere((element) => element.userId.toString() == AppSharedPreferences.getStringFromSharedPref(variableName: AppSharedPreferences.userId).toString());
                                      if(indexID >= 0){
                                        reviewID = controller.reviewData?[indexID].id.toString() ?? "";
                                        reviewRating = double.parse(controller.reviewData?[indexID].ratingCount.toString() ?? "0.0");
                                        reviewCT.text = controller.reviewData?[indexID].review ?? "";
                                      }
                                }
                                PopupCustom.addReviewPopUp(
                                    context: context,
                                    btnTitle: kSubmit,//controller.reviewApiResponse?.isSubscription == true ? kEditReview:kAddReview,
                                    stars: reviewRating,
                                    reviewController: reviewCT,
                                    onTap: () async {
                                      if(reviewCT.text.toString().trim().isNotEmpty){
                                        PrintLog.printLog("Review Added: libraryId: ${widget.libraryID} \nRating count: $reviewRating \n comment: ${reviewCT.text}");
                                        await controller.updateReview(context: context,libraryID: widget.libraryID,comment: reviewCT.text.toString().trim(),ratingCount:reviewRating.toString(),reviewID: controller.reviewApiResponse?.isSubscription == true ? reviewID.toString():"").then((value) {
                                          Get.back();
                                          init();
                                        });
                                      }else{
                                        ToastCustom.showToast(msg: kReviewToastString);
                                      }
                                    },
                                    onRatingUpdate: (value){
                                      reviewRating = value.toDouble();
                                    },
                                    onValue: (value){
                                      if(value == true){
                                        init();
                                      }
                                    }
                                );
                              }, text: controller.reviewApiResponse?.isSubscription == false ? kAddReview:kEditReview,
                              buttonWidth: Get.width,
                              buttonHeight: 50.0,
                            ),
                          )

                        ),
                        body:
                        controller.isError ?
                        ErrorScreen(
                          onTap: () {
                            init();
                          },
                        )
                            : controller.isNetworkError ?
                        NoInternetConnectionScreen(
                          onTap: () {
                            init();
                          },
                        )
                            : controller.isEmpty ?
                        EmptyDataScreen(
                          onTap: () {
                            init();
                          },
                          isShowBtn: false,
                          string: kEmptyData,
                        )
                            : controller.reviewData != null && controller.isEmpty == false ?
                        Padding(
                            padding: const EdgeInsets.all(12),
                            child: ListView.builder(
                                itemCount: controller.reviewData?.length,
                                padding: EdgeInsets.zero,
                                shrinkWrap: true,
                                physics: const ClampingScrollPhysics(),
                                itemBuilder: (context,index){
                                  return Transform.translate(
                                    offset: const Offset(-12, 0),
                                    child: Column(
                                      children: [
                                        ListTile(
                                          leading: Transform.translate(
                                              offset: const Offset(0, -9),
                                              child: Container(
                                                height: 40,
                                                width: 40,
                                                clipBehavior: Clip.antiAlias,
                                                decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    border: Border.all(width: 0.3,color: CustomColors.greyColor)
                                                ),
                                                child: controller.reviewData?[index].image != null ?
                                                ImageHelperWhiteBgForProfile(
                                                  image: controller.reviewData?[index].image ?? '',
                                                  height: MediaQuery.of(context).size.height,
                                                  width: MediaQuery.of(context).size.width,
                                                  fit: BoxFit.cover,
                                                  alignment: Alignment.topCenter,
                                                ):DefaultWidget.image(),
                                              )
                                          ),
                                          title: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              buildHeading(text: controller.reviewData?[index].name ?? "",size: 16),
                                              buildTextCommon(
                                                text: controller.reviewData?[index].address ?? "",
                                                size: 14,
                                              ),
                                              buildSizeBox(3.0, 0.0),
                                              CustomRattingBar(
                                                stars: double.parse(controller.reviewData?[index].ratingCount ?? "0.0"),
                                                onRatingUpdate: (value){
                                                  PrintLog.printLog("Star: $value");
                                                },
                                                ignoreGesture: true,
                                              ),
                                              buildSizeBox(10.0, 0.0)
                                            ],
                                          ),
                                          subtitle: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              buildTextWithHeight(
                                                  text:
                                                  // "Paste your JSON in the textarea below, click convert and get your Dart classes for free",
                                                  controller.reviewData?[index].review ?? "",
                                                  size: 14,
                                                  height: 1.1,
                                                  color: CustomColors.greyColor
                                              ),
                                              buildSizeBox(10.0, 0.0),
                                              const Divider(height: 1,color: Colors.grey),
                                              buildSizeBox(10.0, 0.0),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }
                            )
                        )
                            : const SizedBox.shrink(),
                    )
                ),
              ),
              isLoading: controller.isLoading
          );

        }
        );
  }

  Future<void> checkUserReview({required ReviewController controller}) async {
    int reviewIndex = controller.reviewData!.indexWhere((element) => element.userId.toString() == userId.toString());

    if(reviewIndex >= 0){
      reviewCT.text = controller.reviewData?[reviewIndex].review ?? "";
      reviewRating = double.parse(controller.reviewData?[reviewIndex].ratingCount.toString() ?? "0.0");
      // PopupCustom.editReviewPopUp(
      //     context: context,
      //     stars: reviewRating,
      //     reviewController: reviewCT,
      //     onTap: () async {
      //       if(reviewCT.text.toString().trim().isNotEmpty){
      //         PrintLog.printLog("Review Added: libraryId: ${widget.libraryID} \nRating count: $reviewRating \n comment: ${reviewCT.text} \nReview ID: {widget.reviewID}");
      //         await controller.updateReview(context: context,libraryID: widget.libraryID,comment: reviewCT.text.toString().trim(),ratingCount:reviewRating.toString(),reviewID: controller.reviewData?[reviewIndex].id ?? "").then((value) {
      //           Get.back();
      //         });
      //       }else{
      //         ToastCustom.showToast(msg: kReviewToastString);
      //       }
      //     },
      //     onRatingUpdate: (value){
      //       reviewRating = value.toDouble();
      //     },
      //     onValue: (e){
      //       init();
      //     }
      // );

    }


  }

}


