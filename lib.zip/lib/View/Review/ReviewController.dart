
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../../../../Controller/ApiController/ApiController.dart';
import '../../Controller/ApiController/WebConstant.dart';
import '../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../Controller/Helper/Shared Preferences/SharedPreferences.dart';
import '../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../../main.dart';
import 'ReviewResponse.dart';


class ReviewController extends GetxController{

  ApiController apiCtrl = ApiController();
  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;
  bool isSuccess = false;
  ReviewApiResponse? reviewApiResponse;
  List<ReviewData>? reviewData;



  Future<ReviewApiResponse?> getReviewApi({required BuildContext context,required String libraryID}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "library_id":libraryID
    };

    String url = WebApiConstant.API_URL_GET_REVIEW;

    await apiCtrl.getReviewListApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              reviewData = result.data;
              reviewApiResponse = result;
              result.data == null ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);
              changeSuccessValue(true);


            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }

          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }

  Future<UpdateReviewResponse?> updateReview({required BuildContext context,required String libraryID,required String comment,required String ratingCount,required String reviewID}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "library_id":libraryID,
      "rate":ratingCount,
      "comment":comment,
    };

    if(reviewID != ""){
      dictparm.addEntries({"review_id":reviewID}.entries);
    }

    String url = WebApiConstant.API_URL_UPDATE_REVIEW;

    await apiCtrl.updateReviewApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              ToastCustom.showToast(msg: result.message ?? "");
              changeLoadingValue(false);
              changeSuccessValue(true);
            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }


  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }

  // Future<void> saveUserData({ReviewData? data})async{
  //   await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userName, variableValue: data?.review.toString() ?? "");
  //   await AppSharedPreferences.addStringValueToSharedPref(variableName: AppSharedPreferences.userEmail, variableValue: data?.ratingCount.toString() ?? "");
  // }

}

