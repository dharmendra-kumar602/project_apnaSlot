
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import 'package:apna_slot/Controller/WidgetController/ImageHelper/ImageHelper.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:apna_slot/View/Dashboard/Notification/NotificationController.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../../../Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
import '../../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Controller/WidgetController/RefresherIndicator/RefreshIndicatorCustom.dart';
import '../Dashboard/DashboardController.dart';
import '../Dashboard/DashboardScreen.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {

  DashboardController dashCtrl = Get.find();
  NotificationController notfCtrl = Get.put(NotificationController());

  RefreshController refreshController = RefreshController();


  @override
  void initState(){
    init();
    super.initState();
  }

  @override
  void dispose() {
    refreshController.dispose();
    super.dispose();
  }

   Future<void> init()async{
     notfCtrl.isNetworkError = false;
     notfCtrl.isEmpty = false;
     if(await ConnectionValidator().check()){
       await notfCtrl.notificationApi(context: context).then((value) {
         bool notRead = notfCtrl.notificationData!.any((element) => element.isRead == 0);
         if(notRead == false){
           dashCtrl.onItemNotification(value: false);
         }
       });
     }else{
       notfCtrl.isNetworkError = true;
       setState(() {

       });
     }
  }



  @override
  Widget build(BuildContext context) {
    return GetBuilder<NotificationController>(
      init: notfCtrl,
      builder: (controller) {
        return WillPopScope(
          onWillPop: ()=> dashCtrl.onItemTapped(index: 0),
          child: LoadScreen(
            widget: controller.isError ?
              ErrorScreen(
              onTap: () {
                init();
              },
            )
            : controller.isNetworkError ?
              NoInternetConnectionScreen(
              onTap: () {
                init();
              },
            )
            : controller.isEmpty ?
              EmptyDataScreen(
              onTap: () {
                init();
              },
              isShowBtn: false,
              string: kEmptyData,
            )
            : controller.notificationData != null && controller.isEmpty == false ?
              Scaffold(
              appBar: CustomAppBar.appBar(
                title: kNotifications,
                onTap: (){
                  dashCtrl.onItemTapped(index: 0);
                },
              ),
              backgroundColor: Colors.white,
              body: controller.notificationData!.isNotEmpty ?
              RefreshIndicatorCustom(
                refreshController: refreshController,
                onRefresh: (){
                  refreshController.refreshCompleted();
                  init();
                },
                child: ListView.builder(
                    physics: const ClampingScrollPhysics(),
                    padding: EdgeInsets.zero,
                    itemCount: controller.notificationData?.length,
                    itemBuilder: (BuildContext context,index){
                      return Padding(
                        padding: const EdgeInsets.only(left: 20,right: 20),
                        child: InkWell(
                          onTap: (){
                            if(controller.notificationData?[index].isRead == 0){
                              controller.notificationReadApi(context: context,id: controller.notificationData?[index].id ?? 0,isRead: 1).then((value) {
                                controller.notificationData?[index].isRead = 1;
                              });
                              bool notRead = controller.notificationData!.any((element) => element.isRead == 0);
                              if(notRead == false){
                                  dashCtrl.onItemNotification(value: false);
                              }
                            }
                            // else{
                            //   controller.notificationReadApi(context: context,id: controller.notificationData?[index].id ?? 0,isRead: 0).then((value) {
                            //     controller.notificationData?[index].isRead = 0;
                            //   });
                            // }
                          },
                          child: Column(
                            children: [
                              buildSizeBox(10.0, 0.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [

                                  // Container(
                                  //   width: 10,
                                  //   height: 10,
                                  //   margin: const EdgeInsets.only(right: 15),
                                  //   decoration: BoxDecoration(
                                  //       color: controller.notificationData?[index].isRead == 0 ? CustomColors.bluearrowcolor:CustomColors.whiteColor,
                                  //       shape: BoxShape.circle
                                  //   ),
                                  // ),
                                  controller.notificationData?[index].isRead == 0 ?
                                  SvgPicture.asset(strSvgBell2) : SvgPicture.asset(strSvgBell2,color: CustomColors.greyColor.withOpacity(0.5)),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 15),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [

                                          ///Notification Title
                                          buildText1(
                                            text: controller.notificationData?[index].title ?? "",
                                            color: CustomColors.bluearrowcolor,
                                            size: 18),
                                          buildSizeBox(5.0, 0.0),

                                          ///Notification Message
                                          buildText1(
                                              text: controller.notificationData?[index].message.toString() ?? "",
                                              color: CustomColors.greyColor,
                                              size: 15),
                                        ],
                                      ),
                                    ),
                                  ),
                                  
                                  ///Image
                                  Container(
                                    width: 30,
                                    height: 30,
                                    decoration: const BoxDecoration(
                                        shape: BoxShape.circle
                                    ),
                                    child: Center(
                                      child: ImageHelperWhiteBg(
                                        image: controller.notificationData?[index].image ?? "",
                                        height: MediaQuery.of(context).size.height,
                                        width: MediaQuery.of(context).size.width,
                                        fit: BoxFit.cover,
                                        alignment: Alignment.topCenter,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              buildSizeBox(10.0, 0.0),
                              const Divider(),
                            ],
                          ),
                        ),
                      );

                    }),
              )
                  : EmptyDataScreen(
                onTap: () {
                  init();
                },
                isShowBtn: false,
                string: kEmptyData,
              ),
            )
            : const SizedBox.shrink(),
            isLoading: controller.isLoading,
          ),
        );
      },
    );
  }

}