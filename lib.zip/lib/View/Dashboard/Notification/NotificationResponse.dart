
class NotificationApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  List<NotificationData>? data;

  NotificationApiResponse(
      {this.error, this.message, this.errorCode, this.state, this.data});

  NotificationApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    if (json['data'] != null) {
      data = <NotificationData>[];
      json['data'].forEach((v) {
        data!.add(new NotificationData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class NotificationData {
  int? id;
  int? userId;
  String? title;
  String? message;
  int? isRead;
  String? image;

  NotificationData(
      {this.id,
      this.userId,
      this.title,
      this.message,
      this.isRead,
      this.image});

  NotificationData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    title = json['title'];
    message = json['message'];
    isRead = json['is_read'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['title'] = this.title;
    data['message'] = this.message;
    data['is_read'] = this.isRead;
    data['image'] = this.image;
    return data;
  }
}

class NotificationReadApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;

  NotificationReadApiResponse(
      {this.error, this.message, this.errorCode, this.state});

  NotificationReadApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    return data;
  }
}
