import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../../Controller/Firebase/FirebaseDynamicLink/FirebaseDynamicLink.dart';
import '../../../Controller/Firebase/FirebaseMessaging/FirebaseMessaging.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../../main.dart';
import '../History/HistoryScreen.dart';
import '../Home/HomeScreen/HomeScreen.dart';
import '../Notification/NotificationController.dart';
import '../Notification/NotificationScreen.dart';
import 'DashboardController.dart';


class DashboardScreen extends StatefulWidget {
  int? screenIndex;
  DashboardScreen({Key? key,required this.screenIndex}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  DashboardController dashCtrl = Get.put(DashboardController());
  NotificationController notificationCtrl = Get.put(NotificationController());


  final pages = [
    const HomeScreen(),
    const NotificationScreen(),
    const HistoryScreen(),
  ];

  @override
  void initState() {
    initDash();
    super.initState();
  }

  Future<void> initDash()async{
    initMsg();
    dashCtrl.onItemTapped(index: widget.screenIndex ?? 0);
    await notificationApi();
    await checkDynamicLink();
    FirebaseMessagingCustom.notificationFuncCall(context: context);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DashboardController>(
        init: dashCtrl,
        builder: (controller) {
          return Scaffold(
            bottomNavigationBar: Card(
              margin: EdgeInsets.zero,
              elevation: 50,
              child: Container(
                  height: 65,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10.0,
                        offset: Offset(0.0, 10.0),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [

                        ///Home
                        GestureDetector(
                          onTap: (){
                            if(controller.pageIndex != 0){
                              controller.onItemTapped(index: 0);
                            }
                          },
                          child: Column(
                            children: [
                              SizedBox(
                                width: 50,
                                child: Center(
                                  child: controller.pageIndex == 0 ?
                                   Icon(Icons.home,size: 30,color: CustomColors.bluearrowcolor):
                                   Icon(Icons.home_outlined,size: 30,color: CustomColors.bluearrowcolor)
                                ),
                              ),
                              buildTextCommon(
                                  text: kHome,
                                  color: controller.pageIndex == 0 ?
                                  CustomColors.bluearrowcolor:
                                  CustomColors.greyColor)
                            ],
                          ),
                        ),

                        ///Notification
                        GestureDetector(
                          onTap: (){
                            if(controller.pageIndex != 1){
                              controller.onItemTapped(index: 1);
                            }
                          },
                          child: Column(
                            children: [
                              SizedBox(
                                width: 50,
                                child: Stack(
                                  children: [
                                    Center(
                                      child: controller.pageIndex == 1 ?
                                       Icon(Icons.notifications_rounded,size: 30,color: CustomColors.bluearrowcolor):
                                       Icon(Icons.notifications_none_outlined,size: 30,color: CustomColors.bluearrowcolor)
                                    ),
                                    Visibility(
                                      visible: controller.isUnReadNotification,
                                      child: const Positioned(
                                        right: 12,
                                          top: 5,
                                          child: CircleAvatar(backgroundColor: Colors.red,radius: 5)
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              buildTextCommon(
                                  text: kAlert,
                                  color: controller.pageIndex == 1 ?
                                  CustomColors.bluearrowcolor:
                                  CustomColors.greyColor
                              )
                            ],
                          ),
                        ),

                        ///Bookings
                        GestureDetector(
                          onTap: (){
                            if(controller.pageIndex != 2){
                              controller.onItemTapped(index: 2);
                            }
                          },
                          child: Column(
                            children: [
                              buildSizeBox(3.0, 0.0),

                              SizedBox(
                                width: 50,
                                child: Center(
                                    child: controller.pageIndex == 2 ?
                                    SvgPicture.asset(strSvgBookingSeleted,width: 25,color: CustomColors.bluearrowcolor,):
                                    SvgPicture.asset(strSvgBookingUnselected,width: 25,color: CustomColors.bluearrowcolor)
                                ),
                              ),
                              buildSizeBox(3.0, 0.0),
                              buildTextCommon(
                                  text: 'Bookings',
                                  color: controller.pageIndex == 2 ?
                                  CustomColors.bluearrowcolor:
                                  CustomColors.greyColor
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  )

              ),
            ),
            body: pages.elementAt(controller.pageIndex),
          );
        }
    );
  }

  /// Dynamic Link
  Future checkDynamicLink() async{
    var libraryID = FirebaseDynamicLinkCustom.getInitialDynamicLinksWhenBackgroundState();
    PrintLog.printLog("library id from dynamic link::::$libraryID");
  }

  /// Notification
  void initMsg() {
    msgController.stream.listen((value) async {
      if(mounted) {
        PrintLog.printLog("Call GetNotification Api....");
        dashCtrl.onItemNotification(value: true);
      }
    });
  }

  Future<void>  notificationApi()async{
    await notificationCtrl.notificationApi(context: context).then((value) {
      bool notRead = notificationCtrl.notificationData!.any((element) => element.isRead == 0);
      if(notRead){
        PrintLog.printLog("Unread notification found:::::::");
        Future.delayed(const Duration(milliseconds: 100),(){
          setState(() {
            dashCtrl.isUnReadNotification = true;
          });
        });
      }
    });
  }

}
