import 'package:get/get.dart';

class DashboardController extends GetxController{

  int pageIndex = 0;
  bool isUnReadNotification = false;

   onItemTapped({required int index}) {
    pageIndex = index;
    update();
  }

  void onItemNotification({required bool value}) {
    isUnReadNotification = value;
    update();
  }

}

