class SearchApiResponse {
  bool? error;
  String? message;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  List<GetSearchListData>? data;
  int? errorCode;

  SearchApiResponse(
      {this.error,
        this.message,
        this.authenticate,
        this.authenticateMessage,
        this.state,
        this.data,
        this.errorCode});

  SearchApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    if (json['data'] != null) {
      data = <GetSearchListData>[];
      json['data'].forEach((v) {
        data!.add(new GetSearchListData.fromJson(v));
      });
    }
    errorCode = json['errorCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['errorCode'] = this.errorCode;
    return data;
  }
}


class GetSearchListData {
  int? id;
  int? userId;
  String? firmName;
  String? address;
  String? openTime;
  String? closeTime;
  String? libraryImages;
  List<Facility>? facility;

  GetSearchListData(
      {this.id,
        this.userId,
        this.firmName,
        this.address,
        this.openTime,
        this.closeTime,
        this.libraryImages,
        this.facility});

  GetSearchListData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? int.parse(json['id'].toString()):null;
    userId = json['user_id'] != null ? int.parse(json['user_id'].toString()):null;
    firmName = json['firm_name'] != null ? json['firm_name'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    openTime = json['open_time'] != null ? json['open_time'].toString():null;
    closeTime = json['close_time'] != null ? json['close_time'].toString():null;
    libraryImages = json['library_images'] != null ? json['library_images'].toString():null;
    if (json['facility'] != null) {
      facility = <Facility>[];
      json['facility'].forEach((v) {
        facility!.add(new Facility.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['firm_name'] = this.firmName;
    data['address'] = this.address;
    data['open_time'] = this.openTime;
    data['close_time'] = this.closeTime;
    data['library_images'] = this.libraryImages;
    if (this.facility != null) {
      data['facility'] = this.facility!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Facility {
  String? name;
  String? image;

  Facility({this.name, this.image});

  Facility.fromJson(Map<String, dynamic> json) {
    name = json['name'] != null ? json['name'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['image'] = this.image;
    return data;
  }
}