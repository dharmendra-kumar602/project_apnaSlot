
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:apna_slot/View/Dashboard/Home/Search/SearchController.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../../Controller/RouteController/RouteNames.dart';
import '../../../../Controller/WidgetController/LibraryItemWidget/LibraryItemWidget.dart';
import '../../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../Detail/NewDetailsScreen.dart';
import '../../../LibraryBooking/LibraryBookShedual/NewLibraryBookScheduleScreen.dart';



class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {

  SearchScreenController searchCtrl = Get.put(SearchScreenController());
  TextEditingController searchTextCtrl = TextEditingController();


  @override
  void initState() {
    super.initState();
  }

  Future<void> init()async{
    // await searchCtrl.getSearchApi(context: context,lat: "51.13245",lng: "4.13245",searchVal: 'test' );
  }

  @override
  void dispose() {
    searchCtrl.searchData?.clear();
    searchTextCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print("hjhkgjhgjh${searchTextCtrl.text.toString().length}");
    return GetBuilder<SearchScreenController>(
      init: searchCtrl,
      builder: (controller) {
        return SafeArea(
            child: GestureDetector(
              onTap: (){
                FocusScope.of(context).unfocus();
              },
              child: LoadScreen(
                widget: Scaffold(
                  resizeToAvoidBottomInset: false,
                  extendBodyBehindAppBar: true,
                  appBar: CustomAppBar.appBar(
                    title: kSearchLibraries,
                    onTap: () {
                      Get.back();
                      FocusScope.of(context).unfocus();
                    },
                  ),
                  backgroundColor: Colors.white,
                  body: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Column(
                      children: [
                        buildSizeBox(Get.height *10/100, 0.0),
              
                        /// Text search box
                        Container(
                          width: Get.width,
                          height: 45,
                          decoration: BoxDecoration(
                            color: CustomColors.greyColorLight,
                            borderRadius: BorderRadius.circular(5)
                          ),
                          child: Row(
                            children: [
                              // SizedBox(
                              //   width: 40,
                              //   child: Center(
                              //     child: SvgPicture.asset(strSvgQrCode),
                              //   ),
                              // ),
                              buildSizeBox(0.0, 10.0),
                              Expanded(
                                child: Container(
                                  margin: const EdgeInsets.only(top: 0, left: 0, bottom: 10),
                                  child: TextFormField(
                                    autofocus:true,
                                    onChanged:  (value) async {
                                      if(value.toString().trim().isNotEmpty && value.length > 0){
                                        await controller.getSearchApi(context: context,searchVal: value.toString().trim() );
                                      }else{
                                        setState(() {
                                          controller.searchData?.clear();
                                        });
                                      }
                                    },
                                    controller: searchTextCtrl,
                                    maxLines: 1,
                                    decoration: InputDecoration(
                                        hintText: kSearch,
                                        border: InputBorder.none,
                                        hintStyle: TextStyle(
                                            fontSize: 14,
                                            fontFamily: FontFamily.josefinRegular,
                                            color: Colors.grey)),
                                  ),
                                ),
                              ),
              
                              SizedBox(
                                width: 40,
                                child: Center(
                                  child: searchTextCtrl.text.toString().trim().isEmpty ?
                                  SvgPicture.asset(strSvgSearch)
                                      : GestureDetector(
                                      onTap: (){
                                        setState(() {
                                          searchTextCtrl.clear();
                                        });
                                      },
                                      child: Icon(Icons.clear,color: CustomColors.blackColor,)
                                  )
                                ),
                              )
                            ],
                          ),
                        ),
              
                        buildSizeBox(20.0, 0.0),
              
                        /// List widget
                        controller.searchData != null && controller.searchData!.isNotEmpty && searchTextCtrl.text.toString().length > 0 ?
                        Expanded(
                          child: ListView.builder(
                              physics: const ClampingScrollPhysics(),
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              itemCount: controller.searchData?.length ?? 0,
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 5.0),
                                  child: SearchLibraryItemWidget(
                                    isShowBookNow: controller.searchData?[index].subscriptions != null && controller.searchData![index].subscriptions!.isNotEmpty && controller.searchData?[index].floorPlan != null && controller.searchData![index].floorPlan!.isNotEmpty ? true : false,
                                    libraryName: controller.searchData?[index].firmName ?? "",
                                    libraryAddress: controller.searchData?[index].address ?? "",
                                    ratingCount: controller.searchData?[index].rating ?? '0.0',
                                    openingHour: "${controller.searchData?[index].openTime ?? ""} - ${controller.searchData?[index].closeTime ?? ""}",
                                    facility: controller.searchData?[index].facility ?? [],
                                    ignoreRatingBarGesture: true,
                                    distance: controller.searchData?[index].distance ?? "0.0",
                                    lat: controller.searchData?[index].latitude.toString() ?? kDefaultLat.toString(),
                                    lng: controller.searchData?[index].longitude.toString() ?? kDefaultLat.toString(),
                                    firmName: controller.searchData?[index].firmName ?? "",
                                    onTapBookNow: (){
                                      Get.toNamed(
                                          newLibraryBookScheduleScreenRoute,
                                          arguments: NewLibraryBookScheduleScreen(
                                            isDetail: false,
                                            currentIndex: index,
                                            homeData: controller.searchData?[index],
                                            currentDate: DateTime.now(),
                                            detailsListData: controller.searchData,
                                            libraryID: controller.searchData?[index].id ?? "0",
                                          )
                                      );
                                    },
                                    onTapLibrary: (){
                                      print("index: $index or length :${controller.searchData?.length}");
                                      Get.toNamed(newDetailScreenRoute,arguments: NewDetailScreen(libraryIndex: index,detailsListData: controller.searchData ?? [],));
                                      // Get.toNamed(detailScreenRoute,arguments: DetailScreen(libraryID: controller.searchData?[index].id ?? "0"));
                                    },
                                  ),
                                );
              
                              }),
                        )
                            : 
                             controller.searchData != searchTextCtrl.text.toString() && searchTextCtrl.text.toString().length > 3 && controller.isLoading == false ?
                             Padding(
                              padding: EdgeInsets.only(top: MediaQuery.of(context).size.height * 0.2),
                              child: buildText1(text: 'No data available',size: 20,color: CustomColors.greyColor),
                            ) 
                            : const SizedBox.shrink()
                      ],
                    ),
                  ),
                ),
              isLoading: controller.isLoading,
              ),
            ));
      },
    );

  }

}
