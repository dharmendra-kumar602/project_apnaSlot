class FilterApiResponse {
  bool? error;
  String? message;
  bool? authenticate;
  String? authenticateMessage;
  String? state;
  FilterData? data;
  int? errorCode;

  FilterApiResponse(
      {this.error,
      this.message,
      this.authenticate,
      this.authenticateMessage,
      this.state,
      this.data,
      this.errorCode});

  FilterApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    authenticate = json['authenticate'];
    authenticateMessage = json['authenticate_message'];
    state = json['state'];
    data = json['data'] != null ? new FilterData.fromJson(json['data']) : null;
    errorCode = json['errorCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['authenticate'] = this.authenticate;
    data['authenticate_message'] = this.authenticateMessage;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['errorCode'] = this.errorCode;
    return data;
  }
}

class FilterData {
  List<Facility>? facility;
  int? startRange;
  int? endRange;

  FilterData({this.facility, this.startRange, this.endRange});

  FilterData.fromJson(Map<String, dynamic> json) {
    if (json['facility'] != null) {
      facility = <Facility>[];
      json['facility'].forEach((v) {
        facility!.add(new Facility.fromJson(v));
      });
    }
    startRange = json['start_range'];
    endRange = json['end_range'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.facility != null) {
      data['facility'] = this.facility!.map((v) => v.toJson()).toList();
    }
    data['start_range'] = this.startRange;
    data['end_range'] = this.endRange;
    return data;
  }
}

class Facility {
  int? id;
  String? name;
  bool isChecked = false;

  Facility({this.id, this.name});

  Facility.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}
