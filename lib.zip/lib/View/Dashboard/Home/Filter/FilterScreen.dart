import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../../../../Controller/Helper/ColoController/CustomColors.dart';
import '../../../../Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../../../../Controller/WidgetController/AdditionalWidget/CustomCheckBox.dart';
import '../../../../Controller/WidgetController/AdditionalWidget/CustomRangSlider.dart';
import '../../../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../../../../Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import '../../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../HomeScreen/HomeController.dart';

class FilterScreen extends StatefulWidget {
  const FilterScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {return _FilterScreenState();}
}

class _FilterScreenState extends State<FilterScreen> {
  // TextEditingController searchTextCtrl = TextEditingController();

  HomeController homeCtrl = Get.find();

  double rangLblStart = 0.0;
  double rangLblEnd = 0.0;
  RangeValues? valuesMain;

  @override
  void initState() {
    super.initState();
    init();
  }

  Future init()async{
    if(homeCtrl.startRange != null){
      rangLblStart = double.parse(homeCtrl.startRange.toString()) ;
      rangLblEnd = double.parse(homeCtrl.endRange.toString())  ;
      valuesMain = RangeValues(double.parse(homeCtrl.startRange.toString()) , double.parse(homeCtrl.endRange.toString()) );
    }else{
      rangLblEnd = homeCtrl.filterData?.endRange?.toDouble() ?? 0.0;
      rangLblStart = homeCtrl.filterData?.startRange?.toDouble() ?? 0.0;
      valuesMain = RangeValues(homeCtrl.filterData?.startRange?.toDouble() ?? 0.0, homeCtrl.filterData?.endRange?.toDouble() ?? 0.0);
    }
    if(homeCtrl.facilityType.isNotEmpty){
        homeCtrl.filterData?.facility?.forEach((element2) {
          bool isAvl = homeCtrl.facilityType.any((element) => element.toString() == element2.id.toString());
          if(isAvl == true){
            element2.isChecked = true;
          }else{
            element2.isChecked = false;
          }
        });
    }else{
      homeCtrl.filterData?.facility?.forEach((element2) {
          element2.isChecked = false;
      });
    }

  }
  
  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      init: homeCtrl,
      builder: (controller) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: (){
                      Get.back();
                    },
                    child: Container(
                      color: Colors.transparent,
                    ),
                  ),
                ),
                Container(
                  height: Get.height,
                  width: Get.width*75/100,
                  color: CustomColors.whiteColor,
                  child: LoadScreen(
                    widget: Scaffold(
                      appBar: AppBar(
                        leading: InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Container(
                              color: Colors.transparent,
                              padding: const EdgeInsets.only(left: 10),
                              width: 30,
                              child: SvgPicture.asset(strSvgBackArrow,color: Colors.black,)
                          ),
                        ),
                        leadingWidth: 30,
                        elevation: 1,
                        title: buildHeading(text: kFilters,color: CustomColors.bluearrowcolor),
                        centerTitle: true,
                        backgroundColor: CustomColors.whiteColor,
                        // actions: [
                        //   PopupMenuButton(
                        //     position: PopupMenuPosition.under,
                        //     icon: Icon(Icons.sort,color: CustomColors.blackColor,),
                        //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                        //     itemBuilder: (ctx) => [
                        //       PopupMenuItem(
                        //         child: Column(
                        //           crossAxisAlignment: CrossAxisAlignment.center,
                        //         children: [
                        //           buildHeading(text: 'A-Z'),
                        //           buildSizeBox(15.0, 0.0),
                        //           buildHeading(text: 'A-Z'),
                        //           buildSizeBox(15.0, 0.0),
                        //           buildHeading(text: 'A-Z')
                        //         ],
                        //       ))
                        //     ],
                        //   )
                        // ],
                      ),
                      bottomNavigationBar: Padding(
                        padding: const EdgeInsets.only(left: 20,right: 15),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ButtonCustom(
                              onPress: () async {
                                bool isAvl = homeCtrl.filterData!.facility!.any((element) => element.isChecked == true);

                                if(isAvl == true || rangLblEnd != controller.filterData?.endRange?.toDouble() || rangLblStart != controller.filterData?.startRange?.toDouble()) {
                                     
                                  await homeCtrl.onTapApply(context: context,newStartRange : rangLblStart.toStringAsFixed(0),newEndRange: rangLblEnd.toStringAsFixed(0));
                                }else{
                                  ToastCustom.showToast( msg: kFilterToastString);
                                }
                              },
                              text: kApply,
                              buttonWidth: Get.width,
                              buttonHeight: 50,
                            ),
                            buildSizeBox(20.0, 0.0),
                            ButtonCustom(
                              onPress: () async {
                                bool isAvl = homeCtrl.filterData!.facility!.any((element) => element.isChecked == true);
                                if(isAvl == true || rangLblEnd != controller.filterData?.endRange?.toDouble() || rangLblStart != controller.filterData?.startRange?.toDouble()) {

                                  await homeCtrl.onTapReset();
                                  rangLblEnd = controller.filterData?.endRange?.toDouble() ?? 0.0;
                                  rangLblStart = controller.filterData?.startRange?.toDouble() ?? 0.0;
                                  valuesMain = RangeValues(controller.filterData?.startRange?.toDouble() ?? 0.0, controller.filterData?.endRange?.toDouble() ?? 0.0);
                                 
                                  await controller.getHome(context: context).then((value) {
                                      homeCtrl.mapMarkCreate();
                                    Get.back();
                                  });
                                }else{
                                  Get.back();
                                }

                              },
                              text: kReset,
                              buttonWidth: Get.width,
                              buttonHeight: 50,
                              backgroundColor: Colors.white,
                              textColor: CustomColors.bluearrowcolor,
                              useBorder: true,
                            ),
                            buildSizeBox(20.0, 0.0),

                          ],
                        ),
                      ),
                      body: Padding(
                        padding: const EdgeInsets.only(left: 20,right: 15),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // buildSizeBox(20.0, 0.0),
                              // buildHeading(text: kSearchArea),
                              // buildSizeBox(10.0, 0.0),
                              // CustomTextField2(
                              //   controller: searchTextCtrl,
                              //   textInputAction: TextInputAction.done,
                              //   keyboardType: TextInputType.text,
                              //   readOnly: false,
                              //   autofocus: false,
                              //   onTap: (){

                              //   },
                              //   onChanged: (value){
                              //     if(value.toString().trim().isNotEmpty && value.length > 2){
                              //       // await provider.getSearchListApi(searchVal: value.toString().trim());
                              //     }else{
                              //       // setState(() {
                              //       //   // provider.searchProductData?.clear();
                              //       // });
                              //     }
                              //   },
                              //   suffixIcon: SvgPicture.asset(strSvgSearch),
                              //   hintText: kSearch,

                              // ),

                              buildSizeBox(20.0, 0.0),

                              /// Facility type
                              buildHeading(text:'Facility type' ,),
                              buildSizeBox(10.0, 0.0),
                              ListView.builder(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: controller.filterData?.facility?.length ?? 0,
                                itemBuilder: (BuildContext context, index) {
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10,top: 10),
                                    child: CustomCheckBoxWithText(
                                      value: controller.filterData?.facility?[index].isChecked,
                                      label: controller.filterData?.facility?[index].name ?? "",
                                      radius: 0,
                                      height: 20,
                                      width: 20,
                                      space: 10,
                                      onChanged: (value){
                                        controller.filterData?.facility?[index].isChecked = value ?? false;
                                      },
                                    ),
                                  );
                                },
                              ),
                              buildSizeBox(20.0, 0.0),
                              const Divider(height: 1,color: Colors.grey),
                              buildSizeBox(20.0, 0.0),
                              /// Distance type
                              // buildHeading(text: kDistance),
                              // buildSizeBox(10.0, 0.0),
                              // CustomCheckBoxWithText(value: true, label: '1km',radius: 0,height: 20,width: 20,space: 2,),

                              // buildSizeBox(20.0, 0.0),
                              // const Divider(
                              //   height: 1,
                              //   color: Colors.grey,
                              // ),
                              // buildSizeBox(20.0, 0.0),
                              /// Range
                              // buildHeading(text: fPrice),
                              // buildSizeBox(10.0, 0.0),
                              ///
                              // Row(
                              //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              //   children: [
                              //     buildTextCommon( text: rangLblStart.toStringAsFixed(0),),
                              //     buildTextCommon( text: rangLblEnd.toStringAsFixed(0),),
                              //   ],
                              // ),

                              ///
                              // RangeSlider(
                              //     activeColor: CustomColors.bluearrowcolor,
                              //     inactiveColor: CustomColors.greyColor,
                              //     min: controller.filterData?.startRange?.toDouble() ?? 0.0,
                              //     max: controller.filterData?.endRange?.toDouble() ?? 0.0,
                              //     values: valuesMain ?? const RangeValues(0.0,0.0),
                              //     onChanged: (values){
                              //       setState(() {
                              //         rangLblStart = values.start;
                              //         rangLblEnd = values.end;
                              //         valuesMain = values;
                              //       });
                              //     }
                              // ),
                              ///
                              // CustomRangeSlider(
                              //   title: 'sdfsd',
                              //   startRange: controller.filterData?.startRange ?? 0,
                              //   endRange: controller.filterData?.endRange ?? 0,
                              //   lblStartRange: rangLblStart,
                              //   lblEndRange: rangLblEnd,
                              //   valuesMain: valuesMain,
                              //   onChanged: (values){
                              //     setState(() {
                              //       rangLblStart = values.start;
                              //       rangLblEnd = values.end;
                              //         valuesMain = values;
                              //     });
                              //   }
                              //
                              // ),
                              buildSizeBox(10.0, 0.0),

                            ],
                          ),
                        ),
                      ),
                    ),
                    isLoading: controller.isLoading,
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}