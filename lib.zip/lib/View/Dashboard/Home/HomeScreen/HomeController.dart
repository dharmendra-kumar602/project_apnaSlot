
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../../../Controller/ApiController/ApiController.dart';
import '../../../../Controller/ApiController/WebConstant.dart';
import '../../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import '../../../../main.dart';
import '../Filter/FilterResponse.dart';
import 'HomeApiResponse.dart';

String lat = "";
String lng = "";


class HomeController extends GetxController{

@override
  void onInit() {
    super.onInit();
  }

  ApiController apiCtrl = ApiController();
  bool isLoading = false;
  bool isError = false;
  bool isEmpty = false;
  bool isNetworkError = false;

  bool isSuccess = false;
  GetHomeApiResponse? getHomeApiResponse;
  List<HomeData>? homeData;
  FilterData? filterData;
  List<MapMarkUpData>? mapMarkUpData;
  RxMap<String, Marker> markers = <String, Marker>{}.obs;
  String? searchVal;
  RxList facilityType = [].obs;
  String? startRange;
  String? endRange;

  Future<void> mapMarkCreate() async {
      markers.clear();
    var data=homeData;
    if(data!=null){
    for (int i = 0; i < data.length; i++){
      PrintLog.printLog("For Loop");
      final marker = Marker(
        icon: await BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(size: Size(20, 20)), strImgMapMarker2) ,
        // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed,),
        markerId: MarkerId(data[i].firmName ?? ""),
        position: LatLng(double.parse(data[i].latitude.toString()), double.parse(data[i].longitude.toString() ) ),
        infoWindow: InfoWindow(
            title: data[i].firmName ?? "",
            snippet: data[i].address ?? "",
            onTap: () {
              PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
            }),
        onTap: () {
          PrintLog.printLog("Clicked on marker");
        },
      );
      PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
      markers[data[i].firmName ?? ""] = marker;
      update();
    }
    }
  }






  Future<GetHomeApiResponse?> getHome({required BuildContext context}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "latitude":lat,
      "longitude":lng,
      // "latitude":"26.8752545",
      // "longitude":"75.7628039",
      "search_val":searchVal,//"test"
      "facility_type":facilityType.isNotEmpty ? facilityType.join(','):null,//"1,2",
      // "start_range":startRange,
      // "end_range":endRange,
    };


    String url = WebApiConstant.API_URL_GET_HOME;

    await apiCtrl.getHomeApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {
      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
            print('dkdkdk${result.data}');

              homeData = result.data;
              getHomeApiResponse = result;
              result.data == null || result.data!.isEmpty ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);
              changeSuccessValue(true);
              if(result.bookingId != null && result.bookingId != "null" && result.bookingId != ""){
                PopupCustom.showCompleteBookingPopUP(context: context,bookingNumber: result.bookingId ?? "");
              }
            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
    return null;
  }

  Future<MapMarkUpResponse?> mapMarkUp({required BuildContext context}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      // "latitude":lat,
      // "longitude":lng,

      "latitude":"26.8752545",
      "longitude":"75.7628039",
    };

    String url = WebApiConstant.API_URL_MAP_MARKUP;

    await apiCtrl.mapMarkUpApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              mapMarkUpData = result.data;
              changeLoadingValue(false);
              changeSuccessValue(true);
            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }
          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }

  Future<FilterApiResponse?> filterApi({required BuildContext context,}) async {

    changeEmptyValue(false);
    changeLoadingValue(true);
    changeNetworkValue(false);
    changeErrorValue(false);
    changeSuccessValue(false);

    Map<String, dynamic> dictparm = {
      "":""
    };

    String url = WebApiConstant.API_URL_GET_FILTER;

    await apiCtrl.getFilterApi(context:context,url: url, dictParameter: dictparm,token: authToken)
        .then((result) async {

      if(result != null){
        if (result.error != true) {
          try {
            if (result.errorCode == 0) {
              filterData = result.data;
              result.data == null ? changeEmptyValue(true):changeEmptyValue(false);
              changeLoadingValue(false);
              changeSuccessValue(true);


            } else {
              changeLoadingValue(false);
              changeSuccessValue(false);
              PrintLog.printLog(result.message);
            }

          } catch (_) {
            changeSuccessValue(false);
            changeLoadingValue(false);
            changeErrorValue(true);
            PrintLog.printLog("Exception : $_");
          }
        }else{
          changeSuccessValue(false);
          changeLoadingValue(false);
          changeErrorValue(true);
          PrintLog.printLog(result.message);
        }
      }else{
        changeSuccessValue(false);
        changeLoadingValue(false);
        changeErrorValue(true);
      }
    });
    update();
  }

  Future onTapApply({required BuildContext context,required String newStartRange,required String newEndRange})async{
    facilityType.clear();
    filterData?.facility?.forEach((element) {
      if(element.isChecked == true){
        facilityType.add(element.id.toString());
      }
    });
    startRange = newStartRange;
    endRange = newEndRange;
    PrintLog.printLog("Facility Type is: ${facilityType.join(',')} \n startRange is: $startRange \n endRange is: $endRange");
    await getHome(context: context).then((value) {
      mapMarkCreate();

      Get.back();
    });
  }

  Future onTapReset()async{
    facilityType.clear();
    startRange = null;
    endRange = null;
    filterData?.facility?.forEach((element) {
      if(element.isChecked == true){
        element.isChecked = false;
      }
    });
    update();
  }

  void changeSuccessValue(bool value){
    isSuccess = value;
    update();
  }
  void changeLoadingValue(bool value){
    isLoading = value;
    update();
  }
  void changeEmptyValue(bool value){
    isEmpty = value;
    update();
  }
  void changeNetworkValue(bool value){
    isNetworkError = value;
    update();
  }
  void changeErrorValue(bool value){
    isError = value;
    update();
  }



}

