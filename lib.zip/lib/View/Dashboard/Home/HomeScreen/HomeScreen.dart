import 'dart:async';
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:apna_slot/View/Dashboard/Home/HomeScreen/GoogleMapScreen.dart';
import 'package:apna_slot/View/Detail/DetailScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../../../../Controller/Helper/ApplicationExit/AppExitValidator.dart';
import '../../../../Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
import '../../../../Controller/Helper/Permission/PermissionHandler.dart';
import '../../../../Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import '../../../../Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import '../../../../Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import '../../../../Controller/WidgetController/LibraryItemWidget/LibraryItemWidget.dart';
import '../../../../Controller/WidgetController/RefresherIndicator/RefreshIndicatorCustom.dart';
import '../../../Detail/NewDetailsScreen.dart';
import '../../../LibraryBooking/LibraryBookShedual/NewLibraryBookScheduleScreen.dart';
import '../../../Profile/ProfileDetail/ProfileDetail.dart';
import 'HomeController.dart';
import 'package:geolocator/geolocator.dart';


bool isLoadFirst = false;

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  State<StatefulWidget> createState() {return _HomeScreenState();}
}

class _HomeScreenState extends State<HomeScreen> {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  HomeController  homeCtrl = Get.put(HomeController());
  ScrollController scrollController = ScrollController();
  RefreshController refreshController = RefreshController();


  /// Google Map
  final Completer<GoogleMapController> mapController = Completer();
  LatLng? mapCenterArea;
  final List<Map<String, dynamic>> libraryMarkers = [];
  double mapHeight = Get.height*0.4;

  @override
  void initState() {
    scrollController.addListener(_scrollListener);
    /// is Load First
    if(isLoadFirst == false){
      firstCall();
    }
    getLetLong();
    super.initState();
  }

  Future<void> _scrollListener() async {
    if(scrollController.offset.toInt() > 12 && mapHeight != 0){
      mapHeight = 0;
      setState(() {});
    }else if(scrollController.offset.toInt() < 10 && mapHeight == 0){
      mapHeight = Get.height *0.4;
      setState(() {});
    }
  }

  void onDispose() {
    refreshController.dispose();
    super.dispose();
  }

  Future<void> firstCall() async {
    homeCtrl.isNetworkError = false;
    homeCtrl.isEmpty = false;
    if(await ConnectionValidator().check()){
        await homeCtrl.filterApi(context: context).then((value) {
          isLoadFirst = true;
        });
    }else{
      homeCtrl.isNetworkError = true;
      setState(() {
      });
    }
  }

  Future<void> init() async {
    homeCtrl.isNetworkError = false;
    homeCtrl.isEmpty = false;
    if(await ConnectionValidator().check()){
      await homeCtrl.getHome(context: context);
    }else{
      homeCtrl.isNetworkError = true;
      setState(() {
      });
    }
  }

  Future getLetLong() async{
    bool isCall = false;
    await CheckPermission.checkLocationPermission(context).then((value) async {
      if(value == true){
        isCall = true;
        await _getCurrentPosition();
      }else{

      }
      PrintLog.printLog("Location permission value is: $value");
    } );
    if(isCall == false) {
      await homeCtrl.getHome(context: context);
      await mapMarkerApiCall();
    }

  }


  /// For Google Map

  Future<void> _getCurrentPosition() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high).then((Position position) async {
      setState(() {
        PrintLog.printLog("Current Lat lng :-> Lat: ${position.latitude.toString()}\nlng: ${position.longitude.toString()}");
        lat = position.latitude.toString();
        lng = position.longitude.toString();
        mapCenterArea = LatLng(position.latitude, position.longitude);
      } );
      await homeCtrl.getHome(context: context);
      await mapMarkerApiCall();

    }).catchError((e) {
      PrintLog.printLog(e);
    });
  }

  Future<void> mapMarkerApiCall() async {
    await homeCtrl.mapMarkUp(context: context).then((value) async {
      await homeCtrl.mapMarkCreate();
    });
  }
  Future<void> _onMapCreated(GoogleMapController? controller) async {
      homeCtrl.markers.clear();
    // await mapMarkerApiCall();
  }

  // Future<void> mapMarkCreate() async {
  //     _markers.clear();
  //   var data=homeCtrl.homeData;
  //   print('dk_p${data!.length}');
  //   if(data==null){}else{}
  //   for (int i = 0; i < data!.length; i++){
  //     PrintLog.printLog("For Loop");
  //     final marker = Marker(
  //       icon: await BitmapDescriptor.fromAssetImage(
  //           const ImageConfiguration(size: Size(20, 20)), strImgMapMarker2) ,
  //       // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed,),
  //       markerId: MarkerId(data[i].firmName ?? ""),
  //       position: LatLng(double.parse(data[i].latitude.toString()), double.parse(data[i].longitude.toString() ) ),
  //       infoWindow: InfoWindow(
  //           title: data[i].firmName ?? "",
  //           snippet: data[i].address ?? "",
  //           onTap: () {
  //             PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
  //           }),
  //       onTap: () {
  //         PrintLog.printLog("Clicked on marker");
  //       },
  //     );
  //     PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
  //     _markers[data[i].firmName ?? ""] = marker;
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
        init: homeCtrl,
        builder: (controller) {
          PrintLog.printLog("Network Status: ${homeCtrl.isNetworkError}"
          "\nEmpty Status: ${homeCtrl.isEmpty}"
          "\nError Status: ${homeCtrl.isError}"
              "Home data length${controller.homeData?.length}"
              );

          return SafeArea(
            child:
            WillPopScope(
                onWillPop: onWillPop,
                child: Scaffold(
                    key: _scaffoldKey,
                    extendBodyBehindAppBar: true,
                    backgroundColor: CustomColors.whiteColor,
                    drawer: const Drawer(child: ProfileDetailScreen()),
                    body: NestedScrollView(
                      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
                        return <Widget>[
                          SliverAppBar(
                            expandedHeight: Get.height *50/100,
                            floating: false,
                            pinned: true,
                            automaticallyImplyLeading: false,
                            backgroundColor: CustomColors.whiteColor,
                            flexibleSpace: FlexibleSpaceBar(
                                centerTitle: true,
                                background: GestureDetector(
                
                                  child: Container(
                                    color: CustomColors.whiteColor,
                                    padding: const EdgeInsets.only(bottom: 0),
                                    child:
                                    ///GOOGLE MAP
                                    GestureDetector(
                                      onHorizontalDragEnd: (e){
                                        Get.toNamed(googleMapScreenRoute,arguments: GoogleMapScreen(tag: "tag"));
                                      },
                                      onDoubleTap: (){
                                        Get.toNamed(googleMapScreenRoute,arguments: GoogleMapScreen(tag: "tag"));
                                        },
                                      child: SizedBox(
                                        height: Get.height *30/100,
                                        width: Get.width,
                                        child: ClipRRect(
                                          borderRadius: const BorderRadius.only(
                                            bottomLeft: Radius.circular(64),
                                            bottomRight: Radius.circular(64),
                                          ),
                                          child: GoogleMap(
                                            mapType: MapType.normal,
                                            zoomGesturesEnabled: true,
                                            onMapCreated: _onMapCreated,
                                            initialCameraPosition:  CameraPosition(
                                              target: mapCenterArea ?? const LatLng(26.8752545, 75.7628039),
                                              zoom: 15.0,
                                            ),
                                            buildingsEnabled: true,
                                            scrollGesturesEnabled: true,
                                            markers: homeCtrl.markers.values.toSet(),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                            ),
                            title: AppBar(
                              elevation: 0.0,
                              backgroundColor: Colors.transparent,
                              leading: InkWell(
                                onTap: () {
                                  _scaffoldKey.currentState!.openDrawer();
                                },
                                child: Container(
                                  margin: const EdgeInsets.all(10),
                                  width: 30,
                                  decoration: const BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black26,
                                        blurRadius: 10.0,
                                        offset: Offset(0.0, 5.0),
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child:
                                    // Image.asset(strImgMapMarker1)
                                    SvgPicture.asset(
                                      strSvgUser,
                                      width: 18,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                              actions: [
                                InkWell(
                                  onTap: () {
                                    Get.toNamed(searchScreenRoute)?.then((value) {
                                      init();
                                    });
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.all(10),
                                    width: 35,
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black26,
                                          blurRadius: 10.0,
                                          offset: Offset(0.0, 5.0),
                                        ),
                                      ],
                                    ),
                                    child: Center(
                                      child: SvgPicture.asset(
                                        strSvgSearch,
                                        width: 18,
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  child: Container(
                                    margin: const EdgeInsets.all(10),
                                    width: 35,
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black26,
                                          blurRadius: 10.0,
                                          offset: Offset(0.0, 5.0),
                                        ),
                                      ],
                                    ),
                                    child: Center(
                                      child: SvgPicture.asset(
                                        strSvgFilter,
                                        width: 18,
                                      ),
                                    ),
                                  ),
                                  onTap: () {
                                    Get.toNamed(filterScreenRoute);
                                    // _scaffoldKey.currentState!.openEndDrawer();
                                  },
                                )
                              ],
                              systemOverlayStyle: SystemUiOverlayStyle(
                                // Status bar color
                                statusBarColor: CustomColors.bluearrowcolor,
                
                                // Status bar brightness (optional)
                                statusBarIconBrightness: Brightness.dark, // For Android (dark icons)
                                statusBarBrightness: Brightness.light, // For iOS (dark icons)
                              ),
                            ),
                          )
                        ];
                      },
                      body: LoadScreen(
                        widget: controller.isError ?
                      ErrorScreen(
                        onTap: () {
                          init();
                        },
                      )
                          : controller.isNetworkError ?
                      NoInternetConnectionScreen(
                        onTap: () {
                          init();
                        },
                      )
                          : controller.isEmpty ?
                      EmptyDataScreen(
                        onTap: () {
                          init();
                        },
                        isShowBtn: false,
                        string: kEmptyData,
                      )
                          : controller.homeData != null && controller.homeData!.isNotEmpty && controller.isEmpty == false ?
                      RefreshIndicatorCustom(
                        refreshController: refreshController,
                        onRefresh: (){
                          refreshController.refreshCompleted();
                          init();
                        },
                        child: ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            padding: EdgeInsets.zero,
                            itemCount: controller.homeData?.length,
                            itemBuilder: (context, index) {
                
                              return NewLibraryItemWidget(
                                isShowBookNow: controller.homeData?[index].subscriptions != null && controller.homeData![index].subscriptions!.isNotEmpty && controller.homeData?[index].floorPlan != null && controller.homeData![index].floorPlan!.isNotEmpty ? true : false,
                                ratingCount: controller.homeData?[index].rating ?? "0",
                                distance: controller.homeData?[index].distance ?? "",
                                ignoreRatingBarGesture: true,
                                facility: controller.homeData?[index].facility ?? [],
                                libraryAddress: controller.homeData?[index].address ?? "",
                                libraryName: controller.homeData?[index].firmName ?? "",
                                openingHour: "${controller.homeData?[index].openTime ?? ""} - ${controller.homeData?[index].closeTime ?? ""}",
                                libraryImages: controller.homeData?[index].libraryImages != null && controller.homeData![index].libraryImages!.isNotEmpty ? controller.homeData![index].libraryImages![0] : "",
                                lat: double.parse(controller.homeData?[index].latitude.toString() ?? "") ,
                                lng: double.parse(controller.homeData?[index].longitude.toString() ?? ""),
                                onTapLibrary: () {
                                  print("Distance : ${controller.homeData?[index].distance ?? ""}");
                                  print("Converted Distance : ${(double.parse(controller.homeData![index].distance.toString())/1000).toStringAsFixed(2)}km");
                                  Get.toNamed(newDetailScreenRoute,arguments: NewDetailScreen(libraryIndex: index,detailsListData: controller.homeData))?.then((value) {
                                    init();
                                  });
                                },
                                onTapBookNow: (){
                                  Get.toNamed(
                                      newLibraryBookScheduleScreenRoute,
                                      arguments: NewLibraryBookScheduleScreen(
                                        isDetail: false,
                                        currentIndex: index,
                                        homeData: controller.homeData?[index],
                                        detailsListData: controller.homeData,
                                        // currentDate: DateTime.parse(controller.detailData?.currentDate ?? "${DateTime.now()}"),
                                        currentDate: DateTime.now(),
                                        libraryID: controller.homeData?[index].id ?? "0",
                                      )
                                  );
                                },
                              );
                            }
                        ),
                      )
                          :
                      controller.homeData != null && controller.homeData!.isEmpty ?
                      EmptyDataScreen(
                        onTap: () {
                          init();
                        },
                        isShowBtn: false,
                        string: controller.getHomeApiResponse?.message ?? "Data not available",
                      ):const SizedBox.shrink(), 
                        isLoading: controller.isLoading)
                    ),
                  ),
            ),
          );
            // return SafeArea(
            //     child:
            //     WillPopScope(
            //       onWillPop: onWillPop,
            //       child: Scaffold(
            //         appBar: AppBar(
            //           elevation: 0.0,
            //           backgroundColor: Colors.transparent,
            //           leading: InkWell(
            //             onTap: () {
            //               _scaffoldKey.currentState!.openDrawer();
            //             },
            //             child: Container(
            //               margin: const EdgeInsets.all(10),
            //               width: 30,
            //               decoration: const BoxDecoration(
            //                 color: Colors.white,
            //                 borderRadius: BorderRadius.all(Radius.circular(5.0)),
            //                 boxShadow: [
            //                   BoxShadow(
            //                     color: Colors.black26,
            //                     blurRadius: 10.0,
            //                     offset: Offset(0.0, 5.0),
            //                   ),
            //                 ],
            //               ),
            //               child: Center(
            //                 child:
            //                 // Image.asset(strImgMapMarker1)
            //                 SvgPicture.asset(
            //                   strSvgUser,
            //                   width: 18,
            //                   color: Colors.black,
            //                 ),
            //               ),
            //             ),
            //           ),
            //           actions: [
            //             InkWell(
            //               onTap: () {
            //                 Get.toNamed(searchScreenRoute)?.then((value) {
            //                   init();
            //                 });
            //               },
            //               child: Container(
            //                 margin: const EdgeInsets.all(10),
            //                 width: 35,
            //                 decoration: const BoxDecoration(
            //                   color: Colors.white,
            //                   borderRadius: BorderRadius.all(Radius.circular(5.0)),
            //                   boxShadow: [
            //                     BoxShadow(
            //                       color: Colors.black26,
            //                       blurRadius: 10.0,
            //                       offset: Offset(0.0, 5.0),
            //                     ),
            //                   ],
            //                 ),
            //                 child: Center(
            //                   child: SvgPicture.asset(
            //                     strSvgSearch,
            //                     width: 18,
            //                   ),
            //                 ),
            //               ),
            //             ),
            //             InkWell(
            //               child: Container(
            //                 margin: const EdgeInsets.all(10),
            //                 width: 35,
            //                 decoration: const BoxDecoration(
            //                   color: Colors.white,
            //                   borderRadius: BorderRadius.all(Radius.circular(5.0)),
            //                   boxShadow: [
            //                     BoxShadow(
            //                       color: Colors.black26,
            //                       blurRadius: 10.0,
            //                       offset: Offset(0.0, 5.0),
            //                     ),
            //                   ],
            //                 ),
            //                 child: Center(
            //                   child: SvgPicture.asset(
            //                     strSvgFilter,
            //                     width: 18,
            //                   ),
            //                 ),
            //               ),
            //               onTap: () {
            //                 Get.toNamed(filterScreenRoute);
            //                 // _scaffoldKey.currentState!.openEndDrawer();
            //               },
            //             )
            //           ],
            //           systemOverlayStyle: SystemUiOverlayStyle(
            //             // Status bar color
            //             statusBarColor: CustomColors.bluearrowcolor,
            //
            //             // Status bar brightness (optional)
            //             statusBarIconBrightness: Brightness.dark, // For Android (dark icons)
            //             statusBarBrightness: Brightness.light, // For iOS (dark icons)
            //           ),
            //         ),
            //         key: _scaffoldKey,
            //         extendBodyBehindAppBar: true,
            //         backgroundColor: CustomColors.whiteColor,
            //         drawer: const Drawer(child: ProfileDetailScreen()),
            //         body:  Stack(
            //           children: [
            //             // controller.homeData!.isNotEmpty ?
            //             SingleChildScrollView(
            //                 controller: scrollController,
            //                 physics: const ClampingScrollPhysics(),
            //                 scrollDirection: Axis.vertical,
            //                 child:  Column(
            //                   children: [
            //                     // buildSizeBox(mapHeight, 0.0),
            //                     AnimatedContainer(
            //                       duration: const Duration(milliseconds: 800),
            //                       height: mapHeight,
            //                       width: Get.width,
            //                     ),
            //                     controller.isError ?
            //                     ErrorScreen(
            //                       onTap: () {
            //                         init();
            //                       },
            //                     )
            //                         : controller.isNetworkError ?
            //                     NoInternetConnectionScreen(
            //                       onTap: () {
            //                         init();
            //                       },
            //                     )
            //                         : controller.isEmpty ?
            //                     EmptyDataScreen(
            //                       onTap: () {
            //                         init();
            //                       },
            //                       isShowBtn: false,
            //                       string: kEmptyData,
            //                     )
            //                         : controller.homeData != null && controller.isEmpty == false ?
            //                     ListView.builder(
            //                         shrinkWrap: true,
            //                         physics: const NeverScrollableScrollPhysics(),
            //                         padding: EdgeInsets.zero,
            //                         itemCount: controller.homeData?.length,
            //                         itemBuilder: (context, index) {
            //
            //                           return NewLibraryItemWidget(
            //                             ratingCount: controller.homeData?[index].rating ?? "0",
            //                             distance: controller.homeData?[index].distance ?? "",
            //                             ignoreRatingBarGesture: true,
            //                             facility: controller.homeData?[index].facility ?? [],
            //                             libraryAddress: controller.homeData?[index].address ?? "",
            //                             libraryName: controller.homeData?[index].firmName ?? "",
            //                             openingHour: "${controller.homeData?[index].openTime ?? ""} - ${controller.homeData?[index].closeTime ?? ""}",
            //                             libraryImages: controller.homeData?[index].libraryImages != null && controller.homeData![index].libraryImages!.isNotEmpty ? controller.homeData![index].libraryImages![0] : "",
            //                             lat: double.parse(controller.homeData?[index].latitude.toString() ?? "") ?? 0.0,
            //                             lng: double.parse(controller.homeData?[index].longitude.toString() ?? "") ?? 0.0,
            //                             onTapLibrary: () {
            //                               Get.toNamed(newDetailScreenRoute,arguments: NewDetailScreen(libraryIndex: index,detailsListData: controller.homeData));
            //                             },
            //                             onTapBookNow: (){
            //                               Get.toNamed(
            //                                   newLibraryBookScheduleScreenRoute,
            //                                   arguments: NewLibraryBookScheduleScreen(
            //                                     isDetail: false,
            //                                     currentIndex: index,
            //                                     homeData: controller.homeData?[index],
            //                                     detailsListData: controller.homeData,
            //                                     // currentDate: DateTime.parse(controller.detailData?.currentDate ?? "${DateTime.now()}"),
            //                                     currentDate: DateTime.now(),
            //                                     libraryID: controller.homeData?[index].id ?? "0",
            //                                   )
            //                               );
            //                             },
            //                           );
            //                         }
            //                     )
            //                         :
            //                     controller.homeData != null && controller.homeData!.isEmpty ?
            //                     EmptyDataScreen(
            //                       onTap: () {
            //                         init();
            //                       },
            //                       isShowBtn: false,
            //                       string: controller.getHomeApiResponse?.message ?? "",
            //                     ):const SizedBox.shrink(),
            //                   ],
            //                 )
            //             ),
            //
            //             ///GOOGLE MAP
            //             InkWell(
            //               onTap: (){
            //                 Get.toNamed(googleMapScreenRoute);
            //               },
            //               child: AnimatedContainer(
            //                 height: mapHeight,
            //                 width: Get.width,
            //                 duration: const Duration(milliseconds: 800),
            //
            //                 child: ClipRRect(
            //                   borderRadius: const BorderRadius.only(
            //                     bottomLeft: Radius.circular(64),
            //                     bottomRight: Radius.circular(64),
            //                   ),
            //                   child: GoogleMap(
            //                     mapType: MapType.normal,
            //                     zoomGesturesEnabled: true,
            //                     onMapCreated: _onMapCreated,
            //                     initialCameraPosition:  CameraPosition(
            //                       target: mapCenterArea ?? const LatLng(26.8752545, 75.7628039),
            //                       zoom: 15.0,
            //                     ),
            //                     buildingsEnabled: true,
            //                     scrollGesturesEnabled: true,
            //                     markers: _markers.values.toSet(),
            //                   ),
            //                 ),
            //               ),
            //             ),
            //
            //           ],
            //         ),
            //       ),
            //     )
            // );
        });

  }
}
