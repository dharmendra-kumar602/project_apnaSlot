
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../../../Controller/Helper/Permission/PermissionHandler.dart';
import '../../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../../Controller/WidgetController/StringDefine/StringDefine.dart';
import 'HomeController.dart';

class GoogleMapScreen extends StatefulWidget {
  String? tag;
  GoogleMapScreen({Key? key,required this.tag}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _GoogleMapScreenState();
  }
}

class _GoogleMapScreenState extends State<GoogleMapScreen> {


  HomeController  homeCtrl = Get.find();
  LatLng? mapCenterArea;
  final Map<String, Marker> _markers = {};


  @override
  void initState() {
    super.initState();
  }


  @override
  void dispose() {

    super.dispose();
  }

  Future<void> _onMapCreated(GoogleMapController? controller) async {
    _markers.clear();
    await mapMarkCreate();
  }


  Future<void> mapMarkCreate() async {
    var data=homeCtrl.homeData;
      if(data==null){}else{
    for (int i = 0; i < data.length; i++){
      PrintLog.printLog("For Loop");
      final marker = Marker(
        icon: await BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(size: Size(20, 20)), strImgMapMarker2) ,
        // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed,),
        markerId: MarkerId(data[i].firmName ?? ""),
        position: LatLng(double.parse(data[i].latitude.toString()), double.parse(data[i].longitude.toString() )),
        infoWindow: InfoWindow(
            title: data[i].firmName ?? "",
            snippet: data[i].address ?? "",
            onTap: () {
              PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
            }),
        onTap: () {
          PrintLog.printLog("Clicked on marker");
        },
      );
      PrintLog.printLog("${data[i].latitude}, ${data[i].longitude}");
      _markers[data[i].firmName ?? ""] = marker;
    }
    setState(() {

    });
  }}


  @override 
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      init: homeCtrl,
      builder: (controller) {
        return SafeArea(
          child: Hero(
            tag: widget.tag!,
            child: Scaffold(
              body: Stack(
                children: [
                  GoogleMap(
                    mapType: MapType.normal,
                    zoomGesturesEnabled: true,
                    onMapCreated: _onMapCreated,
                    initialCameraPosition:  CameraPosition(
                      target: mapCenterArea ?? const LatLng(26.8752545, 75.7628039),
                      zoom: 15.0,
                    ),
                    buildingsEnabled: true,
                    scrollGesturesEnabled: true,
                    markers: _markers.values.toSet(),
                  ),
                  InkWell(
                    onTap: (){
                      Get.back();
                    },
                    child: Container(
                      height: 100,
                        width: 100,
                        color: CustomColors.transparentColor,
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.only(left: 10),
                        child: SvgPicture.asset(strSvgBackArrow,color: Colors.black,width: 30)
                        // child: Icon(Icons.arrow_back,size: 40,color: CustomColors.bluearrowcolor,)
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
