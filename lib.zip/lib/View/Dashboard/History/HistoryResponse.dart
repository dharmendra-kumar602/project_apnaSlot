class HistoryApiResponse {
  bool? error;
  String? message;
  int? errorCode;
  String? state;
  List<HistoryData>? data;
  List<FacilityType>? facilityType;

  HistoryApiResponse(
      {this.error, this.message, this.errorCode, this.state, this.data,this.facilityType});

  HistoryApiResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    errorCode = json['errorCode'];
    state = json['state'];
    if (json['data'] != null) {
      data = <HistoryData>[];
      json['data'].forEach((v) {
        data!.add(new HistoryData.fromJson(v));
      });
    }
    if (json['facility_type'] != null) {
      facilityType = <FacilityType>[];
      json['facility_type'].forEach((v) {
        facilityType!.add(new FacilityType.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    data['message'] = this.message;
    data['errorCode'] = this.errorCode;
    data['state'] = this.state;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    if (this.facilityType != null) {
      data['facility_type'] =
          this.facilityType!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class HistoryData {
  String? id;
  String? bookingNumber;
  String? customerId;
  String? libraryId;
  String? subscriptionId;
  String? libraryTableId;
  String? createdBy;
  double? amount;
  String? startDate;
  String? endDate;
  String? bookingDate;
  String? paymentDate;
  String? paymentMode;
  String? paymentReferenceNo;
  String? paidStatus;
  String? createdAt;
  String? updatedAt;
  String? subsName;
  String? tableNo;
  String? libraryName;
  String? address;
  String? openingHour;
  String? ratingStar;
  String? timeSlot;
  List<FacilityType>? facilityType;
  String? invoice;
  int? isExpired;
  String? floorNo;
  bool? isReview;
  int? isVerified;
  HistoryReviewData? reviewData;

  HistoryData(
      {this.id,
      this.bookingNumber,
      this.customerId,
      this.libraryId,
      this.subscriptionId,
      this.libraryTableId,
      this.createdBy,
      this.amount,
      this.startDate,
      this.endDate,
      this.bookingDate,
      this.paymentDate,
      this.paymentMode,
      this.paymentReferenceNo,
      this.paidStatus,
      this.createdAt,
      this.updatedAt,
      this.subsName,
      this.tableNo,
      this.libraryName,
      this.address,
      this.openingHour,
      this.ratingStar,
      this.timeSlot,
      this.facilityType,
      this.isExpired,
      this.invoice,
      this.floorNo,
      this.isReview,
      this.reviewData,
      this.isVerified});

  HistoryData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    bookingNumber = json['booking_number'] != null ? json['booking_number'].toString():null;
    customerId = json['customer_id'] != null ? json['customer_id'].toString():null;
    libraryId = json['library_id'] != null ? json['library_id'].toString():null;
    subscriptionId = json['subscription_id'] != null ? json['subscription_id'].toString():null;
    libraryTableId = json['library_table_id'] != null ? json['library_table_id'].toString():null;
    createdBy = json['created_by'] != null ? json['created_by'].toString():null;
    amount = json['amount'] != null ? double.parse(json['amount'].toString()):null;
    startDate = json['start_date'] != null ? json['start_date'].toString():null;
    endDate = json['end_date'] != null ? json['end_date'].toString():null;
    bookingDate = json['booking_date'] != null ? json['booking_date'].toString():null;
    paymentDate = json['payment_date'] != null ? json['payment_date'].toString():null;
    paymentMode = json['payment_mode'] != null ? json['payment_mode'].toString():null;
    paymentReferenceNo = json['payment_reference_no'] != null ? json['payment_reference_no'].toString():null;
    paidStatus = json['paid_status'] != null ? json['paid_status'].toString():null;
    createdAt = json['created_at'] != null ? json['created_at'].toString():null;
    updatedAt = json['updated_at'] != null ? json['updated_at'].toString():null;
    subsName = json['subs_name'] != null ? json['subs_name'].toString():null;
    tableNo = json['table_no'] != null ? json['table_no'].toString():null;
     libraryName = json['library_name'] != null ? json['library_name'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    openingHour = json['opening_hour'] != null ? json['opening_hour'].toString():null;
    ratingStar = json['rating_star'] != null ? json['rating_star'].toString():null;
    timeSlot = json['time_slot'] != null ? json['time_slot'].toString():null;
    if (json['facility_type'] != null) {
      facilityType = <FacilityType>[];
      json['facility_type'].forEach((v) {
        facilityType!.add(new FacilityType.fromJson(v));
      });
    }
    isExpired = json['is_expired'] != null ? int.parse(json['is_expired'].toString()):null;
    invoice = json['invoice'] != null ? json['invoice'].toString():null;
    floorNo = json['floor_no'] != null ? json['floor_no'].toString():null;
    isReview = json['isReview'];
    isVerified = json['is_verified'] != null ? int.parse(json['is_verified'].toString()):null;
    reviewData = json['reviewData'] != null
        ? new HistoryReviewData.fromJson(json['reviewData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['booking_number'] = this.bookingNumber;
    data['customer_id'] = this.customerId;
    data['library_id'] = this.libraryId;
    data['subscription_id'] = this.subscriptionId;
    data['library_table_id'] = this.libraryTableId;
    data['created_by'] = this.createdBy;
    data['amount'] = this.amount;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['booking_date'] = this.bookingDate;
    data['payment_date'] = this.paymentDate;
    data['payment_mode'] = this.paymentMode;
    data['payment_reference_no'] = this.paymentReferenceNo;
    data['paid_status'] = this.paidStatus;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['subs_name'] = this.subsName;
    data['table_no'] = this.tableNo;
    data['library_name'] = this.libraryName;
    data['address'] = this.address;
    data['opening_hour'] = this.openingHour;
    data['rating_star'] = this.ratingStar;   
    data['time_slot'] = this.timeSlot;
    if (this.facilityType != null) {
      data['facility_type'] =
          this.facilityType!.map((v) => v.toJson()).toList();
    }
    data['is_expired'] = this.isExpired;
    data['invoice'] = this.invoice;
    data['floor_no'] = this.floorNo;
    data['isReview'] = this.isReview;
    data['is_verified'] = this.isVerified;
    if (this.reviewData != null) {
      data['reviewData'] = this.reviewData!.toJson();
    }

    return data;
  }
}

class HistoryReviewData {
  String? id;
  String? userId;
  String? name;
  String? address;
  String? ratingCount;
  String? review;
  String? image;

  HistoryReviewData(
      {this.id,
        this.userId,
        this.name,
        this.address,
        this.ratingCount,
        this.review,
        this.image});

  HistoryReviewData.fromJson(Map<String, dynamic> json) {
    id = json['id'] != null ? json['id'].toString():null;
    userId = json['user_id'] != null ? json['user_id'].toString():null;
    name = json['name'] != null ? json['name'].toString():null;
    address = json['address'] != null ? json['address'].toString():null;
    ratingCount = json['rating_count'] != null ? json['rating_count'].toString():null;
    review = json['review'] != null ? json['review'].toString():null;
    image = json['image'] != null ? json['image'].toString():null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['address'] = this.address;
    data['rating_count'] = this.ratingCount;
    data['review'] = this.review;
    data['image'] = this.image;
    return data;
  }
}


class FacilityType {
  String? name;
  String? image;

  FacilityType({this.name, this.image});

  FacilityType.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    image = json['image'];
    
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['image'] = this.image;
    return data;
  }
}
