import 'package:apna_slot/Controller/RouteController/RouteNames.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/EmptyDataScreen.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/ErrorDataScreen.dart';
import 'package:apna_slot/Controller/WidgetController/ErrorHandling/NetworkErrorScreen.dart';
import 'package:apna_slot/Controller/WidgetController/Loader/LoadScreen/LoadScreen.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:apna_slot/View/Dashboard/History/HistoryController.dart';
import 'package:apna_slot/View/Profile/MyDetails/MyDetailScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../../../../Controller/WidgetController/AdditionalWidget/CustomAppBar.dart';
import '../../../Controller/Helper/ConnectionValidator/ConnectionValidator.dart';
import '../../../Controller/Helper/PrintLog/PrintLog.dart';
import '../../../Controller/Helper/RedirectToMap/RedirectToMap.dart';
import '../../../Controller/WidgetController/BottomSheet/BottomSheetCustom.dart';
import '../../../Controller/WidgetController/LibraryItemWidget/LibraryItemWidget.dart';
import '../../../Controller/WidgetController/Popup/PopupCustom.dart';
import '../../../Controller/WidgetController/RefresherIndicator/RefreshIndicatorCustom.dart';
import '../../../Controller/WidgetController/Toast/ToastCustom.dart';
import '../../Detail/NewDetailsScreen.dart';
import '../../LibraryBooking/LibraryBookShedual/NewLibraryBookScheduleScreen.dart';
import '../../LibraryBooking/LibrarySheetArrangement/SubmitBookingController.dart';
import '../../Review/ReviewController.dart';
import '../Dashboard/DashboardController.dart';
import '../Home/HomeScreen/HomeController.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({Key? key}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return _HistoryScreenState();
  }
}

class _HistoryScreenState extends State<HistoryScreen> {

  DashboardController dashCtrl = Get.find();
  SubmitBookingController submitCTRL = Get.put(SubmitBookingController());

  HistoryController hstCtrl = Get.put(HistoryController());
  ReviewController reviewCtrl = Get.put(ReviewController());
  HomeController  homeCtrl = Get.put(HomeController());

  RefreshController refreshController = RefreshController();

  TextEditingController reviewCT = TextEditingController();
  double reviewRating = 0.0;

  @override
  void initState() {
    init();
    super.initState();
  }

  Future<void> init()async{
    hstCtrl.isNetworkError = false;
    hstCtrl.isEmpty = false;
    if(await ConnectionValidator().check()){
      await hstCtrl.HistoryApi(context: context);
    }else{
      hstCtrl.isNetworkError = true;
      setState(() { });
    }
  }

  // Future<void> getReviewData( String libraryId)async{
  //   await reviewCtrl.getReviewApi(context: context, libraryID:libraryId);
  // }

  @override
  void dispose() {
    reviewCT.dispose();
    refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // print('testing....${hstCtrl.historyData?[0].ratingStar}');
    return GetBuilder<HistoryController>(
      init: hstCtrl,
      builder: (controller) {
        return WillPopScope(
          onWillPop: ()=> dashCtrl.onItemTapped(index: 0),
          child: LoadScreen(
              widget: controller.isError ?
              ErrorScreen(
                onTap: () {
                  init();
                },
              )
                  : controller.isNetworkError ?
              NoInternetConnectionScreen(
                onTap: () {
                  init();
                },
              )
                  : controller.isEmpty ?
              EmptyDataScreen(
                onTap: () {
                  init();
                },
                isShowBtn: false,
                string: kEmptyData,
              )
                  : controller.historyData != null && controller.isEmpty == false ?
              Scaffold(
                resizeToAvoidBottomInset: false,
                extendBodyBehindAppBar: false,
                appBar: CustomAppBar.appBar(
                  title: kMyBooking,
                  onTap: () {
                    dashCtrl.onItemTapped(index: 0);
                  },
                ),
                backgroundColor: Colors.white,
                body: controller.historyData!.isNotEmpty ?
                RefreshIndicatorCustom(
                  refreshController: refreshController,
                  onRefresh: (){
                      refreshController.refreshCompleted();
                    init();
                  },
                  child: Padding(
                    padding:
                    const EdgeInsets.only(left: 15, right: 15, top: 0),
                    child: ListView.builder(
                        shrinkWrap: true,
                        physics: const ClampingScrollPhysics(),
                        padding: EdgeInsets.zero,
                        itemCount: controller.historyData?.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: MyBookingItemWidget(
                              isShowRenewSubscription: controller.historyData?[index].isExpired == 1,
                              historyData: controller.historyData![index],
                              onTapLibrary: (){
                                // Get.toNamed(detailScreenRoute,arguments: DetailScreen(libraryIndex:index].id ?? "0"));
                              },
                              onTapNavigation: (){
                                RedirectToMap.redirect(lat: 26.8530, lng: 75.8047, name: 'WTP');
                              },
                              addReviewBtnTitle: controller.historyData?[index].isReview == true ? kEditReview:kAddReview,
                              onTapAddReview:  (){
                                reviewRating = 1.0;
                                reviewCT.clear();
                                
//  getReviewData(reviewCtrl.reviewData?[index].libraryId.toString()??"");
                                if(controller.historyData?[index].reviewData != null){
                                  reviewRating = double.parse(controller.historyData?[index].reviewData?.ratingCount.toString() ?? "");
                                  reviewCT.text = controller.historyData?[index].reviewData?.review ?? "";
                                }
                                PopupCustom.addReviewPopUp(
                                    context: context,
                                    stars: reviewRating,
                                    btnTitle: kAddReview,
                                    reviewController: reviewCT,
                                    onTap: () async {
                                      if(reviewCT.text.toString().trim().isNotEmpty){
                                        PrintLog.printLog("Review Added: libraryId: ${controller.historyData?[index].libraryId ?? 0} \nRating count: $reviewRating \n comment: ${reviewCT.text}");
                                        await reviewCtrl.updateReview(context: context,libraryID: controller.historyData?[index].libraryId.toString() ?? "0",comment: reviewCT.text.toString().trim(),ratingCount:reviewRating.toString(),
                                        reviewID:controller.historyData?[index].reviewData==null? "":controller.historyData![index].reviewData!.id.toString() ).then((value) {
                                          Get.back();
                                          if(reviewCtrl.isSuccess == true){
                                            init();
                                          }
                                        });
                                      }else{
                                        ToastCustom.showToast(msg: kReviewToastString);
                                      }
                                    },
                                    onRatingUpdate: (value){
                                      reviewRating = value.toDouble();
                                    },
                                    onValue: (e){

                                    }
                                );
                              },
                              onTapRenewSubscription:  () async {
                                int a = homeCtrl.homeData?.indexWhere((element) => element.id == controller.historyData?[index].libraryId) ?? 0;
                                  if(a >= 0){
                                    Get.toNamed(newDetailScreenRoute,arguments: NewDetailScreen(libraryIndex: a,detailsListData: homeCtrl.homeData))?.then((value) {
                                      init();
                                    });
                                  }

                                // if(controller.historyData?[index].isExpired == 1) {
                                //   await submitCTRL.submitBooking(context: context,subscriptionId: controller.historyData?[index].subscriptionId ?? "0",tableId: controller.historyData?[index].libraryTableId ?? "0",isRenew: true,couponCode: "",).then((value) {
                                //   init();
                                // });
                                // //       .then((value) {
                                // //   PopupCustom.seatNotAvailablePopUP(
                                // //       onValue: (e) {
                                // //       },
                                // //       context: context,
                                // //       onTap: (){
                                // //         Get.back();
                                // //         },
                                // //       message: 'This seat is already booked');
                                // // },);
                                // }
                              },
                              onTapInvoice:  () async {
                                // await DownloadFileCustom.saveFileFromUrl(url: controller.historyData?[index].invoice ?? "",context: context).then((value) {
                                //   print("value:...$value");
                                // });
                                // Get.toNamed(pdfViewScreenRoute,arguments: PdfViewScreen(pdfUrl: controller.historyData?[index].invoice ?? "",));
                                BottomSheetCustom.share(context: context, link: controller.historyData?[index].invoice ?? "");

                              },
                              onTapViewDetail:  (){
                                Navigator.pushNamed(context, myDetailScreenRoute,
                                    arguments: MyDetailsScreen(
                                      isShowRenewSubscription: controller.historyData?[index].isExpired == 1,
                                      historyData: controller.historyData?[index],
                                        price: controller.historyData?[index].amount?.toStringAsFixed(0) ?? "0",
                                        subsType: controller.historyData?[index].subsName ?? "",
                                        bookingNo: controller.historyData?[index].bookingNumber ?? "",
                                        reNewSubs: ()async{
                                            int a = homeCtrl.homeData?.indexWhere((element) => element.id == controller.historyData?[index].libraryId) ?? 0;
                                            if(a >= 0){
                                              Get.toNamed(newDetailScreenRoute,arguments: NewDetailScreen(libraryIndex: a,detailsListData: homeCtrl.homeData))?.then((value) {
                                                init();
                                              });
                                            }
                                          // if(controller.historyData?[index].isExpired == 1) {
                                          //   await submitCTRL.submitBooking(context: context,subscriptionId: controller.historyData?[index].subscriptionId ?? "0",tableId: controller.historyData?[index].libraryTableId ?? "0",isRenew: true,couponCode: "",).then((value) {
                                          //     init();
                                          //   });
                                          // }else{
                                          //   ToastCustom.showToast(msg: "Plan is not expired");
                                          // }
                                        },
                                    )
                                );
                              },
                            ),
                          );
                        }),
                  ),
                ) :
                EmptyDataScreen(
                  onTap: () {
                    init();
                  },
                  isShowBtn: false,
                  string: kEmptyData,
                ),
              )
                  : const SizedBox.shrink(),
              isLoading: controller.isLoading
          ),
        );
      },
    );
  }
}
