
import 'package:apna_slot/View/Dashboard/Dashboard/DashboardController.dart';
import 'package:apna_slot/View/Dashboard/Dashboard/DashboardScreen.dart';
import 'package:flutter_cashfree_pg_sdk/api/cferrorresponse/cferrorresponse.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfdropcheckoutpayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentcomponents/cfpaymentcomponent.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentgateway/cfpaymentgatewayservice.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfsession/cfsession.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfenums.dart';
import 'package:flutter_cashfree_pg_sdk/api/cftheme/cftheme.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfexceptions.dart';
import 'package:get/get.dart';
import '../../View/LibraryBooking/CompleteBooking/CompleteBookingScreen.dart';
import '../Helper/PrintLog/PrintLog.dart';
import '../RouteController/RouteNames.dart';
import '../WidgetController/Popup/PopupCustom.dart';
import 'PaymentStatus.dart';



class CashFreeCustom{
  static var cfPaymentGatewayService = CFPaymentGatewayService();

  static Future<void> getInstance() async {
    cfPaymentGatewayService.setCallback(verifyPayment, onError);
  }
  static Future<void> verifyPayment(String orderId)async {
    PrintLog.printLog("Verify Payment:::::::::${orderId}");
    Get.toNamed(paymentStatusRoute,
        arguments: PaymentStatus(
            message: "Your payment was Successful",
            paymentStatus: true,
            onTap: (){
              Get.toNamed(completeBookingScreenRoute,arguments: CompleteBookingScreen(bookingNumber: orderId) );
              // PopupCustom.showCompleteBookingPopUP(context: context,bookingNumber: result.bookingId ?? "");
              // Get.offAllNamed(dashboardScreenRoute,arguments: DashboardScreen(screenIndex: 2));
            }
        ));
  }

  static Future<void> onError(CFErrorResponse errorResponse, String orderId)async {
    PrintLog.printLog("Error while making payment::::::::::::${errorResponse}");
    // Get.toNamed(completeBookingScreenRoute,arguments: CompleteBookingScreen(bookingNumber: orderId) );
    Get.toNamed(paymentStatusRoute,
        arguments: PaymentStatus(
            message: "Your payment was failed",
            paymentStatus: false,
            onTap: (){
              Get.back();
            }
        ));
  }

  static CFSession? createSession({required String environment,required String orderID,required String sessionID}){
    try {
      var session = CFSessionBuilder().setEnvironment(environment.toString().toUpperCase() == "SANDBOX" ? CFEnvironment.SANDBOX:CFEnvironment.PRODUCTION).setOrderId(orderID).setPaymentSessionId(sessionID).build();
      return session;
    } on CFException catch (e) {
      PrintLog.printLog("1Ex::::: ${e.message}");
    }
    return null;
  }

  static Future<void> cashFreeOnTap({required String environment,required String orderID,required String sessionID})async{
    try {
      var session = createSession(environment: environment,orderID: orderID,sessionID: sessionID);
      List<CFPaymentModes> components = <CFPaymentModes>[];
      components.add(CFPaymentModes.UPI);
      components.add(CFPaymentModes.CARD);
      components.add(CFPaymentModes.WALLET);
      var paymentComponent = CFPaymentComponentBuilder().setComponents(components).build();
      var theme = CFThemeBuilder().setNavigationBarBackgroundColorColor("#FF0000").setPrimaryFont("Menlo").setSecondaryFont("Futura").build();
      var cfDropCheckoutPayment = CFDropCheckoutPaymentBuilder().setSession(session!).setPaymentComponent(paymentComponent).setTheme(theme).build();

      cfPaymentGatewayService.doPayment(cfDropCheckoutPayment);
    } on CFException catch (e){
      PrintLog.printLog("2Ex::::: ${e.message}");
    }
  }
}
