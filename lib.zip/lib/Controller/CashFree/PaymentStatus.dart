
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../Controller/Helper/TextController/FontFamily/FontFamily.dart';
import '../../Controller/WidgetController/Button/ButtonCustom.dart';
import '../Helper/ColoController/CustomColors.dart';
import '../WidgetController/AdditionalWidget/AdditionalWidget.dart';
import '../WidgetController/StringDefine/StringDefine.dart';



class PaymentStatus extends  StatefulWidget{
  PaymentStatus({Key? key,required this.message, required this.paymentStatus, required this.onTap}) : super(key: key);
  String? message;
  bool? paymentStatus;
  final OnTap? onTap;

  @override
  State<PaymentStatus> createState() => _PaymentStatusState();
}

class _PaymentStatusState extends State<PaymentStatus> {


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: CustomColors.whiteColor,
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [

                widget.paymentStatus == true ?
                SvgPicture.asset(strSvgPaymentSuccess,height: Get.width *0.70,)
                    :SvgPicture.asset(strSvgPaymentFailed,height: Get.width *0.70,),

                buildSizeBox(Get.width *0.10, 0.0),

                Padding(
                  padding: const EdgeInsets.only(left: 40,right: 40),
                  child: buildText2(fontFamily: FontFamily.larkenRegular,text: widget.message ?? "",color: widget.paymentStatus == true ? Colors.green:Colors.red,size: 28),
                ),

                buildSizeBox(Get.width *0.10, 0.0),


                widget.paymentStatus == true ?
                ButtonCustom(
                    onPress: widget.onTap!,
                    buttonWidth: 220,
                    buttonHeight: 54,
                    text: kCompleteBookingTitle
                )
                    : ButtonCustom(
                    onPress: widget.onTap!,
                    buttonWidth: 150,
                    buttonHeight: 54,
                    text: kRetry
                ),
              ],
            ),
          )
      ),
    );
  }
}

typedef OnTap = void Function();
