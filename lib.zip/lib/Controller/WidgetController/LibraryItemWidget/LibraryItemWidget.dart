
import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:get/instance_manager.dart';
import 'package:sizer/sizer.dart';
import '../../../View/Dashboard/History/HistoryResponse.dart';
import '../../../View/Dashboard/Home/HomeScreen/HomeApiResponse.dart';
import '../../Helper/PrintLog/PrintLog.dart';
import '../../Helper/RedirectToMap/RedirectToMap.dart';
import '../AdditionalWidget/CustomeRattingBar.dart';
import '../Button/ButtonCustom.dart';
import '../Default Widget/DefaultWidget.dart';
import '../ImageHelper/ImageHelper.dart';


// class LibraryItemWidget extends StatelessWidget {
//   // bool? showImage = true;
//   bool? showIcon = false;
//   bool? isBookingPage = false;
//   bool? ignoreRatingBarGesture;
//   Function()? addReviewCallBack;
//   Function()? onTapCallBack;
//   String? libraryName;
//   String? libraryAddress;
//   String? openingHour;
//   String? closingHour;
//   String? libraryImages;
//   List<Facility>? facility;
//
//   LibraryItemWidget(
//       {super.key,
//         this.showIcon,
//         this.isBookingPage,
//         this.addReviewCallBack,
//         this.closingHour,
//         this.openingHour,
//         this.libraryAddress,
//         this.libraryName,
//         this.libraryImages,
//         this.onTapCallBack,
//         required this.facility,
//         this.ignoreRatingBarGesture});
//
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     return Container(
//       // height: 10.h,
//       margin: const EdgeInsets.all(8.0),
//       child: Card(
//         color: const Color.fromRGBO(255, 252, 252, 1),
//         elevation: 0.2,
//         shape: const RoundedRectangleBorder(
//             side: BorderSide(
//               width: 0.5,
//               color: Color.fromRGBO(232, 232, 232, 1),
//             ),
//             borderRadius: BorderRadius.all(Radius.circular(15))),
//         child: InkWell(
//           onTap: onTapCallBack,
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.stretch, // add this
//             children: <Widget>[
//               showIcon == true
//                   ? SizedBox()
//                   : ClipRRect(
//                   borderRadius: const BorderRadius.only(
//                     topLeft: Radius.circular(15),
//                     topRight: Radius.circular(15),
//                   ),
//                   // child: Image.asset('assets/images/library.jpeg',
//                   //     // width: 300,
//                   //     height: 25.h,
//                   //     fit: BoxFit.cover),
//                   child: libraryImages.toString() != null &&
//                       libraryImages.toString() != ""
//                       ? Image.network(
//                     libraryImages.toString(),
//                     fit: BoxFit.cover,
//                   )
//                       : Image.asset(
//                     'assets/images/404.jpg',
//                     fit: BoxFit.cover,
//                   )),
//               // SizedBox(height: getHeight(context)*2/100),
//               Padding(
//                 padding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 3.w),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Row(children: [
//                       showIcon == true
//                           ? Container(
//                         width: 10.w,
//                         height: 10.w,
//                         decoration: BoxDecoration(
//                             color: Colors.white,
//                             shape: BoxShape.circle,
//                             border: Border.all(
//                               color: Colors.grey.shade200,
//                               width: 1,
//                             )),
//                         child: Center(
//                           child: SvgPicture.asset(
//                               strSvgBookReader),
//                         ),
//                       )
//                           : SizedBox(),
//                       showIcon == true
//                           ? SizedBox(
//                         width: 5.w,
//                       )
//                           : SizedBox(),
//                       Column(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           SizedBox(
//                             width: 60.w,
//                             child: Text(
//                               libraryName ?? '',
//                               style: TextStyle(
//                                   fontFamily: FontFamily.josefinRegular,
//                                   fontSize: 16,
//                                   color: Color.fromRGBO(0, 0, 0, 1)),
//                               maxLines: 1,
//                               overflow: TextOverflow.ellipsis,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 1.h,
//                           ),
//                           SizedBox(
//                             width: 60.w,
//                             child: Text(
//                               libraryAddress ?? '',
//                               style: TextStyle(
//                                   fontFamily: FontFamily.josefinRegular,
//                                   fontSize: 14,
//                                   color: const Color.fromRGBO(139, 139, 139, 1),
//                                   height: 1.5),
//                               maxLines: 2,
//                               overflow: TextOverflow.ellipsis,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ]),
//
//                     SvgPicture.asset(
//                       strSvgNavigation,
//                       height: 9.w,
//                     ),
//                     // Image.asset('assets/icons/navigate.png',width: 30,),
//                   ],
//                 ),
//               ),
//
//               ///Divider
//               const Padding(
//                 padding: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
//                 child: Divider(
//                   color: Colors.grey,
//                   height: 1,
//                 ),
//               ),
//
//               ///Divider
//               Padding(
//                 padding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 3.w),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         Row(
//                           children: [
//                             Text('Open hour : ',
//                                 style: TextStyle(
//                                     fontFamily: FontFamily.josefinRegular,
//                                     fontSize: 16)),
//                             Container(
//                               color: Colors.transparent,
//                               width: 30.w,
//                               height: 2.h,
//                               child: FittedBox(
//                                 child: Text(
//                                   openingHour != null && openingHour != ''
//                                       ? '${openingHour} - ${closingHour}'
//                                       : "Always Open",
//                                   style: TextStyle(
//                                       fontFamily: FontFamily.josefinRegular,
//                                       fontSize: 14,
//                                       color: const Color.fromRGBO(
//                                           139, 139, 139, 1)),
//                                 ),
//                               ),
//                             )
//                           ],
//                         ),
//                         Column(
//                           children: [
//                             CustomRattingBar(
//                               stars: 3,
//                               ignoreGesture: ignoreRatingBarGesture ?? true,
//                               onRatingUpdate: (value){
//                                 PrintLog.printLog("Star: $value");
//                               },
//                             ),
//                             isBookingPage == true
//                                 ? InkWell(
//                               onTap: addReviewCallBack,
//                               child: Text(
//                                 'Add Review',
//                                 style: TextStyle(
//                                     fontFamily: FontFamily.josefinRegular,
//                                     color: const Color.fromRGBO(1, 28, 80, 1)),
//                               ),
//                             )
//                                 : const SizedBox()
//                           ],
//                         )
//                       ],
//                     ),
//                     SizedBox(
//                       height: 2.h,
//                     ),
//                     Row(
//                       children: [
//                         Text('Facility : ',
//                             style: TextStyle(
//                                 fontFamily: FontFamily.josefinRegular,
//                                 fontSize: 16)
//                         ),
//                         Container(
//                           height: 50,
//                           // width: 100.w,
//                           child: ListView.builder(
//                             itemCount: facility?.length,
//                             shrinkWrap: true,
//                             padding: EdgeInsets.zero,
//                             scrollDirection: Axis.horizontal,
//                             // physics: NeverScrollableScrollPhysics(),
//                             itemBuilder: (context, index) {
//                               return Container(
//                                 child: Row(
//                                   children: [
//
//                                     SizedBox(
//                                       width: 2.w,
//                                     ),
//                                     Container(
//                                       height: 20,
//                                       width: 20,
//                                       child: Image.network(
//                                           facility?[index].image.toString() ?? ""
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       width: 1.w,
//                                     ),
//                                     Text(
//                                       facility?[index].name.toString() ?? "",
//                                     ),
//                                   ],
//                                 ),
//                               );
//                             },
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(
//                       height: 2.h,
//                     ),
//                     isBookingPage == true
//                         ? Row(
//                       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text('Subscription Type : ',
//                             style: TextStyle(
//                                 fontFamily: FontFamily.josefinRegular,
//                                 fontSize: 16)),
//                         SizedBox(
//                           width: 1.w,
//                         ),
//                         Text(
//                           'Monthly',
//                           style: TextStyle(
//                               fontFamily: FontFamily.josefinRegular,
//                               fontSize: 14,
//                               color:
//                               const Color.fromRGBO(139, 139, 139, 1)),
//                         ),
//                         SizedBox(
//                           width: 4.w,
//                         ),
//                       ],
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? SizedBox(
//                       height: 2.h,
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? Row(
//                       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text('Time Slot : ',
//                             style: TextStyle(
//                                 fontFamily: FontFamily.josefinRegular,
//                                 fontSize: 16
//                             )
//                         ),
//                         SizedBox(
//                           width: 1.w,
//                         ),
//                         Text(
//                           '8AM - 3PM',
//                           style: TextStyle(
//                               fontFamily: FontFamily.josefinRegular,
//                               fontSize: 14,
//                               color:
//                               const Color.fromRGBO(139, 139, 139, 1)),
//                         ),
//                         SizedBox(
//                           width: 4.w,
//                         ),
//                       ],
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? SizedBox(
//                       height: 2.h,
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? Divider(
//                       color: Colors.grey,
//                       height: 1,
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? SizedBox(
//                       height: 2.h,
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Row(
//                           children: [
//                             // AppCommonHeadingBold(text: 'Price : '),
//                             // AppCommonHeadingBold(text: 'Rs. 2500')
//                           ],
//                         ),
//                         InkWell(
//                           onTap: () {},
//                           child: Text(
//                             'Renew Subscription',
//                             style: TextStyle(
//                                 fontFamily: FontFamily.josefinRegular,
//                                 color:
//                                 const Color.fromRGBO(1, 28, 80, 1)),
//                           ),
//                         )
//                       ],
//                     )
//                         : SizedBox(),
//                     isBookingPage == true
//                         ? SizedBox(
//                       height: 3.h,
//                     )
//                         : SizedBox(
//                       height: 0.h,
//                     ),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Row(
//                           children: [
//                             SizedBox(
//                               width: 1.w,
//                             ),
//                             ButtonCustom(
//                               onPress: () {},
//                               text: '5 km',
//                               buttonWidth: 12.w,
//                               buttonHeight: 3.h,
//                               radius: 3,
//                               textSize: 12,
//                             ),
//                           ],
//                         ),
//                         isBookingPage == true
//                             ? ButtonCustom(
//                           onPress: () {},
//                           text: 'Invoice',
//                           buttonWidth: 30.w,
//                           buttonHeight: 5.h,
//                           backgroundColor: Colors.white,
//                           textColor: CustomColors.bluearrowcolor,
//                           useBorder: true,
//                         )
//                             : SizedBox(),
//                         ButtonCustom(
//                             onPress: () {
//                               // Navigator.pushNamed(context, libraryBookShedualScreenRoute);
//                               // isBookingPage == true ?
//                               // Navigator.pushNamed(
//                               //     context,
//                               //     AppRoutes.myDetailsPage,
//                               //     arguments: libraryName
//                               // )
//                               //     : Navigator.pushNamed(
//                               //     context, AppRoutes.bookedSlotPage);
//                             },
//                             text: isBookingPage == true
//                                 ? 'View Detail'
//                                 : 'Book now',
//                             buttonWidth: 30.w,
//                             buttonHeight: 5.h),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//               // ListTile(
//               //   title: Row(
//               //     children: <Widget>[
//               //       Expanded(
//               //           child: ElevatedButton(
//               //               onPressed: () {},
//               //               child: Text("5 Km"),
//               //               style: ButtonStyle(
//               //                   backgroundColor: MaterialStateProperty.all(Colors.blue),
//               //                   padding: MaterialStateProperty.all(const EdgeInsets.all(20)),
//               //                   textStyle: MaterialStateProperty.all(
//               //                       const TextStyle(
//               //                           fontSize: 14,
//               //                           color: Colors.white))))),
//               //       Expanded(
//               //           child: AppCommonButton(
//               //             onPress: () {
//               //               Navigator.pushNamed(context, AppRoutes.detailsPage);
//               //             },
//               //             text: 'Book Now',
//               //             buttonWidth: 50,
//               //             buttonHeight: 10,
//               //
//               //           )
//               //           // ElevatedButton(
//               //           //     onPressed: () {
//               //           //       Navigator.pushNamed(context, AppRoutes.detailsPage);
//               //           //     },
//               //           //     child: Text("Book Now"),
//               //           //     style: ButtonStyle(
//               //           //         backgroundColor: MaterialStateProperty.all(Colors.blue),
//               //           //         padding: MaterialStateProperty.all(const EdgeInsets.all(20)),
//               //           //         textStyle: MaterialStateProperty.all(
//               //           //             const TextStyle(
//               //           //                 fontSize: 14,
//               //           //                 color: Colors.white)
//               //           //         )
//               //           //     )
//               //           // )
//               //       ),
//               //     ],
//               //   ),
//               // ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

class NewLibraryItemWidget extends StatelessWidget {

  bool? ignoreRatingBarGesture;
  Function()? onTapLibrary;
  Function()? onTapBookNow;
  String? libraryImages;
  String? libraryAddress;
  List<HomeFacility>? facility;
  String? libraryName;
  String? openingHour;
  String? ratingCount;
  String? distance;
  double? lat;
  double? lng;
  bool? isShowBookNow;

  NewLibraryItemWidget(
      {super.key,
        this.openingHour,
        this.libraryAddress,
        this.libraryName,
        this.ratingCount,
        this.libraryImages,
        this.onTapLibrary,
        this.onTapBookNow,
        this.distance,
        this.lat,
        this.lng,
        required this.facility,
        this.ignoreRatingBarGesture,
        this.isShowBookNow});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: onTapLibrary,
        child: Card(
          // color: CustomColors.whiteColor,
          elevation: 5,
          shadowColor: CustomColors.whiteColor,
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(
              side: BorderSide(
                width: 0.1,
                color: CustomColors.greyColor,
              ),
              borderRadius: const BorderRadius.all(Radius.circular(15))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch, // add this
              children: <Widget>[

                /// Image
                ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                    ),
                    child: libraryImages != null && libraryImages != ""  && libraryImages !="null"?
                    ImageHelperWhiteBg(
                      image: libraryImages! ,
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,
                      fit: BoxFit.cover,
                      alignment: Alignment.topCenter,
                    ):DefaultWidget.whiteBg(),
                    ),

                /// Name or address
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            buildHeadingBold(text: libraryName ?? '',size: 16.0),
                            buildSizeBox(5.0, 0.0),
                            buildTextWithHeight(text: libraryAddress ?? '',height:1.3,size: 16.0,color: CustomColors.greyColor),
                          ],
                        ),
                      ),
                      buildSizeBox(10.0, 10.0),
                      InkWell(
                        onTap: (){
                          RedirectToMap.redirect(lat: lat ?? kDefaultLat, lng: lng ?? kDefaultLng, name: libraryName ?? "");
                        },
                          child: SvgPicture.asset(strSvgNavigation,height: 30)
                      ),
                    ],
                  ),
                ),

                ///Divider
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 0, horizontal: 15),
                  child: Divider(
                    color: Colors.grey,
                    height: 1,
                  ),
                ),

                /// Other details
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          /// Opening Hours
                          Expanded(
                            child: FittedBox(
                              child: Row(
                                                  
                                children: [
                                  buildText1(text: kOpenHour,size: 16,color: CustomColors.blackColor),
                                  buildText1(text: openingHour ?? "",size: 12,color: CustomColors.greyColor),
                                ],
                              ),
                            ),
                          ),
                      
                          /// Rating bar
                          if( ratingCount != null && ratingCount!.isNotEmpty)...[
                          CustomRattingBar(
                            stars: double.parse(ratingCount.toString()),
                            ignoreGesture: true,
                            size: 15,
                            onRatingUpdate: (value){
                              PrintLog.printLog("Star: $value");
                            },
                          )
                        ]
                        ],
                      ),

                      buildSizeBox(0.0, 0.0),
                      /// Facility
                      facility != null && facility!.isNotEmpty ?
                      SizedBox(
                        height: 50,
                        width: Get.width,
                        child: Row(
                          children: [
                            buildText1(text: kFacility,size: 16,color: CustomColors.blackColor),

                            Expanded(
                              child: ListView.builder(
                                itemCount: facility?.length,
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                scrollDirection: Axis.horizontal,
                                physics: const ClampingScrollPhysics(),
                                itemBuilder: (context, index) {
                                  return Container(
                                    child: Row(
                                      children: [

                                        buildSizeBox(0.0, 5.0),
                                        Container(
                                          height: 16,
                                          width: 16,
                                          child: ImageHelper(
                                            image: facility?[index].image.toString() ?? "",
                                            height: MediaQuery.of(context).size.shortestSide,
                                            width: MediaQuery.of(context).size.width,
                                            fit: BoxFit.fitWidth,
                                            alignment: Alignment.center,
                                          )
                                        ),
                                        buildSizeBox(0.0, 5.0),
                                        buildText1(text: facility?[index].name.toString() ?? "",color: CustomColors.greyColor),
                                        buildSizeBox(0.0, 10.0),

                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      )
                      : const SizedBox.shrink(),


                      /// Distance or Book Now
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ButtonCustom(
                            onPress: () {
                              
                            },
                            text: distance != null ? "${(double.parse(distance.toString())/1000).toStringAsFixed(2)}km": "0km",
                            buttonWidth: 50,
                            buttonHeight: 25,
                            radius: 3,
                            textSize: 12,
                          ),
                          isShowBookNow == true ?
                          ButtonCustom(
                              onPress: onTapBookNow!,
                              text: kBookNow,
                              buttonWidth: 30.w,
                              buttonHeight: 5.h) : const SizedBox.shrink(),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),

        ),
      ),
    );
  }
}

class SearchLibraryItemWidget extends StatelessWidget {

  bool? ignoreRatingBarGesture;
  Function()? onTapLibrary;
  Function()? onTapBookNow;
  String? libraryAddress;
  List<HomeFacility>? facility;
  String? libraryName;
  String? openingHour;
  String? ratingCount;
  String? distance;
  String? lat;
  String? lng;
  String? firmName;
  bool? isShowBookNow;

  SearchLibraryItemWidget(
      {super.key,
        this.openingHour,
        this.libraryAddress,
        this.libraryName,
        this.ratingCount,
        this.onTapLibrary,
        this.onTapBookNow,
        this.distance,
        required this.facility,
        this.ignoreRatingBarGesture,
        this.lat,
        this.lng,
        this.firmName,
        this.isShowBookNow});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0.0),
      child: InkWell(
        onTap: onTapLibrary,
        child: Card(
          color: const Color.fromRGBO(255, 252, 252, 1),
          elevation: 0.2,
          shape: const RoundedRectangleBorder(
              side: BorderSide(
                width: 0.5,
                color: Color.fromRGBO(232, 232, 232, 1),
              ),
              borderRadius: BorderRadius.all(Radius.circular(15))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch, // add this
            children: <Widget>[

              /// Name or address
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      margin: const EdgeInsets.only(right: 10.0),
                      decoration: BoxDecoration(
                          color: CustomColors.whiteColor,
                          borderRadius: const BorderRadius.all(Radius.circular(90)),
                          border: Border.all(color: CustomColors.greyColorLight)),
                      child: Center(
                        child: SvgPicture.asset(strSvgBookReader,width: 20),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildTextWithLine(text: libraryName ?? '',size: 16.0),
                          buildSizeBox(5.0, 0.0),
                          buildTextWithLine(text: libraryAddress ?? '',size: 16.0,color: CustomColors.greyColor,maxLines: 2),
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        RedirectToMap.redirect(
                          lat: double.parse(lat ?? "") ,
                          lng: double.parse(lng ?? ""),
                          name: firmName ?? "" ,
                        );
                      },
                      child: SvgPicture.asset(strSvgNavigation,height: 30)),
                  ],
                ),
              ),

              ///Divider
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
                child: Divider(
                  color: Colors.grey,
                  height: 1,
                ),
              ),

              /// Other details
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        /// Opening Hours
                        Expanded(
                          child: FittedBox(
                            child: Row(
                              children: [
                                buildText1(text: kOpenHour,size: 16),
                                buildText1(text: openingHour ?? "",size: 12,color: CustomColors.greyColor),
                              ],
                            ),
                          ),
                        ),

                        /// Rating bar
                        if( ratingCount != null && ratingCount!.isNotEmpty)...[
                        CustomRattingBar(
                          stars: double.parse(ratingCount.toString() ) ,
                          ignoreGesture: ignoreRatingBarGesture ?? true,
                          size: 16,
                          onRatingUpdate: (value){
                            PrintLog.printLog("Star: $value");
                          },
                        )
                      ]
                      ],
                    ),
                    buildSizeBox(0.0, 0.0),
                    
                    /// Facility
                    facility != null && facility!.isNotEmpty ?
                    SizedBox(
                      height: 50,
                      width: Get.width,
                      child: Row(
                        children: [
                          buildText1(text: kFacility,size: 16),

                          Expanded(
                            child: ListView.builder(
                              itemCount: facility?.length,
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              scrollDirection: Axis.horizontal,
                              physics: const ClampingScrollPhysics(),
                              itemBuilder: (context, index) {
                                return Container(
                                  child: Row(
                                    children: [

                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      Container(
                                        height: 16,
                                        width: 16,
                                        child: ImageHelper(
                                            image: facility?[index].image.toString() ?? "",
                                            height: 16,
                                            width: 16,
                                            fit: BoxFit.contain,
                                            alignment: Alignment.center)
                                        // Image.network(
                                        //     facility?[index].image.toString() ?? ""
                                        // ),
                                      ),
                                      SizedBox(
                                        width: 1.w,
                                      ),
                                      Text(
                                        facility?[index].name.toString() ?? "",
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    )
                    : const SizedBox.shrink(),
                    buildSizeBox(15.0, 0.0),

                    /// Distance or Book Now
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ButtonCustom(
                          onPress: () {},
                          text: distance != null ? "${(double.parse(distance.toString())/1000).toStringAsFixed(2)}km": "0km",
                          buttonWidth: 50,
                          buttonHeight: 25,
                          radius: 3,
                          textSize: 12,
                        ),
                        isShowBookNow == true ?
                        ButtonCustom(
                            onPress: onTapBookNow!,
                            text: kBookNow,
                            buttonWidth: 30.w,
                            buttonHeight: 5.h) : const SizedBox.shrink(),
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyBookingItemWidget extends StatelessWidget {

  HistoryData? historyData;
  Function()? onTapLibrary;
  Function()? onTapViewDetail;
  Function()? onTapInvoice;
  Function()? onTapAddReview;
  Function()? onTapRenewSubscription;
  Function()? onTapNavigation;
  String? addReviewBtnTitle;
  bool? isShowRenewSubscription;

  MyBookingItemWidget(
      {super.key,
        this.historyData,
        this.onTapLibrary,
        this.onTapViewDetail,
        this.onTapInvoice,
        this.addReviewBtnTitle,
        this.onTapAddReview,
        this.onTapRenewSubscription,
        this.onTapNavigation,
        this.isShowRenewSubscription,
      });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0.0),
      child: InkWell(
        onTap: onTapLibrary,
        child: Card(
          color: const Color.fromRGBO(255, 252, 252, 1),
          elevation: 5,
          shape: const RoundedRectangleBorder(
              side: BorderSide(
                width: 0.5,
                color: Color.fromRGBO(232, 232, 232, 1),
              ),
              borderRadius: BorderRadius.all(Radius.circular(15))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch, // add this
            children: <Widget>[

              /// Name or address
              Padding(
                padding: const EdgeInsets.only(top: 15,right: 15,left: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      margin: const EdgeInsets.only(right: 10.0),
                      decoration: BoxDecoration(
                          color: CustomColors.whiteColor,
                          borderRadius: const BorderRadius.all(Radius.circular(90)),
                          border: Border.all(color: CustomColors.greyColorLight)),
                      child: Center(
                        child: SvgPicture.asset(strSvgBookReader,width: 20),
                      ),
                    ),

                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildTextWithLine(text: historyData?.libraryName ?? '',size: 16.0,color: CustomColors.blackColor),
                          buildSizeBox(5.0, 0.0),
                          buildTextWithLine(text: historyData?.address ?? '',color: CustomColors.greyColor,maxLines: 1),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10,),
                    InkWell(
                      onTap: onTapNavigation,
                      child: SvgPicture.asset(strSvgNavigation,height: 30)),
                  ],
                ),
              ),

              ///Divider
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 15),
                child: Divider(thickness: 1,height: 25,),
              ),

              /// Other details
              Padding(
                padding: const EdgeInsets.only(right: 15,left: 15),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   crossAxisAlignment: CrossAxisAlignment.center,
                    //   children: [

                    //     /// Opening Hours
                    //     Expanded(
                    //       child: Row(
                    //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //         children: [
                    //           buildText1(text: kOpenHour,color: CustomColors.blackColor),
                    //           buildText1(text: historyData?.openingHour ?? "",color: CustomColors.greyColor),
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    // buildSizeBox(12.0, 0.0),

                    ///Schedule Timing
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,                   
                      children: [
                        buildText1(text: 'Schedule timing',color: CustomColors.blackColor) ,
                        buildText1(text: historyData?.timeSlot ?? "",color: CustomColors.greyColor),
                      ],
                    ),
                    buildSizeBox(12.0, 0.0),

                    ///Start Date
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,                   
                      children: [
                        buildText1(text: 'Start Date : ',color: CustomColors.blackColor) ,
                        buildText1(text: historyData?.startDate ?? "",color: CustomColors.greyColor),
                      ],
                    ),
                    buildSizeBox(12.0, 0.0),

                    ///Seat number
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildText1(text: kSeatNum,color: CustomColors.blackColor) ,
                        buildText1(text: historyData?.tableNo ?? "",color: CustomColors.greyColor),
                      ],
                    ),
                    buildSizeBox(10.0, 0.0),
                    // /// Facility
                    // historyData?.facilityType != null && historyData!.facilityType!.isNotEmpty ?
                    // SizedBox(
                    //   height: 30,
                    //   width: Get.width,
                    //   child: Row(
                    //     children: [
                    //       buildText1(text: kFacility,color: CustomColors.blackColor),

                    //       Expanded(
                    //         child: ListView.builder(
                    //           itemCount: historyData?.facilityType?.length,
                    //           shrinkWrap: true,
                    //           padding: EdgeInsets.zero,
                    //           scrollDirection: Axis.horizontal,
                    //           physics: const ClampingScrollPhysics(),
                    //           itemBuilder: (context, index) {
                    //             return Row(
                    //               children: [
                    //                 SizedBox(
                    //                   height: 16,
                    //                   width: 16,
                    //                   child:
                    //                   ImageHelper(
                    //                     image: historyData?.facilityType?[index].image.toString() ?? "",
                    //                     height: MediaQuery.of(context).size.shortestSide,
                    //                     width: MediaQuery.of(context).size.width,
                    //                     fit: BoxFit.fitWidth,
                    //                     alignment: Alignment.center,
                    //                   )
                    //                   // Image.network(
                    //                   //     historyData?.facilityType?[index].image.toString() ?? ""
                    //                   // ),
                    //                 ),
                    //                 buildSizeBox(0.0, 5.0),
                    //                 buildText1(text: historyData?.facilityType?[index].name.toString() ?? "",color: CustomColors.greyColor),
                    //                 buildSizeBox(0.0, 10.0),
                    //               ],
                    //             );
                    //           },
                    //         ),
                    //       ),
                    //     ],
                    //   ),
                    // )
                    // : const SizedBox.shrink(),
                    // buildSizeBox(5.0, 0.0),

                    // /// Subscription type
                    // Row(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       buildText1(text: '$kSubscriptionType : ',color: CustomColors.blackColor) ,
                    //       Expanded(child: buildText1(text: historyData?.subsName ?? "",color: CustomColors.greyColor)),
                    //       // const Spacer(),
                    //       /// Rating bar
                    //       CustomRattingBar(
                    //         stars: double.parse(historyData?.ratingStar.toString() ?? "0.0") ,
                    //         ignoreGesture: true,
                    //         size: 12,
                    //         onRatingUpdate: (value){
                    //           PrintLog.printLog("Star: $value");
                    //         },
                    //       )
                    //     ]
                    // ),
                    // buildSizeBox(10.0, 0.0),

                    // /// Time slot
                    // Row(   
                    //   crossAxisAlignment: CrossAxisAlignment.start,                   
                    //   children: [
                    //     Expanded(
                    //       child: Row(
                    //         crossAxisAlignment: CrossAxisAlignment.start,                   
                    //         children: [
                    //           buildText1(text: kTimeSlot,color: CustomColors.blackColor) ,
                    //           Expanded(child: buildText1(text: historyData?.timeSlot ?? "",color: CustomColors.greyColor)),
                    //         ],
                    //       ),
                    //     ),

                    //     historyData?.paidStatus == "1" ?
                    //     InkWell(
                    //         onTap: onTapAddReview,
                    //         child: Container(
                    //             alignment: Alignment.topCenter,
                    //             width: 80,
                    //             height: 25,
                    //             child: buildHeading(
                    //               text: addReviewBtnTitle ?? "",
                    //               color: CustomColors.bluearrowcolor,
                    //               size: 14,
                    //             ))) : const SizedBox.shrink()
                    //   ],
                    // ),
                    // historyData?.paidStatus == "0" ? buildSizeBox(10.0, 0.0) : const SizedBox.shrink(),


                    ///Payment Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildText1(text: 'Payment : ',color: CustomColors.blackColor),
                        historyData?.paidStatus == "1" ?
                        Row(
                          children: [
                            buildText1(text: kSuccess,color: Colors.green),
                            const Icon(Icons.check_circle,color: Colors.green,size: 20,)
                          ],
                        ) :
                        Row(
                          children: [
                            buildText1(text: kFailed,color: CustomColors.redColor),
                            Icon(Icons.error,color: CustomColors.redColor,size: 20,)
                          ],
                        )
                      ],
                    ),
                    buildSizeBox(10.0, 0.0),

                    ///Verified
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildText1(text: 'Verified : ',color: CustomColors.blackColor),
                        historyData?.isVerified == 1 ?
                        buildText1(text: kYes,color: Colors.green) : buildText1(text: kNo,color: CustomColors.redColor)
                      ],
                    ),
                    buildSizeBox(10.0, 0.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        
                        ///Rating Stars
                        CustomRattingBar(
                            stars: historyData?.ratingStar != null && historyData!.ratingStar!.isNotEmpty ? double.parse(historyData?.ratingStar ?? "0") : 0.0,
                            ignoreGesture: true,
                            size: 15,
                            onRatingUpdate: (value){
                              PrintLog.printLog("Star: $value");
                            },
                          ),

                          ///Add Review
                          historyData?.paidStatus == "1" ?
                        InkWell(
                            onTap: onTapAddReview,
                            child: Container(
                                alignment: Alignment.topCenter,
                                width: 80,
                                height: 25,
                                child: buildHeading(
                                  text: addReviewBtnTitle ?? "",
                                  color: CustomColors.bluearrowcolor,
                                  size: 14,
                                ))) : const SizedBox.shrink()
                      ],
                    ),
                    buildSizeBox(5.0, 0.0),

                    
                    // historyData?.paidStatus == "0" ? buildSizeBox(10.0, 0.0) : const SizedBox.shrink(),

                    // ///Floor number
                    // Row(
                    //   children: [
                    //     Expanded(
                    //       child: Row(
                    //         children: [
                    //           buildText1(text: kFloorNum,color: CustomColors.blackColor),
                    //           Expanded(child: buildText1(text: historyData?.floorNo ?? "",color: CustomColors.greyColor)),
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    // buildSizeBox(10.0, 0.0),

                    // ///Booking Number
                    // Row(
                    //   children: [
                    //     Expanded(
                    //       child: Row(
                    //         children: [
                    //           buildText1(text: kBookingNumber,color: CustomColors.blackColor),
                    //           Expanded(child: buildText1(text: historyData?.bookingNumber ?? "",color: CustomColors.greyColor)),
                    //         ],
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    // buildSizeBox(10.0, 0.0),

                    // ///Expiry Date                    
                    // Row(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     Expanded(
                    //       child: Row(
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: [
                    //           Padding(
                    //             padding: const EdgeInsets.only(bottom: 5),
                    //             child: buildText1(text: kExpiryDate,color: CustomColors.blackColor),
                    //           ),
                    //           Expanded(child: buildText1(text: historyData?.endDate ?? "N/A",color: CustomColors.greyColor)),
                    //         ],
                    //       ),
                    //     ),

                        
                    //   ],
                    // ),

                    const Divider(thickness: 1,height: 0,),

                    /// Price
                    Row(
                      children: [
                        buildHeading(text: kAmount, color: CustomColors.blackColor, size: 18),
                        buildHeading(text: "₹${historyData?.amount?.toStringAsFixed(0) ?? ""}", size: 18),
                        const Spacer(),
                        isShowRenewSubscription == true ?
                        InkWell(
                            onTap:onTapRenewSubscription,
                            child: Container(
                                alignment: Alignment.center,
                                width: 130,
                                height: 40,
                                child: buildHeading(
                                  text: kRenewSub,
                                  color: CustomColors.bluearrowcolor,
                                  size: 14,
                                ))):buildSizeBox(40.0, 0.0)
                      ],
                    ),
                    /// Distance or Book Now
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // ButtonCustom(
                        //   onPress: () {},
                        //   text: "1km",//historyData?. != null ? "${(double.parse(distance.toString())/1000).toStringAsFixed(2)}km": "0km",
                        //   buttonWidth: 50,
                        //   buttonHeight: 20,
                        //   radius: 3,
                        //   textSize: 12,
                        // ),
                        // buildSizeBox(0.0, 20.0),

                        historyData?.paidStatus == "1" ?
                        ButtonCustomWithBorder(
                            onPress: onTapInvoice!,
                            text: kInvoice,
                            buttonWidth: 100,
                            buttonHeight: 30,
                          textColor: CustomColors.bluearrowcolor,
                        ) : const SizedBox.shrink(),
                        // const Spacer(),

                        historyData?.paidStatus == "1" ?
                        ButtonCustom(
                            onPress: onTapViewDetail!,
                            text: kViewDetail,
                            buttonWidth: 100,
                            buttonHeight: 35
                        ) : const SizedBox.shrink(),
                      ],
                    ),
                    buildSizeBox(15.0, 0.0),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
