import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

import '../../Helper/ColoController/CustomColors.dart';



class CustomTextField extends StatelessWidget{

  final OnTextChanged? onChanged;
  String? labelText = "";
  TextEditingController? controller;
  FocusNode? focus;
  bool? enable;
  bool readOnly;
  TextInputType? inputType;
  TextInputAction? inputAction;
  double? leftPadding;
  String? hintText ;
  String? errorText ;
  int? maxLines = 1;
  int? maxLength = 100;
  List<TextInputFormatter>? inputFormatters;
  Widget? prefixIcon;
  Widget? suffixIcon;
  Widget? suffixWidget;
  bool? obscureText;
  bool? isError;
  String? Function(String?)? validator;
  Iterable<String>? autofillHints;
  VoidCallback? onTap;
  Function()? onComplete;

  CustomTextField({
    Key? key,
    this.autofillHints,
    this.validator,
    this.enable,
    this.maxLines,
    required this.readOnly,
    this.onChanged,
    this.labelText,
    this.inputType,
    this.inputAction,
    this.hintText,
    this.maxLength,
    this.errorText,
    this.focus,
    this.isError,
    this.controller,
    this.inputFormatters,
    this.prefixIcon,
    this.obscureText,
    this.suffixWidget,
    this.suffixIcon,
    this.onTap,
    this.onComplete}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      // margin: EdgeInsets.all(5),
        height: isError == true ? 60:54,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(0),
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 5),
          child: TextFormField(
            onEditingComplete: onComplete,
            onTap: onTap,
            focusNode: focus,
            autofillHints: autofillHints,
            validator: validator,
            textInputAction: inputAction,
            keyboardType: inputType,
            autofocus: false,
            enabled: enable,
            readOnly: readOnly,
            maxLength: maxLength,
            maxLines: maxLines,
            inputFormatters: inputFormatters,
            obscureText: obscureText != null ? obscureText! : false,
            style: TextStyle(fontFamily: FontFamily.josefinRegular,fontSize: 16),
            controller: controller,
            decoration: InputDecoration(
                prefixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 50),
                contentPadding: const EdgeInsets.only(top: 6.0,left: 15),
                counter: const Offstage(),
                hintText: hintText,
                errorText: errorText,
                suffixIcon: suffixIcon,
                suffix: suffixWidget,
                labelText:labelText,
                border: InputBorder.none,
                prefixIcon: prefixIcon,
                suffixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 55),
                hintStyle: TextStyle(fontFamily: FontFamily.josefinRegular,color: Colors.grey)
            ),
            onFieldSubmitted: (v) {
              FocusScope.of(context).requestFocus(focus);
            },
            onChanged: (value){
              if(onChanged != null) {
                onChanged!(value);
              }
            },
          ),
        )
    );
  }

}

typedef OnTextChanged = void Function(String value);


class CustomTextField2 extends StatelessWidget{

  Function(String)? onChanged;
  TextInputAction? textInputAction;
  TextEditingController? controller;
  TextInputType? keyboardType;
  FocusNode? focus;
  Function()? onTap;
  String? hintText;
  Widget? prefixIcon;
  Widget? suffixIcon;
  bool? readOnly = false;
  bool? autofocus = false;

  CustomTextField2({
    Key? key,
    this.onChanged,
    this.textInputAction,
    this.controller,
    this.keyboardType,
    this.focus,
    this.onTap,
    this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.readOnly,
    this.autofocus,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return TextField(
      controller: controller,
      textInputAction: textInputAction,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.black,fontSize: 14),
      readOnly: readOnly ?? false,
      autofocus: autofocus ?? false,
      focusNode: focus,
      onTap: onTap,
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: hintText,
        prefixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 55),//10
        suffixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 55),//10
        hintStyle: TextStyle(color: Colors.grey,fontFamily: FontFamily.josefinRegular,fontSize: 14.0),
        fillColor: CustomColors.greyColorLight,
        filled: true,
        prefixIcon: prefixIcon,
        suffixIcon: suffixIcon,
        contentPadding: const EdgeInsets.only(left: 15.0, right: 15.0),
        border:  OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
      ),
    );
  }

}

class CustomTextFieldRaiseQuery extends StatelessWidget{

  Function(String)? onChanged;
  TextInputAction? textInputAction;
  TextEditingController? controller;
  TextInputType? keyboardType;
  FocusNode? focus;
  Function()? onTap;
  String? hintText;
  int? maxLine;
  Widget? prefixIcon;
  Widget? suffixIcon;
  bool? readOnly = false;
  bool? autofocus = false;

  CustomTextFieldRaiseQuery({
    Key? key,
    this.onChanged,
    this.textInputAction,
    this.controller,
    this.keyboardType,
    this.focus,
    this.maxLine,
    this.onTap,
    this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.readOnly,
    this.autofocus,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return TextField(
      controller: controller,
      textInputAction: textInputAction,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.black,fontSize: 14),
      readOnly: readOnly ?? false,
      autofocus: autofocus ?? false,
      focusNode: focus,
      onTap: onTap,
      maxLines: maxLine ?? 6,
      maxLength: 500,
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: hintText,
        counterText: "",
        prefixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 55),//10
        suffixIconConstraints: const BoxConstraints(minWidth: 50, maxHeight: 55),//10
        hintStyle: TextStyle(color: Colors.grey,fontFamily: FontFamily.josefinRegular,fontSize: 14.0),
        fillColor: CustomColors.greyColorLight,
        filled: true,
        prefixIcon: prefixIcon,
        suffixIcon: suffixIcon,
        contentPadding: const EdgeInsets.only(left: 15.0, right: 15.0,top: 10,bottom: 10),
        border:  OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.0),
          borderSide: BorderSide(color: CustomColors.transparentColor),),
      ),
    );
  }

}

