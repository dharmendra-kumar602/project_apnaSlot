import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../StringDefine/StringDefine.dart';

class DefaultWidget {
  static Widget image() {
    return Container(
      color: Colors.grey.withOpacity(0.1),
      child: Image.asset(
        str_imgDefaultBg,
        fit: BoxFit.contain,
      ),
    );
  }

  static Widget whiteBg() {
    return Container(
      color: Colors.white,
    );
  }
  static Widget transparentBg() {
    return Container(
      color: Colors.transparent,
    );
  }
}
