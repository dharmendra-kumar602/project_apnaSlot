
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:flutter/material.dart';
import '../../Helper/ColoController/CustomColors.dart';
import '../../Helper/TextController/FontFamily/FontFamily.dart';
import '../StringDefine/StringDefine.dart';


class CheckBoxCustomWithText extends StatefulWidget {
  final bool? value;
  final String? title1;
  final String? title2;
  final double? leftSpace;
  final double? rightSpace;
  Function()? onTap;
  final ValueChanged<bool?>? onChanged;

  CheckBoxCustomWithText({
    Key? key,
    required this.value,
    this.onChanged,
    this.title1,
    this.title2,
    this.leftSpace,
    this.rightSpace,
    this.onTap,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CheckBoxCustomWithTextState();
}

class _CheckBoxCustomWithTextState extends State<CheckBoxCustomWithText> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Transform.translate(
          offset:  const Offset(-6, 0),
          child: Checkbox(
            value: widget.value,
            visualDensity: const VisualDensity(horizontal: -4,vertical: -4),
            splashRadius: 0.0,
            onChanged:widget.onChanged,
            fillColor: MaterialStateProperty.all(CustomColors.bluearrowcolor),
          ),
        ),
        widget.title1 != "" ? buildText1(text: widget.title1 ?? "",color: CustomColors.greyColor):const SizedBox.shrink(),
        widget.title2 != "" ? InkWell(onTap: widget.onTap,child: buildText1(text: widget.title2 ?? "",decoration:TextDecoration.underline )):const SizedBox.shrink(),
      ],
    );

  }

}


class CheckBoxCustomWithTextBorder extends StatefulWidget {
  final bool? value;
  final String label;
  final bool leadingCheckbox;
  final double? radius;
  final double? height;
  final double? width;
  final double? space;
  final ValueChanged<bool?>? onChanged;

  CheckBoxCustomWithTextBorder({
    Key? key,
    required this.value,
    this.onChanged,
    required this.label,
    this.leadingCheckbox = true,
    this.radius,
    this.height,
    this.width,
    this.space
  }) : super(key: key);

  @override
  State<CheckBoxCustomWithTextBorder> createState() => _CheckBoxCustomWithTextBorderState();
}

class _CheckBoxCustomWithTextBorderState extends State<CheckBoxCustomWithTextBorder> {
  var value = false;

  @override
  void initState() {
    super.initState();
    value = widget.value == true;
  }

  @override
  Widget build(BuildContext context) {
    var widgets = <Widget>[
      _buildCheckbox(context),
    ];
    if (widget.label.isNotEmpty) {
      if (widget.leadingCheckbox) {
        widgets.add(SizedBox(width: widget.space ?? 10,));
        widgets.add(_buildLabel(context));
      } else {
        widgets.insert(0, _buildLabel(context));

      }
    }
    return SizedBox(
      // height: widget.height ?? 4.h,
      height: 20,
      child: InkWell(
        borderRadius: BorderRadius.circular(4),
        onTap: () => _onCheckedChanged(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          // mainAxisSize: MainAxisSize.min,
          children: widgets,
        ),
      ),
    );

  }

  Widget _buildCheckbox(BuildContext context) {
    return
      Container(
          margin: const EdgeInsets.all(0),
          // color: Colors.white,
          // width: widget.width ?? 10.w,
          clipBehavior: Clip.antiAlias,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
              border: Border.all(
                  width: 1,
                  color: Colors.red
              ),
              borderRadius: BorderRadius.circular(3)
          ),
          width: 20,
          child: Theme(
            data: ThemeData(
              // unselectedWidgetColor: AppColors.darkblueprofile,
            ),
            child:Checkbox(
              checkColor: Colors.red,
              fillColor: MaterialStateProperty.all<Color>(Colors.white),
              activeColor: CustomColors.whiteColor,
              value: value,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(3.0)),

              onChanged: (v) => _onCheckedChanged(),
              side: const BorderSide(
                color: Colors.white,
              ),

            ),
          )
      );


  }

  Widget _buildLabel(BuildContext context) {
    // var padding =
    // widget.leadingCheckbox ? EdgeInsets.only(right: widget.rightPadding ?? 8) :  EdgeInsets.only(left: widget.leftPadding ?? 8);

    return Padding(
      padding: EdgeInsets.zero,
      child:
      Text(widget.label.toString(),style: TextStyle(fontFamily: FontFamily.larkenMedium,fontSize: 14.0,color: CustomColors.blackColor),),
    );
  }

  void _onCheckedChanged() {
    setState(() {
      value = !value;
    });
    if (widget.onChanged != null) {
      widget.onChanged!.call(value);
    }
  }
}