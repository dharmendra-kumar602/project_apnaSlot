import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

class OtpTextfieldWidget extends StatelessWidget{

  final OnTextChanged? onChanged;
  TextEditingController? textEditingController;
  FocusNode? focus;
  final OnTapText? onTap;

  OtpTextfieldWidget({Key? key,this.onTap,this.onChanged,this.focus,this.textEditingController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return CircleAvatar(
        backgroundColor: Colors.grey[200],
        radius: 4.h,
        child: Center(
          child: TextFormField(
            autofocus: true,
            obscureText: false
            ,
            focusNode: focus,
            controller: textEditingController,
            style: TextStyle(fontSize: 22.0,fontFamily: FontFamily.josefinRegular,  color: Colors.black),
            textInputAction: TextInputAction.next,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 1,
            inputFormatters: <TextInputFormatter>[
              FilteringTextInputFormatter.digitsOnly
            ],
            decoration: const InputDecoration(
                counterText: "",border: InputBorder.none,contentPadding: EdgeInsets.only(left: 3)
            ),
            showCursor: false,
            onTap: onTap,
            onChanged: (value){
              if(onChanged != null) {
                onChanged!(value);
              }
            },
          ),
        )

    );
  }

}

typedef OnTextChanged = void Function(String value);

typedef OnTapText = void Function();