import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'AdditionalWidget.dart';

class CustomRangeSlider extends StatefulWidget {
  const CustomRangeSlider({Key? key, required this.lblEndRange,
    required this.lblStartRange,required this.title,required this.startRange,required this.endRange}) : super(key: key);
  final String title;
  final int startRange;
  final int endRange;
  final double lblStartRange;
  final double lblEndRange;

  @override
  State<CustomRangeSlider> createState() => _CustomRangeSliderState();
}

class _CustomRangeSliderState extends State<CustomRangeSlider> {

  double lblStart = 0.0;
  double lblEnd = 0.0;
  RangeValues? valuesMain;

  @override
  void initState() {
    valuesMain = RangeValues(widget.startRange.toDouble(), widget.endRange.toDouble());
    lblStart = widget.startRange.toDouble();
    lblEnd =  widget.endRange.toDouble();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            buildTextCommon( text: lblStart.toStringAsFixed(0),),
            buildTextCommon( text: lblEnd.toStringAsFixed(0),),
          ],
        ),

        RangeSlider(
            activeColor: CustomColors.bluearrowcolor,
            inactiveColor: CustomColors.greyColor,
            min: widget.startRange.toDouble(),
            max: widget.endRange.toDouble(),
            values: valuesMain!,
            onChanged: (values){
              setState(() {
                  lblStart = values.start;
                  lblEnd = values.end;
                  valuesMain = values;
              });
            }
        ),
      ],
    );
  }
}