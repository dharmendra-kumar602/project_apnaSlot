import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'AdditionalWidget.dart';

class CustomDropDown extends StatefulWidget {
  _CustomDropDownState createState() => _CustomDropDownState();
}

class _CustomDropDownState extends State<CustomDropDown> {
  String dropdownvalue = '1 hour';
  var items = [
    '1 hour',
    '2 hour',
    '3 hour',
    '4 hour',
    '5 hour',
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      width: 100.w,
      height: 5.h,
      color: CustomColors.greyColorLight,
      child: DropdownButton(
        underline: SizedBox(),
        // Initial Value
        value: dropdownvalue,
        isExpanded : true,

        // Down Arrow Icon
        icon: Icon(Icons.keyboard_arrow_down,color: CustomColors.headingText,),

        // Array list of items
        items: items.map((String items) {
          return DropdownMenuItem(
            value: items,
            child: buildTextCommon(text: items,),
          );
        }).toList(),
        // After selecting the desired option,it will
        // change button value to selected value
        onChanged: (String? newValue) {
          setState(() {
            dropdownvalue = newValue!;
          });
        },
      ),
    );

  }

}