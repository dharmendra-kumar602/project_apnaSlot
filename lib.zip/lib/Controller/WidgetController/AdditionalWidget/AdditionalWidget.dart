import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:flutter/cupertino.dart';
import '../../Helper/ColoController/CustomColors.dart';


Widget buildSizeBox(height,width){
  return SizedBox(height: height, width: width,);
}

Widget buildMainHeading({required String text,double? size,int? maxLines,double? lineHeight,Color? color}){
  return Text(
    text,
    style: TextStyle(
        fontFamily: FontFamily.larkenRegular,
        fontSize: size ?? 24,
        height: lineHeight,
        color: color ?? CustomColors.bluearrowcolor
    ),
  );
}

Widget buildMainHeadingForEmptyScreen({required String text,double? size,int? maxLines,double? lineHeight,Color? color}){
  return Text(
    text,
    style: TextStyle(
        fontFamily: FontFamily.larkenRegular,
        fontSize: size ?? 24,
        height: lineHeight,
        color: color ?? CustomColors.bluearrowcolor
    ),textAlign: TextAlign.center,
  );
}

Widget buildMainDescription({required String text,TextAlign? textAlign,double? letterSpacing,double? size,int? maxLines,double? lineHeight,Color? color}){
  return Text(
    text,
    style: TextStyle(
        fontFamily: FontFamily.josefinRegular,
        fontSize: size ?? 14,
        height: lineHeight ?? 1.4,
        color: color ?? CustomColors.bluearrowcolor,
        letterSpacing:letterSpacing ?? 0.37,
    ),textAlign: textAlign ?? TextAlign.center

  );
}

Widget buildText1({required String text,TextDecoration? decoration,String? fontFamily,double? size,Color? color}){
  return Text(
      text,
      style: TextStyle(
        fontFamily: fontFamily ?? FontFamily.josefinRegular,
        fontSize: size ?? 14,
        color: color ?? CustomColors.bluearrowcolor,
        decoration: decoration ?? TextDecoration.none,
      )

  );
}

Widget buildTextWithLine({required String text,TextOverflow? overflow,int? maxLines,TextDecoration? decoration,String? fontFamily,double? size,Color? color}){
  return Text(
      text,maxLines: maxLines ?? 1,
      overflow: overflow ?? TextOverflow.ellipsis,
      style: TextStyle(
        fontFamily: fontFamily ?? FontFamily.josefinRegular,
        fontSize: size ?? 14,
        color: color ?? CustomColors.bluearrowcolor,
        decoration: decoration ?? TextDecoration.none,
      )

  );
}

Widget buildText2({TextAlign? textAlign,required String text,TextDecoration? decoration,String? fontFamily,double? size,Color? color}){
  return Text(
      text,
      style: TextStyle(
        fontFamily: fontFamily ?? FontFamily.josefinRegular,
        fontSize: size ?? 14,
        color: color ?? CustomColors.bluearrowcolor,
        decoration: decoration ?? TextDecoration.none,
      ),textAlign: textAlign ?? TextAlign.center,

  );
}

Widget buildTextWithHeight({double? height,TextAlign? textAlign,required String text,TextDecoration? decoration,String? fontFamily,double? size,Color? color}){
  return Text(
      text,
      style: TextStyle(
        fontFamily: fontFamily ?? FontFamily.josefinRegular,
        fontSize: size ?? 14,
        height: height ?? 0,
        color: color ?? CustomColors.bluearrowcolor,
        decoration: decoration ?? TextDecoration.none,
      ),textAlign: textAlign ?? TextAlign.left,

  );
}




Widget buildHeading({required String text,double? size,int? maxLines,double? lineHeight,Color? color}){
  return Text(
    text,
    style: TextStyle(
        fontFamily: FontFamily.josefinRegular,
        fontSize: size ?? 16,
        height: lineHeight,
        color: color
    ),
  );
}

Widget buildHeadingBold({required String text,double? size,int? maxLines,double? lineHeight,Color? color,TextStyle? style}){
  return Text(
    text,
    style: style ?? TextStyle(
      fontFamily: FontFamily.josefinBold,
      fontSize: size ?? 16,
      height: lineHeight,
    ),
  );
}
Widget buildHeadingBoldCutPrice({required String text,double? size,int? maxLines,double? lineHeight,Color? color,TextStyle? style}){
  return Text(
    text,
    style: style ?? TextStyle(
      fontFamily: FontFamily.josefinBold,
      fontSize: size ?? 16,
      height: lineHeight,color: CustomColors.greyColor,
        decoration: TextDecoration.lineThrough
    ),
  );
}


Widget buildTextCommon({required String text,double? size,int? maxLines,double? lineHeight,Color? color,TextStyle? style}){
  return Text(
    text,
    maxLines: maxLines,
    style: TextStyle(
        fontFamily: FontFamily.josefinRegular,
        fontSize: size ?? 16,
        color: color ?? CustomColors.greyColorDark,
        height: lineHeight,
        overflow: TextOverflow.ellipsis
    ),
  );
}

Widget buildTextNotification({required String text,}){
  return Text(
    text,
    textAlign: TextAlign.start,
    style: TextStyle(
      fontFamily: FontFamily.josefinRegular,
      fontSize: 16,
      color: CustomColors.greyColorDark,            
    ),

  );
}