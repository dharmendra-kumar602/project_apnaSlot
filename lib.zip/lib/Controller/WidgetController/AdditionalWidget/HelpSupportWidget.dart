

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../Helper/ColoController/CustomColors.dart';
import 'AdditionalWidget.dart';

class HelpAndSupportWidget{
  static Widget contactWidget({required onTap,required String iconImage,required String title}){
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: CustomColors.bluearrowcolor,
            ),
            child: Center(
              child: Image.asset(iconImage),
            ),
          ),
          buildSizeBox(0.0, 10.0),
          buildText1(text: title,color: CustomColors.greyColor,size: 16),

          // InkWell(
          //     onTap: (){
          //       _makePhoneCall(phoneNumber: '+91 2365478952');
          //     },
          //     child: buildText1(text: '+91 2365478952',size: 2.5,)
          // )

        ],
      ),
    );
  }
}