import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:sizer/sizer.dart';

class CustomRattingBar extends StatelessWidget {
  double? stars;
  double? size;
  bool? ignoreGesture;
  Function(double) onRatingUpdate;

  CustomRattingBar({super.key,required this.onRatingUpdate,this.stars, this.size, this.ignoreGesture});

  @override
  Widget build(BuildContext context) {
    return RatingBar.builder(
      initialRating: stars ?? 0.0,
      glow: false,
      minRating: 1,
      direction: Axis.horizontal,
      allowHalfRating: false,
      itemCount: 5,
      ignoreGestures: ignoreGesture ?? false,
      itemSize: size ?? 5.w,
      itemPadding: const EdgeInsets.symmetric(horizontal: 0),
      itemBuilder: (context, _) => Icon(
        Icons.star,
        color: const Color.fromRGBO(238, 212, 43, 1),
        size: size ?? 3.w,
      ),
      onRatingUpdate: onRatingUpdate,
      // onRatingUpdate: (rating) {
      //   print(rating);
      // },
    );

    //   Row(
    //   children: List<Widget>.generate(5, (index) {
    //     if(stars != null){
    //       if(index <= stars! - 1){
    //         return Icon(Icons.star,color: const Color.fromRGBO(238, 212, 43, 1),size: size ?? 4.w,);
    //       }else{
    //         return Icon(Icons.star,color: Color.fromRGBO(245, 245, 245, 1),size: size ?? 4.w,);
    //       }
    //     } else{
    //       return Icon(Icons.star,color: Color.fromRGBO(245, 245, 245, 1),size: size ?? 4.w,);
    //     }
    //   } ),
    // );
  }
}
