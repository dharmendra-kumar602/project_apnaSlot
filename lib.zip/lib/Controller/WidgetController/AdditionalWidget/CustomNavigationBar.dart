import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'AdditionalWidget.dart';


class CustomBottomNavigationBar extends StatefulWidget {
  _CustomBottomNavigationBarState createState() => _CustomBottomNavigationBarState();
}

class _CustomBottomNavigationBarState extends State<CustomBottomNavigationBar> {
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      elevation: 50,
      child: Container(
          width: 100.w,
          height: 10.h,

          decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 10.0,
                offset: Offset(0.0, 10.0),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Container(
                      width: 50,
                      height: 5.h,

                      child: Center(
                        child: SvgPicture.asset('assets/icons/homeselected.svg',),
                      ),
                    ),
                    buildTextCommon(text: 'Home')

                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15.w),
                  child: Column(


                    children: [
                      GestureDetector(
                        onTap:(){
                          // Navigator.pushNamed(context, AppRoutes.notificationPage);
                        },
                        child: Container(
                          width: 50,
                          height: 5.h,
                          // color: Colors.pink,
                          child: Center(
                            child: SvgPicture.asset('assets/icons/bellunselected.svg',),
                          ),
                        ),
                      ),
                      buildTextCommon(text: 'Alert')

                    ],
                  ),
                ),

                Column(
                  children: [
                    Container(
                      width: 50,
                      height: 5.h,
                      // color: Colors.pink,
                      child: Center(
                        child: SvgPicture.asset('assets/icons/fileunselected.svg',),
                      ),
                    ),
                    buildTextCommon(text: 'History')

                  ],
                )
              ],
            ),
          )

      ),
    );


  }

}