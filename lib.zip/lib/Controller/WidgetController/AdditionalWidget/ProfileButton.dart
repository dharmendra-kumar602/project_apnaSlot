
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import '../../Helper/ColoController/CustomColors.dart';
import 'AdditionalWidget.dart';

class ProfileButton{

  static Widget button({required onTap,required String svgName,required String title}){
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 40,left: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              // padding: const EdgeInsets.all(5),
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: CustomColors.bluearrowcolor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(5),
              ),
              child: Center(
                child: SvgPicture.asset(
                  svgName,color: CustomColors.bluearrowcolor,
                ),
              ),
            ),
            buildSizeBox(0.0, 10.0),
            Column(
              children: [
                buildHeading(
                  text: title,
                  size: 18,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  static Widget raiseQueryButton({required onTap,required String svgName,required String title}){
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 40,left: 15),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              // padding: const EdgeInsets.all(5),
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: CustomColors.bluearrowcolor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(5),
              ),
              child: Center(
                child: SvgPicture.asset(
                  svgName,
                ),
              ),
            ),
            buildSizeBox(0.0, 10.0),
            Column(
              children: [
                buildHeading(
                  text: title,
                  size: 18,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}