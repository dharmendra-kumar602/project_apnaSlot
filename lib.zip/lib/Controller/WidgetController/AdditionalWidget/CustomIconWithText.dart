import 'package:apna_slot/Controller/Helper/TextController/FontFamily/FontFamily.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';

import '../../Helper/ColoController/CustomColors.dart';

class CustomIconWithText extends StatelessWidget {
  String icon;
  String text;
  bool? isSvg = true;
  double? width;

  CustomIconWithText(
      {super.key,
        required this.text,
        required this.icon,
        this.isSvg,
        this.width = 20});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Image.asset(icon),
        isSvg == true
            ? SvgPicture.asset(
          icon,
        )
            : Image.network(icon, width: width),

        SizedBox(
          width: 1.w,
        ),
        Text(text,
            style: TextStyle(
                fontFamily: FontFamily.josefinRegular,
                fontSize: 12,
                color: const Color.fromRGBO(139, 139, 139, 1)))
      ],
    );
  }
}
