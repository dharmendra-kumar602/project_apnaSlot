import 'package:apna_slot/Controller/Helper/ColoController/CustomColors.dart';
import 'package:flutter/material.dart';
import 'AdditionalWidget.dart';

class CustomCheckBoxWithText extends StatefulWidget {
  final bool? value;
  final String label;
  final bool leadingCheckbox;
  final double? radius;
  final double? height;
  final double? width;
  final double? space;
  final ValueChanged<bool?>? onChanged;

  CustomCheckBoxWithText({
    Key? key,
    required this.value,
    this.onChanged,
    required this.label,
    this.leadingCheckbox = true,
    this.radius,
    this.height,
    this.width,
    this.space
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CustomCheckBoxWithTextState();
}

class _CustomCheckBoxWithTextState extends State<CustomCheckBoxWithText> {
  var value = false;

  @override
  void initState() {
    super.initState();
    value = widget.value == true;
  }

  @override
  Widget build(BuildContext context) {
    var widgets = <Widget>[
      _buildCheckbox(context),
    ];
    if (widget.label.isNotEmpty) {
      if (widget.leadingCheckbox) {
        widgets.add(SizedBox(width: widget.space ?? 3,));
        widgets.add(_buildLabel(context));

      } else {
        widgets.insert(0, _buildLabel(context));

      }
    }
    return SizedBox(
      // height: widget.height ?? 4.h,
      height: 20,
      child: InkWell(
        borderRadius: BorderRadius.circular(4),
        onTap: () => _onCheckedChanged(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          // mainAxisSize: MainAxisSize.min,
          children: widgets,
        ),
      ),
    );

  }

  Widget _buildCheckbox(BuildContext context) {
    return
      Container(
          margin: const EdgeInsets.all(1),
          color: Colors.transparent,
          // width: widget.width ?? 10.w,
          width: 20,
          child: Theme(
            data: ThemeData(
              // unselectedWidgetColor: AppColors.darkblueprofile,
            ),
            child: Checkbox(
              fillColor: MaterialStateProperty.all(CustomColors.bluearrowcolor),
              overlayColor: MaterialStateProperty.all<Color>(Colors.transparent),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(widget.radius ?? 4),

              ),
              checkColor: Colors.white,
              activeColor: CustomColors.bluearrowcolor,
              value: value,
              onChanged: (v) => _onCheckedChanged(),
              side: BorderSide(
                color: CustomColors.bluearrowcolor,
              ),
            ),
          )
      );


  }

  Widget _buildLabel(BuildContext context) {
    // var padding =
    // widget.leadingCheckbox ? EdgeInsets.only(right: widget.rightPadding ?? 8) :  EdgeInsets.only(left: widget.leftPadding ?? 8);

    return Padding(
      padding: EdgeInsets.zero,
      child: buildTextCommon(text: widget.label,size: 14,),
    );
  }

  void _onCheckedChanged() {
    setState(() {
      value = !value;
    });
    if (widget.onChanged != null) {
      widget.onChanged!.call(value);
    }
  }
}


class CheckBoxCustomWithText{
  static Widget box({required bool isSelected,required String text}){
    return Row(
      children: [
      Container(
        height: 20,
        width: 20,
        margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
          border: Border.all(width: 1,color: CustomColors.bluearrowcolor),
          borderRadius: BorderRadius.circular(4),
          color: isSelected ? CustomColors.bluearrowcolor:CustomColors.transparentColor
        ),
        child: Center(
          child: Visibility(
            visible: isSelected,
              child: FittedBox(
                  child: Icon(Icons.check,color: CustomColors.whiteColor,)
              )
          ),
        ),
      ),
        buildText1(text: text,color: CustomColors.greyColor)
      ],
    );
  }
}