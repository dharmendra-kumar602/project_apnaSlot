import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CustomCarouserSlider extends StatefulWidget {
  double? height = 30.h;
  CustomCarouserSlider({super.key,this.height});
  _CustomCarouserSliderState createState() => _CustomCarouserSliderState();
}

class _CustomCarouserSliderState extends State<CustomCarouserSlider> {

  int _current = 0;
  final CarouselController _controller = CarouselController();

  final List<String> _images = ['assets/images/library.jpeg','assets/images/library1.jpg','assets/images/library2.jpg'];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CarouselSlider(
          items: List.generate(_images.length, (index) => Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(_images[index]),
                fit: BoxFit.cover,
              ),
            ),
          ),
          ),
          options: CarouselOptions(
              height: widget.height,
              enlargeCenterPage: true,
              autoPlay: true,
              // disableCenter: false,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.fastOutSlowIn,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: Duration(milliseconds: 200),
              viewportFraction: 1,
              onPageChanged: (index, reason) {
                setState(() {
                  _current = index;
                });
              }
          ),
        ),
        Positioned(
            left: 10,
            right: 10,
            bottom: 10,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: _images.asMap().entries.map((entry) {
                return GestureDetector(
                    onTap: () => _controller.animateToPage(entry.key),
                    child: Container(
                      width: 3.w,
                      height: 3.w,
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _current == entry.key ? Color.fromRGBO(74, 0, 224, 1) : Colors.white,
                      ),
                    ));
              }).toList(),
            ))
      ],
    );

  }

}