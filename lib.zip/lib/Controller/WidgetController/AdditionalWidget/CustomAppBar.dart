import 'package:apna_slot/Controller/WidgetController/StringDefine/StringDefine.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../../Helper/TextController/FontFamily/FontFamily.dart';

class CustomAppBar{

  static AppBar appBar({bool? showBackBtn,Color? backgroundColor,bool? centerTitle,double? elevation,double? leadingWidth,String? title, Color? titleColor,double? fontSize,required onTap, Color? leadingColor}){
    return AppBar(
      toolbarHeight: 55,
      title: Text(title ?? '',style: TextStyle(color: titleColor ?? Colors.black,fontSize: fontSize ?? 20, fontFamily: FontFamily.josefinRegular)),
      leading:
          Visibility(
            visible: showBackBtn ?? true,
            child: InkWell(
              onTap: onTap,
              child: Container(
                  alignment: Alignment.center,
                  width: 40,

                  child: SvgPicture.asset(strSvgBackArrow,color: leadingColor ?? Colors.black,width: 20,)
              ),
            ),
          ),


      leadingWidth: leadingWidth ?? 50,
      elevation: elevation ?? 0,
      centerTitle: centerTitle ?? false,
      backgroundColor: backgroundColor ?? Colors.white,
    );
  }
}

// class CustomAppBar extends StatefulWidget {
//   String? title;
//   double? leadingWidth;
//   double? elevation;
//   bool? centerTitle;
//   Color? backgroundColor;
//   Color? titleColor;
//   Color? leadingColor;
//   Function()? onTap;
//   CustomAppBar({super.key,required this.onTap,this.title,this.backgroundColor,this.centerTitle,this.elevation,this.leadingWidth,this.titleColor,this.leadingColor});
//
//   _CustomAppBarState createState () => _CustomAppBarState();
// }
//
// class _CustomAppBarState extends State<CustomAppBar> {
//   @override
//   Widget build(BuildContext context) {
//     return AppBar(
//       title: Text(widget.title ?? 'title',style: TextStyle(color: widget.titleColor ?? Colors.black,fontSize: 20, fontFamily: FontFamily.josefinRegular),),
//       leading: Row(
//         children: [
//           SizedBox(
//             width: 20,
//           ),
//           InkWell(
//             onTap: widget.onTap,
//             child: SvgPicture.asset(strSvgBackArrow,color: widget.leadingColor ?? Colors.black,width: 20,),
//           ),
//         ],
//       ),
//
//       leadingWidth: widget.leadingWidth ?? 50,
//       elevation: widget.elevation ?? 0,
//       centerTitle: widget.centerTitle ?? false,
//       backgroundColor: widget.backgroundColor ?? Colors.white,
//     );
//
//   }
//
// }