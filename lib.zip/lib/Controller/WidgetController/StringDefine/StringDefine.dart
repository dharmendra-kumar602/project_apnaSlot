
const String kLoginDes = "Finding a perfect library and a suitable seat can be difficult these days. And who wants to hustle to get into your desired library? Don't worry; we have something for all the students and booklovers, Apnaslot!";
const String kSignUpDes = "Finding a perfect library and a suitable seat can be difficult these days. And who wants to hustle to get into your desired library? Don't worry; we have something for all the students and booklovers, Apnaslot!";
const String kVerifyOtpDes = "Finding a perfect library and a suitable seat can be difficult these days. And who wants to hustle to get into your desired library? Don't worry; we have something for all the students and booklovers, Apnaslot!";
const String kMyQrCodeDes = "Lorem ipsum dolor sit amet, sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores";

// gif
const String str_gifSplash = "assets/logo/logo_gif.gif";
const String strAppShareLink = "https://play.google.com/store/games";

//Svg
const String strSvgEmptyData = 'assets/svg/empty_data.svg';
const String strSvgErrorData = 'assets/svg/error.svg';
const String strSvgBackArrow = 'assets/svg/back.svg';
const String strSvgSearch = 'assets/svg/search.svg';
const String strSvgFilter = 'assets/svg/filter.svg';
const String strSvgUser = 'assets/svg/user.svg';
const String strSvgQrCode = 'assets/svg/qr.svg';
const String strSvgBell = 'assets/svg/bell_icon.svg';
const String strSvgEarth = 'assets/svg/earth.svg';
const String strSvgTermAndCondition = 'assets/svg/terms_and_conditions.svg';
const String strSvgBook = 'assets/svg/book.svg';
const String strSvgBookReader = 'assets/svg/bookreader.svg';
const String strSvgCamera = 'assets/svg/camera.svg';
const String strSvgChair = 'assets/svg/chair.svg';
const String strSvgEditProfile = 'assets/svg/editprofile_icon.svg';
const String strSvgEmail = 'assets/svg/email.svg';
const String strSvgArrowLeft = 'assets/svg/arrow_left.svg';
const String strSvgForward = 'assets/svg/forward.svg';
const String strSvgHelp = 'assets/svg/help_icon.svg';
const String strSvgBell2 = 'assets/svg/bell_2.svg';
const String strSvgLocationOn = 'assets/svg/location_on.svg';
const String strSvgLogout = 'assets/svg/logout_icon.svg';
const String strSvgMinus = 'assets/svg/minus.svg';
const String strSvgPlus = 'assets/svg/plus.svg';
const String strSvgCardPayment = 'assets/svg/mobile_card_payment.svg';
const String strSvgNavigation = 'assets/svg/navigate.svg';
const String strSvgNotebook = 'assets/svg/notbook.svg';
const String strSvgPen = 'assets/svg/pen.svg';
const String strSvgPhone = 'assets/svg/phone.svg';
const String strSvgShare = 'assets/svg/share_icon.svg';
const String strSvgWifi = 'assets/svg/wifi.svg';
const String strSvgPaymentFailed = 'assets/svg/payment_failed.svg';
const String strSvgPaymentSuccess = 'assets/svg/payment_success.svg';

//Image
const String str_imgSvgSplashScreen1 = 'assets/images/svg_splash1.png';
const String str_imgIntro1 = "assets/images/intro1.png";
const String str_imgIntro2 = "assets/images/intro2.png";
const String str_imgLoginBg = "assets/images/welcome.png";
const String str_imgDefaultBg = "assets/images/place_holder.png";
const String str_imgHelpAndSupport = "assets/images/help.png";
const String strImgPhoneWhite = "assets/images/phone_white.png";
const String strImgEmailWhite = "assets/images/email.png";
const String strImgLogout = "assets/images/logout.png";
const String strImgMapMarker1 = "assets/images/marker1.png";
const String strImgMapMarker2 = "assets/images/marker2.png";

const String strImgChairBottom = "assets/images/bottomchair.png";
const String strImgChairTop = "assets/images/topchair.png";
const String strImgChairRight = "assets/images/rightchair.png";
const String strImgChairLeft = "assets/images/leftchair.png";
const String strImgChairBottomGreen = "assets/images/bottomchairgreen.png";
const String strImgChairTopGreen = "assets/images/topchairgreen.png";
const String strImgChairRightGreen = "assets/images/rightchairgreen.png";
const String strImgChairLeftGreen = "assets/images/leftchairgreen.png";

/// Help & Support
const String kHelpSupportContactNumber = "+91 2365478952";
const String kHelpSupportContactEmail = "support@apnaslot.com";
const double kDefaultLat = 26.8752545;
const double kDefaultLng = 75.7628039;
// Splash
const String kSplashScreenTitle = "Book your space";

// Common String
const String kEmail = "Email";
const String kMobileNumber = "Mobile number";
const String kName = "Name";
const String kSubmit = "Submit";
const String kAddReview = "Add Review";
const String kEditReview = "Edit Review";
const String kLogin = "Login";
const String kSkip = "Skip";
const String kRetry = "Retry";
const String kBack = "Back";
const String kEmptyData = "Empty";
const String kError = "Something went wrong";
const String kNoInternet = "No internet connection";
const String kFilters = "Filters";
const String kSearchArea = "Search area";
const String kSearch = "Search...";
const String kDistance = "Distance type";
const String kRange = "Range";
const String kRenewSub = "Renew Subscription";
const String kApply = "Apply";
const String kReset = "Reset";
const String kGoBack = "Go Back";
const String kSuccess = "Success";
const String kProfile = "Profile";
const String kCompleteBookingTitle = "Enter student details";
const String kPrice = "Price : ";
const String kAmount = "Amount : ";
const String kBookingNumber = "Booking number : ";
const String fPrice = "Price";
const String kAddress = "Address";
const String kRenewSubscription = "Renew Subscription";
const String kTimeSlot = "Time Slot : ";
const String kSeatNum = "Seat No : ";
const String kFloorNum = "Floor No : ";
const String kExpiryDate = "Expiry Date : ";
const String kUpdate = "Update";
const String kCompleteBooking = "Complete Booking";
const String kGallery = "Gallery";
const String kCamera = "Camera";
const String kReview = "Review";
const String kPayment = "Payment";
const String kStar = "Star : ";
const String kComment = "Comment...";
const String kNotifications = "Notifications";
const String kMyBooking  = "My Booking";
const String kMyQRCode  = "My QR Code";
const String kMyDetails  = "My Details";
const String kBookingDetails  = "Booking Details";
const String kMyQrCode  = "My Qr Code";
const String kOk  = "OK";
const String kYes  = "Yes";
const String kNo  = "No";
const String kWriteReview  = "Write a Review";
const String kUpdateReview  = "Update Review";
const String kNotAuthenticated  = "Not Authenticated";
const String kAuthenticatedDes  = "Someone trying to login in another device so you logout form here!";
const String kQueryDes  = "Thank you for submitting your request we will get in touch with you shortly.";
const String kAreYouSureWantToLogout  = "Are you sure want to logout!";
const String kApplyCoupon  = "Apply Coupon";
const String kFailed  = "Failed";





// Validation string
const String kEnterName = "Enter your name";
const String kEnterAadhaar = "Enter your aadhaar number";
const String kEnterValidAadhaar = "Enter valid aadhaar number";
const String kEnterCity = "Enter your city";
const String kEnterMobileNo = "Enter mobile number";
const String kEnterValidMobileNo = "Enter 10 digit Mobile Number";
const String kEnterEmail = "Enter your email";
const String kEnterValidEmail = "Enter valid email";
const String kEnterAddress = "Enter address";

// Login
const String kLoginTitle = "Welcome";
const String kLoginBtnTitle = "Login";
const String kLoginNotMember  = "Not a member? ";
const String kLoginSignUpNow  = "SignUp now";
const String kLoginRegisterNow  = "Register now";
const String kLoginMob = "Mobile Number";
const String kAadhaar = "Aadhaar Number";
const String kCity = "City";
const String kCheckTerm = "Please check term and conditions";

// SignUp
const String kSignUpTitle = "SignUp";
const String kRegisterTitle = "Register";
const String kSignUpName = "Full Name";
const String kSignUpIAgree  = "I Agree ";
const String kSignUpTNC  = "T&C";
const String kSignUpAlready = "Already have an account? ";

// Verify otp
const String kVerifyOtpTitle = "Verify Mobile OTP";
const String kVerifyOtpDoNotCode = "Didn't you receive any code ?";
const String kVerifyOtpResend  = "Resend New CODE";
const String kVerifyOtpOtpReceive  = "Resend OTP in ";
const String kSeconds = " seconds";

// Dashboard
const String kHome = "Home";
const String kAlert = "Alert";
const String kHistory = "History";


// Query
const String kAskQuery = "Ask Query";
const String kSelectedQuery = "Selected Query Reason";
const String kSelectQuery = "Select Query Reason";
const String kSelectedBookingNo = "Selected Booking Number";
const String kSelectBookingNo = "Select Booking Number";
const String kContactInfo = "Contact Info :";

// Profile
const String kEditProfile = "Edit Profile";
const String kHelpAndSupport = "Help & Support";
const String kPrivacyStatement = "Privacy Statement";
const String kTermsAndConditions = "Terms and Conditions";
const String kShareApp = "Share App";
const String kLogOut = "Log Out";


//Home
const String kOpenHour = "Opening hour : ";
const String kFacility = "Facility : ";
const String kBookNow = "Book now";
const String kInvoice = "Invoice";
const String kViewDetail = "View Detail";

//Search
const String kSearchLibraries = "Search Libraries";

//My Qr code

// Seat arrangement
const String kBookingDate = "Booking Date : ";
const String kWhereDoYouSit = "Where do you want to sit?";
const String kUnavailable = "Unavailable";
const String kAvailable = "Available";
const String kSelected = "Selected";
const String kSeatArrangement = "Seat Arrangement";
const String kSeat = "Seat";

// Details
const String kDetails = "Details";
const String kDirection = "Direction";
const String kFacilities = "Facilities";
const String kSubscriptionType = "Subscription Type";
const String kMore = "More...";

// Schedule screen
const String kSchedule = "Schedule";
const String kProceedToBookNow = "Proceed to Book Now";



// Intro
const String introTitle = "Heading";
const String introDescription = "Lorem ipsum dolor sit amet, consetetur sadipsing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna";
const String introTitle2 = "Heading2";
const String introDescription2 = "Lorem ipsum dolor sit amet, consetetur sadipsing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna";

const String appName = "ApnaSlot";
const String networkErrorText = "Please check network connection and try again!";
const String errorText = "Something went wrong";



// Toast string
const String networkToastString = "Please check network connection and try again!";
const String kStoragePermissionToast = "Go to Mobile setting or give access the storage permission";
const String kQueryToastString = "Please mention your query";
const String kQueryReasonString = "Please choose query reason";
const String kFilterToastString = "Please select any option";
const String kReviewToastString = "Please enter your comment";
const String kChoosePlanToastString = "Please choose plan";
const String kNoAnyPlanToastString = "Not available plan";
const String kChooseYourSheet = "Choose your seat";
const String kAlreadyBookedSeat = "This seat already booked";
const String kSeatNotAvailable = "This seat not available";
const String kUpdatePictureToastMsg = "Please update your picture";
const String kUpdateYourAadharImage = "Please update your aadhar image";
const String kPleaseSelectBookingNo = "Please select booking number";



//Un-Use Svg
const String strSvgSplashLogo = 'assets/svg/svg_logo.svg';
const String strSvgSplash = 'assets/svg/svg_splash.svg';
const String strSvgLoginBg = 'assets/svg/svg_login.svg';
const String strSvgIntro1 = 'assets/svg/intro1.svg';
const String strSvgIntro2 = 'assets/svg/intro2.svg';
const String strSvgHistoryUnSelected = 'assets/svg/history_unselected.svg';
const String strSvgHistorySelected = 'assets/svg/history_selected.svg';
const String strSvgBookingSeleted = 'assets/svg/booking_selected.svg';
const String strSvgBookingUnselected = 'assets/svg/booking_unselected.svg';

// const String str_Svg10 = 'assets/svg/Icon_Arrow-Right.svg';

//Image Path
const String str_svgForward = "assets/svg/forward.svg";


//Image Path
const String strImgSplashScreen = "assets/images/img_splash.jpeg";
const String strImgSplashgif = "assets/images/apnaslot.gif";
const String strGif = "assets/images/apnaslot.gif";

// gif


