import 'package:apna_slot/Controller/Helper/PrintLog/PrintLog.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/AdditionalWidget.dart';
import 'package:apna_slot/Controller/WidgetController/AdditionalWidget/CustomeRattingBar.dart';
import 'package:delayed_display/delayed_display.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import '../../../View/LibraryBooking/CompleteBooking/CompleteBookingScreen.dart';
import '../../../View/Privacy/PrivacyContentScreen.dart';
import '../../Helper/ColoController/CustomColors.dart';
import '../../Helper/Shared Preferences/SharedPreferences.dart';
import '../../Helper/TextController/FontFamily/FontFamily.dart';
import '../../RouteController/RouteNames.dart';
import '../Button/ButtonCustom.dart';
import '../StringDefine/StringDefine.dart';
import '../TextField/CustomTextField.dart';


class PopupCustom{

  static logoutPopUP({required BuildContext context}){
    return showDialog(
        context: context,
        builder: (_){
          return WillPopScope(
              onWillPop: () async => false,
              child: const LogoutPopUP()
          );
        }
    );
  }

  static userLogoutPopUP({required BuildContext context}){
    return showDialog(barrierDismissible: true,
        context: context,
        builder: (_){
          return const UserLogoutPopUP();
        }
    ).then((value) {
      PrintLog.printLog("Value is: $value");
      if(value == true){
        AppSharedPreferences.clearSharedPref().then((value) {
          Get.offAllNamed(loginScreenRoute);
        });
      }
    });
  }

  static submitQueryPopUP({required BuildContext context,required String title,required String description}){
    return showDialog(
        context: context,
        builder: (_){
          return SubmitQueryPopUP(title: title,description:description);
        }
    );
  }

  static termAndConditionPopUP({required BuildContext context,required String type}){
    return showDialog(
        context: context,
        builder: (_){
          return PrivacyAndTermsScreen(type: type);
        }
    );
  }


  static seatNotAvailablePopUP({ required Function(dynamic) onValue,required BuildContext context,required Function()? onTap,required String message}){
    return showDialog(
      context: context,
      builder: (_) {
        return SeatNotAvailablePopUP(onTap: onTap,message: message,);
      },).then(onValue);
  }

  static addReviewPopUp({ required Function(dynamic) onValue,required BuildContext context,TextEditingController? reviewController,Function()? onTap,double? stars,required Function(double) onRatingUpdate,required String btnTitle}){
    return showDialog(
      context: context, 
      builder: (_) {
        return AddReviewPopUP(onTap: onTap,reviewController: reviewController,stars: stars,onRatingUpdate: onRatingUpdate,btnTitle: btnTitle,);
      },).then(onValue);
  }

  // static editReviewPopUp({ required Function(dynamic) onValue,required BuildContext context,TextEditingController? reviewController,Function()? onTap,double? stars,required Function(double) onRatingUpdate,}){
  //   return showDialog(
  //     context: context,
  //     builder: (_) {
  //       return EditReviewPopUP(onTap: onTap,reviewController: reviewController,stars: stars,onRatingUpdate: onRatingUpdate);
  //     },).then(onValue);
  // }

  static showCompleteBookingPopUP({required BuildContext context,required String bookingNumber}){
    return showDialog(
        context: context,
        builder: (_){
          return WillPopScope(
              onWillPop: () async => false,
              child: CompleteBookingScreen(bookingNumber: bookingNumber,)
          );
        }
    );
  }
}





class LogoutPopUP extends StatelessWidget {
  const LogoutPopUP({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              // height: 280,
              decoration: BoxDecoration(
                  color: CustomColors.whiteColor,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 110,
                    width: 110,
                    margin: const EdgeInsets.only(top: 10),
                    child: Image.asset(strImgLogout),
                  ),
                  buildText1(text: kNotAuthenticated,size: 25,fontFamily: FontFamily.josefinBold),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Wrap(
                        alignment: WrapAlignment.center,
                        children: [
                          buildText2(text: kAuthenticatedDes,color: CustomColors.greyColor,size: 16),
                        ]
                    ),
                  ),
                  buildSizeBox(20.0, 0.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: InkWell(
                      onTap: () async {
                        AppSharedPreferences.clearSharedPref().then((value) {
                          Get.offAllNamed(loginScreenRoute);
                        });
                      },
                      child: Container(
                        height: 45,
                        width: 120,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: CustomColors.redColor,
                        ),
                        child: Center(
                          child: buildText1(text: kOk,color: CustomColors.whiteColor,size: 20.0,fontFamily: FontFamily.josefinBold),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class UserLogoutPopUP extends StatelessWidget {
  const UserLogoutPopUP({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              // height: 280,
              decoration: BoxDecoration(
                  color: CustomColors.whiteColor,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 110,
                    width: 110,
                    margin: const EdgeInsets.only(top: 10),
                    child: Image.asset(strImgLogout),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20,right: 20),
                    child: buildText2(text: kAreYouSureWantToLogout,size: 25,fontFamily: FontFamily.josefinBold),
                  ),

                  buildSizeBox(20.0, 0.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: InkWell(
                          onTap: () async {
                            Navigator.of(context).pop(false);
                          },
                          child: Container(
                            height: 45,
                            width: 120,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              color: CustomColors.bluearrowcolor,
                            ),
                            child: Center(
                              child: buildText1(text: kNo,color: CustomColors.whiteColor,size: 20.0,fontFamily: FontFamily.josefinBold),
                            ),
                          ),
                        ),
                      ),
                      buildSizeBox(0.0, 20.0),

                      Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: InkWell(
                          onTap: () async {
                            Navigator.of(context).pop(true);
                            // AppSharedPreferences.clearSharedPref().then((value) {
                            //   Get.offAllNamed(loginScreenRoute);
                            // });
                          },
                          child: Container(
                            height: 45,
                            width: 120,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              color: CustomColors.bluearrowcolor,
                            ),
                            child: Center(
                              child: buildText1(text: kYes,color: CustomColors.whiteColor,size: 20.0,fontFamily: FontFamily.josefinBold),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SubmitQueryPopUP extends StatelessWidget {
  String title;
  String description;
SubmitQueryPopUP({Key? key,required this.title,required this.description}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              decoration: BoxDecoration(
                  color: CustomColors.whiteColor,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 20,bottom: 10),
                    width: Get.width * 30/100,
                    height: Get.width * 30/100,
                    child: const CircleAvatar(
                      backgroundImage: AssetImage(str_imgHelpAndSupport),
                    ),
                  ),
                  buildText2(text: title ,size: 25,fontFamily: FontFamily.josefinBold),
                  buildSizeBox(10.0, 0.0),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Wrap(
                        alignment: WrapAlignment.center,
                        children: [
                          buildText2(text: description,color: CustomColors.greyColor,size: 16),
                        ]
                    ),
                  ),
                  buildSizeBox(20.0, 0.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: InkWell(
                      onTap: () async {
                        Navigator.of(context).pop(true);
                      },
                      child: Container(
                        height: 45,
                        width: 120,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: CustomColors.bluearrowcolor,
                        ),
                        child: Center(
                          child: buildText1(text: kOk,color: CustomColors.whiteColor,size: 20.0,fontFamily: FontFamily.josefinBold),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AddReviewPopUP extends StatelessWidget { 
  final TextEditingController? reviewController;
  void Function()? onTap;
  double? stars;
  String btnTitle;
  Function(double) onRatingUpdate;
  AddReviewPopUP({Key? key,required this.btnTitle,required this.onRatingUpdate,this.stars,this.onTap,this.reviewController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height*0.48,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(5),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    offset: Offset(0.0, 10.0),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min, // To make the card compact
                children: <Widget>[

                  Container(
                    height: 60,
                    padding: const EdgeInsets.only(left: 15),
                    decoration: BoxDecoration(
                      color: CustomColors.bluearrowcolor,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(5),
                        topRight: Radius.circular(5),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildTextCommon(text: kReview,color: Colors.white,),
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Container(
                            height: 30,
                            width: 30,
                            margin: const EdgeInsets.only(right: 15),
                            alignment: Alignment.centerRight,
                            child: const Icon(Icons.clear,color: Colors.white),
                          ),
                        )
                      ],
                    ),
                  ),

                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            children: [
                              buildTextCommon(text: kStar,size: 12,),
                              CustomRattingBar(
                                stars: stars,
                                ignoreGesture: false,
                                onRatingUpdate:onRatingUpdate,
                              ),
                            ],
                          ),
                        ),
                        buildSizeBox(20.0, 0.0),

                        CustomTextFieldRaiseQuery(
                          controller: reviewController,
                          textInputAction: TextInputAction.done,
                          keyboardType: TextInputType.text,
                          readOnly: false,
                          autofocus: false,
                          hintText: kComment,
                          maxLine: 4,
                          onTap: (){

                          },
                          onChanged: (value){

                          },
                        ),
                        buildSizeBox(30.0,  0.0),

                        SizedBox(
                          width: Get.width,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: onTap,
                            style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all<Color>(CustomColors.bluearrowcolor),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(90),
                                    )
                                )
                            ),
                            child: buildText1(text: btnTitle,color: CustomColors.whiteColor,size: 18),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class EditReviewPopUP extends StatelessWidget {
  final TextEditingController? reviewController;
  void Function()? onTap;
  double? stars;
  Function(double) onRatingUpdate;
  EditReviewPopUP({Key? key,required this.onRatingUpdate,this.stars,this.onTap,this.reviewController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height*0.48,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(5),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                    offset: Offset(0.0, 10.0),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min, // To make the card compact
                children: <Widget>[
                  Container(
                    height: 60,
                    padding: const EdgeInsets.only(left: 15),
                    decoration: BoxDecoration(
                      color: CustomColors.bluearrowcolor,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(5),
                        topRight: Radius.circular(5),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildTextCommon(text: kReview,color: Colors.white,),
                        InkWell(
                          onTap: (){
                            Get.back();
                          },
                          child: Container(
                            height: 30,
                            width: 30,
                            margin: const EdgeInsets.only(right: 15),
                            alignment: Alignment.centerRight,
                            child: const Icon(Icons.clear,color: Colors.white),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            children: [
                              buildTextCommon(text: kStar,size: 12,),
                              CustomRattingBar(
                                stars: stars,
                                ignoreGesture: false,
                                onRatingUpdate:onRatingUpdate,
                              ),
                            ],
                          ),
                        ),
                        buildSizeBox(20.0, 0.0),

                        CustomTextFieldRaiseQuery(
                          controller: reviewController,
                          textInputAction: TextInputAction.done,
                          keyboardType: TextInputType.text,
                          readOnly: false,
                          autofocus: false,
                          hintText: kComment,
                          maxLine: 4,
                          onTap: (){

                          },
                          onChanged: (value){

                          },
                        ),
                        buildSizeBox(30.0,  0.0),

                        SizedBox(
                          width: Get.width,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: onTap,
                            style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all<Color>(CustomColors.bluearrowcolor),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(90),
                                    )
                                )
                            ),
                            child: buildText1(text: kSubmit,color: CustomColors.whiteColor,size: 18),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SeatNotAvailablePopUP extends StatelessWidget {
  void Function()? onTap;
  String? message;

  SeatNotAvailablePopUP({Key? key,required this.message,this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.blackColor.withOpacity(0.3),
      body: DelayedDisplay(
        child: Dialog(
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5)
                ),
                child: Column(
                  children: [
                    Container(
                        alignment: Alignment.center,
                        color: CustomColors.bluearrowcolor,
                        height: 50,
                        child: buildHeading(text: 'No seats available',color: Colors.white,)
                    ),
                    buildSizeBox(15.0, 0.0),
                    SvgPicture.asset(strSvgChair),
                    buildSizeBox(15.0, 0.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),
                        Container(height: 2,width: 20,color: CustomColors.greyColorDark,),

                      ],
                    ),
                    buildSizeBox(15.0, 0.0),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: buildText2(text:
                      message ?? ""
                          // "For instance, Mr. Jones of BookingWiz.com notes that if you want to fly to Asia on Northwest and there are no seats"
                          ,textAlign: TextAlign.justify,color: CustomColors.greyColor),
                    ),
                    buildSizeBox(20.0, 0.0),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: ButtonCustom(onPress: onTap!, text: 'Continue', buttonWidth: MediaQuery.of(context).size.width, buttonHeight: 40),
                    ),
                    buildSizeBox(20.0, 0.0),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}