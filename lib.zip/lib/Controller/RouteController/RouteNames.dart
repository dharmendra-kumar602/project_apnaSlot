

const String splashScreenRoute = "/";
const String introScreenRoute = "intro_screen";
const String signUpScreenRoute = "signup_screen";
const String verifyOtpScreenRoute = "verify_otp_screen";
const String loginScreenRoute = "login_screen";
const String dashboardScreenRoute = "dashboard_screen";
const String homeScreenRoute = "home_screen";
const String historyScreenRoute = "history_screen";
const String notificationScreenRoute = "notification_screen";
// const String detailScreenRoute = "detail_screen";
const String newDetailScreenRoute = "new_detail_screen";
const String searchScreenRoute = "search_screen";
const String filterScreenRoute = "filter_screen";
const String updateProfileScreenRoute = "update_profile_screen";
const String helpAndSupportScreenRoute = "help_and_support_screen";
// const String libraryBookScheduleScreenRoute = "library_book_schedule_Screen";
const String newLibraryBookScheduleScreenRoute = "new_library_book_schedule_Screen";
const String seatArrangementScreenRoute = "seatArrangement_Screen";
const String reviewScreenRoute = "review_Screen";
const String myDetailScreenRoute = "myDetail_Screen";
const String myQrCodeScreenRoute = "my_qr_code_Screen";
const String paymentStatusRoute = "payment_Screen";
const String pdfViewScreenRoute = "pdf_view_Screen";
const String googleMapScreenRoute = "google_map_Screen";
const String completeBookingScreenRoute = "complete_booking_Screen";
const String couponCodeScreenRoute = "coupon_code_screen";
