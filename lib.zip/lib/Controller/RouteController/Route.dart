import 'package:apna_slot/View/Dashboard/Home/Search/SerachScreen.dart';
import 'package:apna_slot/View/Detail/DetailScreen.dart';
import 'package:apna_slot/View/LibraryBooking/LibrarySheetArrangement/SheetArrangementScreen.dart';
import 'package:apna_slot/View/Profile/MyDetails/MyDetailScreen.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import '../../View/Dashboard/Dashboard/DashboardScreen.dart';
import '../../View/Dashboard/History/HistoryScreen.dart';
import '../../View/Dashboard/Home/Filter/FilterScreen.dart';
import '../../View/Dashboard/Home/HomeScreen/GoogleMapScreen.dart';
import '../../View/Dashboard/Home/HomeScreen/HomeScreen.dart';
import '../../View/Dashboard/Home/Search/SerachScreen.dart';
import '../../View/Dashboard/Notification/NotificationScreen.dart';
import '../../View/Detail/NewDetailsScreen.dart';
import '../../View/LibraryBooking/CompleteBooking/CompleteBookingScreen.dart';
import '../../View/LibraryBooking/LibraryBookShedual/LibraryBookScheduleScreen.dart';
import '../../View/LibraryBooking/LibraryBookShedual/NewLibraryBookScheduleScreen.dart';
import '../../View/LibraryBooking/coupon_code/coupon_code_screen.dart';
import '../../View/Onboarding/Intro/IntroScreen.dart';
import '../../View/Onboarding/Login/LoginScreen.dart';
import '../../View/Onboarding/SignUp/SignUpScreen.dart';
import '../../View/Onboarding/Splash/SplashScreen.dart';
import '../../View/Onboarding/VerifyOTP/VerifyOtpScreen.dart';
import '../../View/Profile/Help&Support/HelpAndSupportScreen.dart';
import '../../View/Profile/MyQrCode/MyQrCodeScreen.dart';
import '../../View/Profile/UpdateProfile/UpdateProfileScreen.dart';
import '../../View/Review/ReviewScreen.dart';
import '../CashFree/PaymentStatus.dart';
import '../Helper/PdfViewer/PdfView.dart';
import 'RouteNames.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case splashScreenRoute:
      return MaterialPageRoute(builder: (context) => const SplashScreen());

    case introScreenRoute:
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const IntroScreen());

    case signUpScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const SignUpScreen());

    case loginScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const LoginScreen());

    case dashboardScreenRoute:
      final args = settings.arguments as DashboardScreen;
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: DashboardScreen(screenIndex: args.screenIndex,));

    case homeScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const HomeScreen());

    case historyScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const HistoryScreen());

    case notificationScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const NotificationScreen());

    // case detailScreenRoute:
    // final args = settings.arguments as DetailScreen;
    //   return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child:  DetailScreen(libraryIndex: args.libraryIndex,));

    case newDetailScreenRoute:
    final args = settings.arguments as NewDetailScreen;
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child:  NewDetailScreen(libraryIndex: args.libraryIndex,detailsListData: args.detailsListData,));

    case searchScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: const SearchScreen());  


    case verifyOtpScreenRoute:
      final args = settings.arguments as VerifyOtpScreen;
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: VerifyOtpScreen(mobileNumber: args.mobileNumber,));

    case filterScreenRoute:
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: FilterScreen());

    case searchScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: SearchScreen());

    case updateProfileScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: UpdateProfileScreen());

    case helpAndSupportScreenRoute:
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: HelpAndSupportScreen());

    // case libraryBookScheduleScreenRoute:
    //   final args = settings.arguments as LibraryBookScheduleScreen;
    //   return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: LibraryBookScheduleScreen(currentDate: args.currentDate,libraryID: args.libraryID,isDetail: args.isDetail,));

    case newLibraryBookScheduleScreenRoute:
      final args = settings.arguments as NewLibraryBookScheduleScreen;
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: NewLibraryBookScheduleScreen(currentDate: args.currentDate,libraryID: args.libraryID,isDetail: args.isDetail,currentIndex: args.currentIndex,homeData: args.homeData,detailsListData:args.detailsListData,));

    case myDetailScreenRoute:
      final args = settings.arguments as MyDetailsScreen;
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: MyDetailsScreen(bookingNo: args.bookingNo,price: args.price,subsType: args.subsType,reNewSubs: args.reNewSubs,historyData: args.historyData,isShowRenewSubscription: args.isShowRenewSubscription,));

    case seatArrangementScreenRoute:
      final args = settings.arguments as SeatArrangementScreen;
      return PageTransition(type: PageTransitionType.bottomToTop,duration: const Duration(milliseconds: 500), alignment: Alignment.center, child: SeatArrangementScreen(planID: args.planID,openTime: args.openTime,closeTime: args.closeTime,planAmount: args.planAmount,planName: args.planName,selectedDate: args.selectedDate,selectedEndDate: args.selectedEndDate,libraryName: args.libraryName,libraryID: args.libraryID,subStartTime: args.subStartTime,subCloseTime: args.subCloseTime,subcriptionId: args.subcriptionId,));

    case reviewScreenRoute:
      final args = settings.arguments as ReviewScreen;
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: ReviewScreen(libraryID: args.libraryID,));

    case myQrCodeScreenRoute:
      final args = settings.arguments as MyQrCodeScreen;
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: MyQrCodeScreen(bookingNo: args.bookingNo));

    case paymentStatusRoute:
      final args = settings.arguments as PaymentStatus;
      return PageTransition(type: PageTransitionType.leftToRight,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: PaymentStatus(onTap: args.onTap,message: args.message,paymentStatus: args.paymentStatus,));

    case pdfViewScreenRoute:
      final args = settings.arguments as PdfViewScreen;
      return PageTransition(type: PageTransitionType.rightToLeft,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: PdfViewScreen(pdfUrl: args.pdfUrl,));

    case googleMapScreenRoute:
      final args = settings.arguments as GoogleMapScreen;
      return PageTransition(type: PageTransitionType.fade,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: GoogleMapScreen(tag: args.tag,));

    case completeBookingScreenRoute:
      final args = settings.arguments as CompleteBookingScreen;
      return PageTransition(type: PageTransitionType.fade,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: CompleteBookingScreen(bookingNumber: args.bookingNumber,));

    case couponCodeScreenRoute:
      final args = settings.arguments as CouponCodesScreen;
      return PageTransition(type: PageTransitionType.fade,duration: const Duration(milliseconds: 300), alignment: Alignment.center, child: CouponCodesScreen(libraryID: args.libraryID,subscriptionID: args.subscriptionID,));


  // case categoryScreenRoute:
    //   final args = settings.arguments as CategoryScreen;
    //   return PageTransition(
    //       type: PageTransitionType.fade,
    //       duration: const Duration(milliseconds: 300),
    //       alignment: Alignment.center,
    //       child: CategoryScreen(
    //         appBarHeading: args.appBarHeading,
    //         id: args.id,
    //       ));

    default:
      return MaterialPageRoute(builder: (context) => const SplashScreen());
  }
}
