import 'package:apna_slot/View/Dashboard/History/HistoryResponse.dart';
import 'package:apna_slot/View/Dashboard/Home/Filter/FilterResponse.dart';
import 'package:dio/dio.dart';
import '../../View/Dashboard/Home/HomeScreen/HomeApiResponse.dart';
import '../../View/Dashboard/Home/Search/SearchResponse.dart';
import '../../View/Dashboard/Notification/NotificationResponse.dart';
import '../../View/Detail/DetailsApiResponse.dart';
import '../../View/LibraryBooking/CompleteBooking/completeBookingResponse.dart';
import '../../View/LibraryBooking/LibrarySheetArrangement/FloorPlanApiResponse.dart';
import '../../View/LibraryBooking/LibrarySheetArrangement/SubmitApiResponse.dart';
import '../../View/LibraryBooking/coupon_code/coupon_code_response.dart';
import '../../View/Onboarding/Intro/IntroApiResponse.dart';
import '../../View/Onboarding/Login/LoginApiResponse.dart';
import '../../View/Onboarding/SignUp/SignUpApiResponse.dart';
import '../../View/Onboarding/VerifyOTP/VerifyOtpResponse.dart';
import '../../View/Privacy/PrivacyResponse.dart';
import '../../View/Profile/Help&Support/SubmitQueryResponse.dart';
import '../../View/Profile/UpdateProfile/ProfileResponse.dart';
import '../../View/Review/ReviewResponse.dart';
import '../../main.dart';
import '../Helper/ConnectionValidator/ConnectionValidator.dart';
import '../Helper/PrintLog/PrintLog.dart';
import '../WidgetController/Popup/PopupCustom.dart';
import '../WidgetController/StringDefine/StringDefine.dart';
import '../WidgetController/Toast/ToastCustom.dart';
import 'WebConstant.dart';
import '../../View/Dashboard/Notification/NotificationResponse.dart';

class ApiController {
  Dio _dio = new Dio();

  Map<String, String> headers = {
    "Content-type": "application/json",
    "Authorization": 'Bearer $authToken',
    "Authkey": WebApiConstant.AUTH_KEY,
    "Connection": "Keep-Alive",
    "Keep-Alive": "timeout=5, max=1000"
  };

  ApiController() {
    BaseOptions options = BaseOptions(
        baseUrl: WebApiConstant.BASE_URL,
        receiveTimeout: const Duration(minutes: 1),
        connectTimeout: const Duration(minutes: 1),
        headers: headers);
    _dio.options = options;
  }


  /// Intro Api
  Future<IntroApiResponse?> introApi({context, required String url, dictParameter, String? token}) async {
    IntroApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = IntroApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Login Api
  Future<LoginApiResponse?> loginApi({context, required String url, dictParameter, String? token}) async {
    LoginApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = LoginApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Sign Up Api
  Future<SignUpApiResponse?> signUpApi({context, required String url, dictParameter, String? token}) async {
    SignUpApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestPostForApi(context: context, url: url,dictParameter: dictParameter,token: token!);
        if (response?.data != null && response?.statusCode == 200) {
          result = SignUpApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Verify OTP Api
  Future<VerifyOtpApiResponse?> verifyOtpApi({context, required String url, dictParameter, String? token}) async {
    VerifyOtpApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestPostForApi(context: context, url: url,dictParameter: dictParameter,token: token!);
        if (response?.data != null && response?.statusCode == 200) {
          result = VerifyOtpApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Get Library Api
  Future<GetHomeApiResponse?> getHomeApi({context, required String url, dictParameter, String? token}) async {
    GetHomeApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = GetHomeApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Map MarkUP Api
  Future<MapMarkUpResponse?> mapMarkUpApi({context, required String url, dictParameter, String? token}) async {
    MapMarkUpResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = MapMarkUpResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Get Library Detail Api
  Future<GetDetailResponse?> getLibraryDetailApi({context, required String url, dictParameter, String? token}) async {
    GetDetailResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = GetDetailResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  // /// Get Library Api
  // Future<GetLibraryApiResponse?> getLibraryApi({context, required String url, dictParameter, String? token}) async {
  //   GetLibraryApiResponse? result;
  //   if (await ConnectionValidator().check()) {
  //     try {
  //       final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
  //       if (response?.data != null && response?.statusCode == 200) {
  //         result = GetLibraryApiResponse.fromJson(response?.data);
  //         return result;
  //       } else {
  //         return result;
  //       }
  //     } catch (e) {
  //       PrintLog.printLog("Exception_main1: $e");
  //       return result;
  //     }
  //   } else {
  //     ToastCustom.showToast( msg: networkToastString);
  //   }
  //   return null;
  // }

///Notification Api
    Future<NotificationApiResponse?> getNotificaitonApi({context, required String url, dictParameter, String? token}) async {
    NotificationApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = NotificationApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Update Profile Api
  Future<UpdateProfileResponse?> updateProfileApi({context, required String url, FormData? formData, String? token}) async {

    UpdateProfileResponse? result;
    if(await ConnectionValidator().check()){
      try{
        final response = await requestMultipartApi(context: context,url:url,formData: formData,token: token);
        if(response?.data != null && response?.statusCode == 200){
          result = UpdateProfileResponse.fromJson(response?.data);
        }
        return result;
      }catch(e){
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    }else{
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Complete Booking Api
  Future<CompleteBookingResponse?> completeBookingApi({context, required String url, FormData? formData, String? token}) async {

    CompleteBookingResponse? result;
    if(await ConnectionValidator().check()){
      try{
        final response = await requestMultipartApi(context: context,url:url,formData: formData,token: token);
        if(response?.data != null && response?.statusCode == 200){
          result = CompleteBookingResponse.fromJson(response?.data);
        }
        return result;
      }catch(e){
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    }else{
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Submit Query Api
  Future<SubmitQueryResponse?> submitQueryApi({context, required String url, dictParameter, String? token}) async {

    SubmitQueryResponse? result;
    if(await ConnectionValidator().check()){
      try{
        final response = await requestPostForApi(context: context,url:url,dictParameter: dictParameter,token: token ?? "");
        if(response?.data != null && response?.statusCode == 200){
          result = SubmitQueryResponse.fromJson(response?.data);
        }
        return result;
      }catch(e){
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    }else{
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Submit Query Api
  Future<QueryHeadingResponse?> queryHeadingApi({context, required String url, dictParameter, String? token}) async {

    QueryHeadingResponse? result;
    if(await ConnectionValidator().check()){
      try{
        final response = await requestGetForApi(context: context,url:url,dictParameter: dictParameter,token: token ?? "");
        if(response?.data != null && response?.statusCode == 200){
          result = QueryHeadingResponse.fromJson(response?.data);
        }
        return result;
      }catch(e){
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    }else{
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }
  ///Search API
  Future<SearchApiResponse?> getSearchApi({context, required String url, dictParameter, String? token}) async {
    SearchApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = SearchApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Notification Api
  Future<NotificationReadApiResponse?> getNotificationReadApi({context, required String url, dictParameter, String? token}) async {
    NotificationReadApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = NotificationReadApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }


  /// Filter Api
  Future<FilterApiResponse?> getFilterApi({context, required String url, dictParameter, String? token}) async {
    FilterApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = FilterApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Term & Condition Api
  Future<TermsAndConditionsResponse?> getTermConditionApi({context, required String url, dictParameter, String? token}) async {
    TermsAndConditionsResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = TermsAndConditionsResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Review Api
  Future<ReviewApiResponse?> getReviewListApi({context, required String url, dictParameter, String? token}) async {
    ReviewApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = ReviewApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Update Review Api
  Future<UpdateReviewResponse?> updateReviewApi({context, required String url, dictParameter, String? token}) async {
    UpdateReviewResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestPostForApi(context: context, url: url,dictParameter: dictParameter,token: token!);
        if (response?.data != null && response?.statusCode == 200) {
          result = UpdateReviewResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  ///History Api
  Future<HistoryApiResponse?> getHistoryApi({context, required String url, dictParameter, String? token}) async {
    HistoryApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = HistoryApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  ///Submit Booking Api
  Future<SubmitBookingResponse?> submitBookingApi({context, required String url, dictParameter, String? token}) async {
    SubmitBookingResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestPostForApi(context: context, url: url,dictParameter: dictParameter,token: token!);
        if (response?.data != null && response?.statusCode == 200) {
          result = SubmitBookingResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

    Future<FloorPlanApiResponse?> floorPlanApi({context, required String url, dictParameter, String? token}) async {
    FloorPlanApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = FloorPlanApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }


  Future<Response?> requestGetForApi(
      {required context,
      String? url,
      Map<String, dynamic>? dictParameter,
      String? token}) async {
    try {
      Map<String, String> headers = {
        "Content-type": "application/json",
        "Authkey": WebApiConstant.AUTH_KEY,
        "Authorization": "Bearer $token",
        "Connection": "Keep-Alive",
        "Keep-Alive": "timeout=5, max=1000",
        // "x-localization":"en",
      };

      //  final prefs = await SharedPreferences.getInstance();
      // String userId = prefs.getString(AppSharedPreferences.userId) ?? "";
      //  String sessionId = prefs.getString(AppSharedPreferences.sessionId) ?? "";

      PrintLog.printLog("Headers: $headers");
      PrintLog.printLog("Url:  $url");
      PrintLog.printLog("Token:  $token");
      PrintLog.printLog("DictParameter: $dictParameter");

      BaseOptions options = BaseOptions(
          baseUrl: WebApiConstant.BASE_URL,
          receiveTimeout: const Duration(minutes: 1),
          connectTimeout: const Duration(minutes: 1),
          headers: headers,
          validateStatus: (_) => true
      );

      _dio.options = options;
      Response response = await _dio.get(url!, queryParameters: dictParameter);
      PrintLog.printLog("Response_headers: ${response.headers}");
      PrintLog.printLog("Response_data: ${response.data}");

      if(response.data["authenticated"] == false){
        PopupCustom.logoutPopUP(context: context);
      }
      return response;

    } catch (error) {
      PrintLog.printLog("Exception_Main: $error");
      return null;
    }
  }

  Future<Response?> requestPostForApi(
      {required context,
      required String url,
      required Map<String, dynamic> dictParameter,
      required String token}) async {
    try {
      Map<String, String> headers = {
        "Content-type": "application/json",
        "Authkey": WebApiConstant.AUTH_KEY,
        "Authorization": "Bearer $token",
        "Connection": "Keep-Alive",
        "Keep-Alive": "timeout=5, max=1000"
      };

      PrintLog.printLog("Headers: $headers");
      PrintLog.printLog("Url:  $url");
      PrintLog.printLog("Token:  $token");
      PrintLog.printLog("DictParameter: $dictParameter");

      BaseOptions options = BaseOptions(
          baseUrl: WebApiConstant.BASE_URL,
          receiveTimeout: const Duration(minutes: 1),
          connectTimeout: const Duration(minutes: 1),
          headers: headers);
      _dio.options = options;
      Response response = await _dio.post(url,
          data: dictParameter,
          options: Options(
              followRedirects: false,
              validateStatus: (status) => true,
              headers: headers));
      if(response.data["authenticated"] == false){
        PopupCustom.logoutPopUP(context: context);
      }
      PrintLog.printLog("Response: $response");
      PrintLog.printLog("Response_headers: ${response.headers}");
      PrintLog.printLog("Response_realuri: ${response.realUri}");
      return response;
    } catch (error) {
      PrintLog.printLog("Exception_Main: $error");
      return null;
    }
  }

  Future<Response?> requestMultipartApi(
      {required context, String? url, formData, String? token}) async {
    try {
      Map<String, String> headers = {
        "Content-type": "application/json",
        "Authkey": WebApiConstant.AUTH_KEY,
        "Authorization": "Bearer $token",
        "Connection": "Keep-Alive",
        "Keep-Alive": "timeout=5, max=1000"
      };

      PrintLog.printLog("Headers: $headers");
      PrintLog.printLog("Url:  $url");
      PrintLog.printLog("Token:  $token");
      PrintLog.printLog("formData: $formData");

      BaseOptions options = BaseOptions(
          baseUrl: WebApiConstant.BASE_URL,
          receiveTimeout: const Duration(minutes: 1),
          connectTimeout: const Duration(minutes: 1),
          headers: headers);

      _dio.options = options;
      Response response = await _dio.post(url!,
          data: formData,
          options: Options(
            followRedirects: false,
            validateStatus: (status) => true,
            headers: headers,
          ));

      PrintLog.printLog("Response: $response");

      if(response.data["authenticated"] == false){
        PopupCustom.logoutPopUP(context: context);
      }
      return response;
    } catch (error) {
      PrintLog.printLog("Exception_Main: $error");
      return null;
    }
  }

  ///Coupon code get list Api
  Future<CouponCodeApiResponse?> getCouponCodeApi({context, required String url, dictParameter, String? token}) async {
    CouponCodeApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestGetForApi(context: context, url: url,dictParameter: dictParameter,token: token);
        if (response?.data != null && response?.statusCode == 200) {
          result = CouponCodeApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

  /// Apply coupon code Api
  Future<ApplyCouponCodeApiResponse?> applyCouponCodeApi({context, required String url, dictParameter, String? token}) async {
    ApplyCouponCodeApiResponse? result;
    if (await ConnectionValidator().check()) {
      try {
        final response = await requestPostForApi(context: context, url: url,dictParameter: dictParameter,token: token!);
        if (response?.data != null && response?.statusCode == 200) {
          result = ApplyCouponCodeApiResponse.fromJson(response?.data);
          return result;
        } else {
          return result;
        }
      } catch (e) {
        PrintLog.printLog("Exception_main1: $e");
        return result;
      }
    } else {
      ToastCustom.showToast( msg: networkToastString);
    }
    return null;
  }

}
