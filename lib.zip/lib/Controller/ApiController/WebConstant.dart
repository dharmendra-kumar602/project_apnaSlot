class WebApiConstant {

  /// Auth key
  static const String AUTH_KEY                               =  "Apna002Slot\$#\$HS";

  /// Live url
  // static const String BASE_URL_DOMAIN                        =  "http://192.168.29.106:8300";
  static const String BASE_URL_DOMAIN                        =  "https://www.apnaslot.com";
  static const String BASE_URL                               =  BASE_URL_DOMAIN +"/api/v1/";

  /// Public
  static const String API_URL_INTRO                          =  "${BASE_URL}intro";
  static const String API_URL_LOGIN                          =  "${BASE_URL}user/login";
  // static const String API_URL_LOGOUT                         =  "${BASE_URL}user/logout";
  static const String API_URL_REGISTER                       =  "${BASE_URL}user/register";
  static const String API_URL_GET_HOME                       =  "${BASE_URL}home";//?latitude=26.8561&longitude=75.8061&search_val=library_name&facility_type=1,2&start_range=1000&end_range=2000'
  static const String API_URL_MAP_MARKUP                     =  "${BASE_URL}mapMarkup";//?latitude=26.8561&longitude=75.8061
  static const String API_URL_GET_LIBRARY_DETAIL             =  "${BASE_URL}library/details"; //?id=45
  static const String API_URL_GET_LIBRARY                    =  "${BASE_URL}library/list";

  static const String API_URL_UPDATE_PROFILE                 =  "${BASE_URL}user/updateProfile";
  static const String API_URL_VERIFY_OTP                     =  "${BASE_URL}user/verifyOtp";
  static const String API_URL_RESEND_OTP                     =  "${BASE_URL}user/resendOtp";
  static const String API_URL_POST_QUERY                     =  "${BASE_URL}general/raiseQuery";
  static const String API_URL_GET_QUERY_HEADING              =  "${BASE_URL}general/complainHeading";
  static const String API_URL_GET_REVIEW                     =  "${BASE_URL}library/getreview"; //?library_id=45
  static const String API_URL_UPDATE_REVIEW                  =  "${BASE_URL}library/review";

  static const String API_URL_GET_PROFILE                    =  "${BASE_URL}user/getProfile";
  static const String API_URL_GET_LIBRARY_DETAILS            =  "${BASE_URL}library/details";
  static const String API_URL_GET_NOTIFICATION               =  "${BASE_URL}notification";
  static const String API_URL_READ_NOTIFICATION              =  "${BASE_URL}notification/read";
  static const String API_URL_GET_FILTER                     =  "${BASE_URL}filterData";
  static const String API_URL_GET_MYBOOKING                  =  "${BASE_URL}user/myBookings";
  static const String API_URL_SUBMIT_BOOKING                 =  "${BASE_URL}user/getToken";
  static const String API_URL_GET_TERMS_OR_POLICY            = "${BASE_URL}user/getcontent";

  static const String API_URL_COMPLETE_BOOKING               = "${BASE_URL}user/submitBooking";

  static const String API_URL_GET_COUPON_CODE_LIST               =  "${BASE_URL}library/getCouponList";
  static const String API_URL_APPLY_COUPON_CODE               =  "${BASE_URL}library/applyCoupon";
  static const String API_URL_FLOOR_PLAN                     =  "${BASE_URL}user/floorplan";

}
