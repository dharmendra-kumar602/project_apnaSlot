import 'dart:developer';

class PrintLog{
  static void printLog(var message){
    log(message);
    // print(message);
  }
}