
import 'package:maps_launcher/maps_launcher.dart';

class RedirectToMap{
  static Future<void> redirect({required double lat,required double lng,required String name})async{
    MapsLauncher.launchCoordinates(
        lat, lng, name);
  }
}