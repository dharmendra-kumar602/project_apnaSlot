import 'package:shared_preferences/shared_preferences.dart';

import '../PrintLog/PrintLog.dart';

class AppSharedPreferences {
  static SharedPreferences? _preferences;

  static Future<SharedPreferences?> getInstance() async {
    if (_preferences == null) {
      _preferences = await SharedPreferences.getInstance();
      return _preferences;
    }
    return _preferences;
  }


  static String authToken = "token";
  static String fcmToken = "fcm_token";

  static String userId = "id";
  static String userName = "user_name";
  static String userStatus = "user_staus";
  static String userProfileImg = "profile_photo";
  static String userMobileNo = "user_mobile_no";
  static String userEmail = "user_email";
  static String userMobileMpin = "mobile_mpin";
  static String userAddress = "address";
  static String userDob = "dob";
  static String userStateName = "state_name";
  static String userStateId = "state_id";
  static String userCityName = "city_name";
  static String userCityId = "city_id";
  static String userAadhaarNumber = "aadhaar_number";
  static String userAadhaarImage = "aadhaar_Image";

  /// ADD DATA
  static addStringValueToSharedPref(
      {required String variableName, required String variableValue}) async {
    await _preferences?.setString(variableName, variableValue);
  }

  static addBoolValueToSharedPref(
      {required String variableName, required bool variableValue}) async {
    await _preferences?.setBool(variableName, variableValue);
  }

  static addIntValueToSharedPref(
      {required String variableName, required int variableValue}) async {
    await _preferences?.setInt(variableName, variableValue);
  }

  static addStringListValueToSharedPref(
      {required String variableName,
      required List<String> variableValue}) async {
    await _preferences?.setStringList(variableName, variableValue);
  }

  ///GET DATA
  static String? getStringFromSharedPref({required String variableName}) {
    String? returnValue = _preferences?.getString(variableName);
    return returnValue;
  }

  static int? getIntValueFromSharedPref({required String variableName}) {
    int? returnValue = _preferences?.getInt(variableName);
    return returnValue;
  }

  static bool? getBoolValueFromSharedPref({required String variableName}) {
    bool? returnValue = _preferences?.getBool(variableName);
    return returnValue;
  }

  static List<String>? getStringListValueFromSharedPref(
      {required String variableName}) {
    List<String>? returnValue = _preferences?.getStringList(variableName);
    return returnValue;
  }

  ///CLEAR SHARED PREFERENCE
  static Future clearSharedPref() async {
    PrintLog.printLog("Shared Preference clean...");
    _preferences?.clear();
  }
}
