
import 'package:url_launcher/url_launcher.dart';

class RedirectToEmail{
 static Future<void> EmailLaunch({required String emailID})async{
    final email = Uri(
                      scheme: 'mailto',
                      path: emailID,
                      query: '',
                    );
                    if (await canLaunchUrl(email)) {
                      launchUrl(email);
                    } else {
                      throw 'Could not launch $email';
                    }
  }
}