import 'dart:ui';
import 'package:flutter/cupertino.dart';

import '../FontFamily/FontFamily.dart';

class BuildText{
  static Widget buildTextForSplash({required String text, required Color color}) {
    return Text(
      text,
      style: TextStyle(
          color: color,
          fontFamily: FontFamily.josefinRegular,
          letterSpacing: 2.0,
          fontSize: 16.0),
    );
  }
}