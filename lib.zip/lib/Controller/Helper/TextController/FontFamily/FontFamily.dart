
class FontFamily{
  static String josefinBold = "JosefinSansBold";
  static String josefinRegular = "JosefinSansRegular";
  static String josefinLight = "JosefinSansLight";
  static String larkenMedium = "LarkenMedium";
  static String larkenBold = "LarkenBold";
  static String larkenRegular = "LarkenRegular";

}