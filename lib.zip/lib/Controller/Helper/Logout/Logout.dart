
import 'package:apna_slot/Controller/Helper/Shared%20Preferences/SharedPreferences.dart';
import 'package:get/get.dart';

import '../../RouteController/RouteNames.dart';

class LogoutCustom{

  static Future logout()async{
    await AppSharedPreferences.clearSharedPref().then((value) {
      Get.offAllNamed(loginScreenRoute);
    });
  }
}