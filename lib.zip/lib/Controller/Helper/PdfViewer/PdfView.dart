import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../ColoController/CustomColors.dart';

class PdfViewScreen extends StatefulWidget {
  const PdfViewScreen({Key? key, required this.pdfUrl,}) : super(key: key);
  final String pdfUrl;

  @override
  State<PdfViewScreen> createState() => _PdfViewScreenState();
}

class _PdfViewScreenState extends State<PdfViewScreen> {
  final GlobalKey<SfPdfViewerState> _pdfViewerKey = GlobalKey();

  PdfViewerController? _pdfViewerController;

  @override
  void initState() {
    _pdfViewerController = PdfViewerController();
    // _pdfViewerKey.currentState?.openBookmarkView();
    super.initState();
  }

  OverlayEntry? _overlayEntry;
  void _showContextMenu(BuildContext context,PdfTextSelectionChangedDetails details) {
    final OverlayState _overlayState = Overlay.of(context);
    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: details.globalSelectedRegion!.center.dy - 55,
        left: details.globalSelectedRegion?.bottomLeft.dx,
        child:
        TextButton(
          child: const Text('Copy',style: TextStyle(fontSize: 17)),onPressed: (){
          Clipboard.setData(ClipboardData(text: details.selectedText ?? ""));
          _pdfViewerController?.clearSelection();
        },
        ),
      ),
    );
    _overlayState.insert(_overlayEntry!);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Hero(
            tag: widget.pdfUrl,
            child: Stack(
              children: [
                SfPdfViewer.network(
                  widget.pdfUrl.toString(),
                  // 'https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf',
                  onTextSelectionChanged:
                      (PdfTextSelectionChangedDetails details) {
                    if (details.selectedText == null && _overlayEntry != null) {
                      _overlayEntry?.remove();
                      _overlayEntry = null;
                    } else if (details.selectedText != null && _overlayEntry == null) {
                      _showContextMenu(context, details);
                    }
                  },
                  controller: _pdfViewerController,
                    // key: _pdfViewerKey
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  // alignment: Alignment.topRight,
                  child: InkWell(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 15.0,left: 15.0, right: 15.0),
                        child: ClipOval(
                            clipBehavior: Clip.antiAlias,
                            child: Container(
                                padding: const EdgeInsets.all(5.0),
                                color: CustomColors.whiteColor.withOpacity(0.70),
                                child: Icon(Icons.clear,color: CustomColors.greyColor ,size: 20.0,)
                            )
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }

}