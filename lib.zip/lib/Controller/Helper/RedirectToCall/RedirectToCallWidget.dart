
import 'package:url_launcher/url_launcher.dart';

class RedirectToCall{
   static Future<void> phoneNumberLaunch({required String phoneNumber})async{
    final call = Uri.parse('tel: $phoneNumber');
                    if (await canLaunchUrl(call)) {
                      launchUrl(call);
                    } else {
                      throw 'Could not launch $call';
                    }
  }  
}